package com.company.payintegration.payment.presentation.request;

import com.company.payintegration.shared.presentation.MoneyDto;
import jakarta.validation.Valid;

/** amount omitted (or no body) = capture the full remaining authorised amount. */
public record CapturePaymentRequest(@Valid MoneyDto amount) {
}
