package com.company.payintegration.payment.presentation.request;

import com.company.payintegration.shared.presentation.MoneyDto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public record RefundPaymentRequest(@NotNull @Valid MoneyDto amount) {
}
