package com.company.payintegration.savedcard.presentation;

import java.time.Instant;

/** What our backend sees about a saved card. Never the token. */
public record SavedCardResponse(String savedCardId, String maskedPan, String scheme, String expiry,
                                String cardholderName, boolean expired, Instant createdAt) {
}
