package com.company.payintegration.payment.presentation.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Shopper browser data for EMV 3DS 2.x, collected by the frontend (navigator.*, screen.*,
 * new Date().getTimezoneOffset()) and the shopper IP seen by our backend.
 */
public record BrowserInfoDto(
        @NotBlank @Size(max = 2048) String acceptHeader,
        Boolean javaEnabled,
        @NotBlank @Size(max = 8) String language,
        @Pattern(regexp = "-?\\d{1,4}") String timeZoneOffset,
        @NotBlank @Size(max = 2048) String userAgent,
        @Pattern(regexp = "\\d{1,2}") String colorDepth,
        @Pattern(regexp = "\\d{1,6}") String screenHeight,
        @Pattern(regexp = "\\d{1,6}") String screenWidth,
        Boolean javascriptEnabled,
        @NotBlank @Size(max = 45) String ip,
        @Pattern(regexp = "0[1-5]") String challengeWindowSize) {
}
