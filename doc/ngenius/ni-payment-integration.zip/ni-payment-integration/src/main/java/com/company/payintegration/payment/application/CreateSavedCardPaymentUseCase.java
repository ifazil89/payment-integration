package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.savedcard.SavedCardApi;
import com.company.payintegration.savedcard.SavedCardForPayment;
import org.springframework.stereotype.Service;

/** Saved card: create AUTH order, then PUT token + expiry + CVV to "payment:saved-card". */
@Service
public class CreateSavedCardPaymentUseCase {

    private final AuthorisationFlow flow;
    private final PaymentGatewayPort gateway;
    private final SavedCardApi savedCardApi;

    public CreateSavedCardPaymentUseCase(AuthorisationFlow flow, PaymentGatewayPort gateway, SavedCardApi savedCardApi) {
        this.flow = flow;
        this.gateway = gateway;
        this.savedCardApi = savedCardApi;
    }

    public PaymentOutcome execute(CreateSavedCardPaymentCommand command) {
        // Checked before creating any order: card exists, belongs to the customer, not expired.
        SavedCardForPayment card = savedCardApi.getForPayment(command.payment().customerId(), command.savedCardId());
        return flow.run(command.payment(), order -> gateway.payWithSavedCard(order, card, command.cvv()));
    }
}
