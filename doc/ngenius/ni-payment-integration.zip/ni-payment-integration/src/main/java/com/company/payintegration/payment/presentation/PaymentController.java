package com.company.payintegration.payment.presentation;

import com.company.payintegration.payment.application.CreateCardPaymentUseCase;
import com.company.payintegration.payment.application.CreateSavedCardPaymentUseCase;
import com.company.payintegration.payment.application.GetPaymentUseCase;
import com.company.payintegration.payment.presentation.request.CreateCardPaymentRequest;
import com.company.payintegration.payment.presentation.request.CreateSavedCardPaymentRequest;
import com.company.payintegration.payment.presentation.response.PaymentResponse;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Called by OUR backend only (X-Api-Key). Every create call needs an Idempotency-Key:
 * repeating a call with the same key returns the same payment and never charges twice.
 *
 * The HTTP status is 200 whenever the request was processed; the payment result
 * (AUTHORISED, AWAITING_3DS, DECLINED, FAILED...) is in the body.
 */
@RestController
@RequestMapping("/api/v1/payments")
class PaymentController {

    static final String IDEMPOTENCY_KEY = "Idempotency-Key";

    private final CreateCardPaymentUseCase createCardPayment;
    private final CreateSavedCardPaymentUseCase createSavedCardPayment;
    private final GetPaymentUseCase getPayment;

    PaymentController(CreateCardPaymentUseCase createCardPayment,
                      CreateSavedCardPaymentUseCase createSavedCardPayment,
                      GetPaymentUseCase getPayment) {
        this.createCardPayment = createCardPayment;
        this.createSavedCardPayment = createSavedCardPayment;
        this.getPayment = getPayment;
    }

    @PostMapping("/card")
    PaymentResponse payWithCard(@RequestHeader(IDEMPOTENCY_KEY) String idempotencyKey,
                                @Valid @RequestBody CreateCardPaymentRequest request) {
        return PaymentPresentationMapper.toResponse(
                createCardPayment.execute(PaymentPresentationMapper.toCommand(validKey(idempotencyKey), request)));
    }

    @PostMapping("/saved-card")
    PaymentResponse payWithSavedCard(@RequestHeader(IDEMPOTENCY_KEY) String idempotencyKey,
                                     @Valid @RequestBody CreateSavedCardPaymentRequest request) {
        return PaymentPresentationMapper.toResponse(
                createSavedCardPayment.execute(PaymentPresentationMapper.toCommand(validKey(idempotencyKey), request)));
    }

    /** refresh=true asks N-Genius for the latest status before answering. */
    @GetMapping("/{paymentId}")
    PaymentResponse get(@PathVariable String paymentId,
                        @RequestParam(defaultValue = "false") boolean refresh) {
        return PaymentPresentationMapper.toResponse(getPayment.execute(paymentId, refresh));
    }

    private static String validKey(String key) {
        if (key.isBlank() || key.length() > 100) {
            throw new IllegalArgumentException(IDEMPOTENCY_KEY + " must be 1-100 characters");
        }
        return key;
    }
}
