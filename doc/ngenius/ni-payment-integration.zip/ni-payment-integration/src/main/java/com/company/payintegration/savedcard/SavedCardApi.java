package com.company.payintegration.savedcard;

/** Public API of the savedcard feature. */
public interface SavedCardApi {

    /** Stores the card; saving the same token twice for a customer is a no-op. Returns the saved card id. */
    String save(NewSavedCard card);

    /** Token data for a payment. Fails if the card is unknown, not the customer's, or expired. */
    SavedCardForPayment getForPayment(String customerId, String savedCardId);
}
