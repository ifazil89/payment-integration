package com.company.payintegration.webhook;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * N-Genius webhook body (only the fields we use).
 * e.g. {"eventId": "...", "eventName": "AUTHORISED", "outletId": "...", "order": {"reference": "...", ...}}
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record NgeniusWebhookPayload(String eventId, String eventName, String outletId, Order order) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Order(String reference, String action) {
    }

    String orderReference() {
        return order != null ? order.reference() : null;
    }
}
