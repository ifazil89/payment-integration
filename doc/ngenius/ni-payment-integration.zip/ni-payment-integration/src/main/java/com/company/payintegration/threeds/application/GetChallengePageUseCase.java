package com.company.payintegration.threeds.application;

import com.company.payintegration.threeds.ThreeDsApi;
import com.company.payintegration.threeds.ThreeDsChallenge;
import org.springframework.stereotype.Service;

import java.util.Optional;

/** Data for the auto-submitting challenge page. Empty if the session is not waiting for a challenge. */
@Service
public class GetChallengePageUseCase {

    private final ThreeDsApi threeDsApi;

    GetChallengePageUseCase(ThreeDsApi threeDsApi) {
        this.threeDsApi = threeDsApi;
    }

    public Optional<ThreeDsChallenge> execute(String sessionId) {
        return threeDsApi.pendingChallenge(sessionId);
    }
}
