package com.company.payintegration.threeds.presentation;

import com.company.payintegration.threeds.application.CompleteThreeDsChallengeUseCase;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;

/**
 * PUBLIC endpoint = the notificationURL sent to N-Genius.
 * After the challenge, the ACS makes the shopper's browser POST a form field "cres" here.
 * We answer with a 303 redirect to the shop's return page (?paymentId=...), where the
 * frontend asks our backend for the final status.
 */
@RestController
@RequestMapping("/ngenius/3ds/notification")
class ThreeDsNotificationController {

    private final CompleteThreeDsChallengeUseCase completeChallenge;

    ThreeDsNotificationController(CompleteThreeDsChallengeUseCase completeChallenge) {
        this.completeChallenge = completeChallenge;
    }

    @PostMapping(path = "/{sessionId}", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    ResponseEntity<Void> notification(@PathVariable String sessionId, @RequestParam("cres") String cres) {
        String redirect = completeChallenge.execute(sessionId, cres);
        return ResponseEntity.status(HttpStatus.SEE_OTHER).location(URI.create(redirect)).build();
    }
}
