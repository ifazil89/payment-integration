package com.company.payintegration.payment;

/**
 * Public API of the payment feature (used by the webhook feature).
 */
public interface PaymentApi {

    /**
     * Re-reads the order from N-Genius and applies its status.
     * Returns false if no payment exists for this N-Genius order reference.
     */
    boolean refreshFromGateway(String gatewayOrderReference);
}
