package com.company.payintegration.threeds.application;

import com.company.payintegration.shared.infrastructure.config.AppProperties;
import com.company.payintegration.threeds.ThreeDsApi;
import com.company.payintegration.threeds.ThreeDsChallenge;
import com.company.payintegration.threeds.ThreeDsStartCommand;
import com.company.payintegration.threeds.ThreeDsStartResult;
import com.company.payintegration.threeds.application.port.AuthenticationResult;
import com.company.payintegration.threeds.application.port.ThreeDsGatewayPort;
import com.company.payintegration.threeds.application.port.ThreeDsSessionRepositoryPort;
import com.company.payintegration.threeds.domain.ChallengeRequestFactory;
import com.company.payintegration.threeds.domain.ThreeDsSession;
import com.company.payintegration.threeds.domain.TransStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

/**
 * Implements the public ThreeDsApi.
 *
 * Step 1: POST cnp:3ds2-authentication with browser data and our notificationURL.
 *   transStatus = C  -> challenge: return acsUrl + creq for the frontend
 *   anything else    -> frictionless: the gateway continued; caller refreshes the order
 */
@Service
class StartThreeDsAuthenticationUseCase implements ThreeDsApi {

    private static final Logger log = LoggerFactory.getLogger(StartThreeDsAuthenticationUseCase.class);

    private final ThreeDsGatewayPort gateway;
    private final ThreeDsSessionRepositoryPort repository;
    private final ThreeDsUrls urls;
    private final Duration sessionTtl;

    StartThreeDsAuthenticationUseCase(ThreeDsGatewayPort gateway, ThreeDsSessionRepositoryPort repository,
                                      ThreeDsUrls urls, AppProperties appProperties) {
        this.gateway = gateway;
        this.repository = repository;
        this.urls = urls;
        this.sessionTtl = appProperties.threeds().sessionTtl();
    }

    @Override
    public void requireAllowedReturnUrl(String returnUrl) {
        urls.requireAllowedReturnUrl(returnUrl);
    }

    @Override
    public ThreeDsStartResult start(ThreeDsStartCommand command) {
        urls.requireAllowedReturnUrl(command.returnUrl());

        ThreeDsSession session = repository.save(ThreeDsSession.start(command.paymentId(), command.outletId(),
                command.orderReference(), command.paymentReference(), command.returnUrl(), sessionTtl));

        AuthenticationResult result;
        try {
            result = gateway.authenticate(command.orderReference(), command.paymentReference(),
                    urls.notificationUrl(session.getId()), command.browserInfo());
        } catch (RuntimeException ex) {
            session.fail();
            repository.save(session);
            throw ex;
        }

        TransStatus transStatus = TransStatus.from(result.transStatus());
        log.info("3DS session {} for payment {}: transStatus={} gatewayState={}",
                session.getId(), command.paymentId(), transStatus, result.gatewayState());

        if (transStatus.challengeRequired()) {
            String creq = result.base64EncodedCReq() != null ? result.base64EncodedCReq()
                    : ChallengeRequestFactory.build(result.threeDsServerTransId(), result.acsTransId(),
                    command.browserInfo().challengeWindowSize(), result.messageVersion());
            session.requireChallenge(result.acsUrl(), creq);
            session = repository.save(session);
            return new ThreeDsStartResult(session.getId(), true, toChallenge(session));
        }

        session.markFrictionless();
        session = repository.save(session);
        return new ThreeDsStartResult(session.getId(), false, null);
    }

    @Override
    public Optional<ThreeDsChallenge> pendingChallenge(String sessionId) {
        return repository.findById(sessionId)
                .filter(s -> s.isAwaitingChallenge(Instant.now()))
                .map(this::toChallenge);
    }

    private ThreeDsChallenge toChallenge(ThreeDsSession session) {
        return new ThreeDsChallenge(urls.challengePageUrl(session.getId()), session.getAcsUrl(), session.getCreq());
    }
}
