package com.company.payintegration.payment.presentation.request;

import com.company.payintegration.shared.presentation.MoneyDto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateCardPaymentRequest(
        @NotBlank @Size(max = 64) String merchantOrderId,
        @NotBlank @Size(max = 64) String customerId,
        @NotNull @Valid MoneyDto amount,
        @NotNull @Valid CustomerDto customer,
        @NotNull @Valid CardDetailsDto card,
        @NotNull @Valid BrowserInfoDto browserInfo,
        @NotBlank @Size(max = 2048) String returnUrl,
        Boolean saveCard) {
}
