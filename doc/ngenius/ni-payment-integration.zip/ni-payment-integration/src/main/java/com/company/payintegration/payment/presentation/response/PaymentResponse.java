package com.company.payintegration.payment.presentation.response;

import com.company.payintegration.shared.presentation.MoneyDto;

import java.time.Instant;

public record PaymentResponse(
        String paymentId,
        String merchantOrderId,
        String status,
        MoneyDto amount,
        MoneyDto capturedAmount,
        MoneyDto refundedAmount,
        String gatewayOrderReference,
        String failureReason,
        NextActionDto nextAction,
        Instant createdAt,
        Instant updatedAt) {
}
