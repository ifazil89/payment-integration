package com.company.payintegration.savedcard.presentation;

import com.company.payintegration.savedcard.application.SavedCardService;
import com.company.payintegration.savedcard.domain.SavedCard;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.YearMonth;
import java.util.List;

@RestController
@RequestMapping("/api/v1/customers/{customerId}/saved-cards")
class SavedCardController {

    private final SavedCardService savedCards;

    SavedCardController(SavedCardService savedCards) {
        this.savedCards = savedCards;
    }

    @GetMapping
    List<SavedCardResponse> list(@PathVariable String customerId) {
        YearMonth now = savedCards.currentMonth();
        return savedCards.list(customerId).stream().map(card -> toResponse(card, now)).toList();
    }

    @DeleteMapping("/{savedCardId}")
    ResponseEntity<Void> delete(@PathVariable String customerId, @PathVariable String savedCardId) {
        savedCards.delete(customerId, savedCardId);
        return ResponseEntity.noContent().build();
    }

    private static SavedCardResponse toResponse(SavedCard card, YearMonth now) {
        return new SavedCardResponse(card.getId(), card.getMaskedPan(), card.getScheme(), card.getExpiry().toString(),
                card.getCardholderName(), card.isExpired(now), card.getCreatedAt());
    }
}
