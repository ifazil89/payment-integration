package com.company.payintegration.webhook;

import com.company.payintegration.payment.PaymentApi;
import com.company.payintegration.shared.infrastructure.ngenius.NgeniusProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * 1. ignore events for other outlets
 * 2. de-duplicate on eventId (N-Genius may deliver the same event twice)
 * 3. ask the payment feature to re-read the order from N-Genius
 *
 * Failures are recorded but never thrown: N-Genius does not retry anyway, and the
 * reconciliation job will pick the payment up.
 */
@Service
class ProcessWebhookService {

    private static final Logger log = LoggerFactory.getLogger(ProcessWebhookService.class);

    private final WebhookEventJpaRepository events;
    private final PaymentApi paymentApi;
    private final String outletId;

    ProcessWebhookService(WebhookEventJpaRepository events, PaymentApi paymentApi, NgeniusProperties properties) {
        this.events = events;
        this.paymentApi = paymentApi;
        this.outletId = properties.outletId();
    }

    void process(NgeniusWebhookPayload payload) {
        if (payload.eventId() == null || payload.orderReference() == null) {
            log.warn("Ignoring webhook without eventId or order reference: {}", payload.eventName());
            return;
        }
        if (payload.outletId() != null && !outletId.equals(payload.outletId())) {
            log.warn("Ignoring webhook {} for unknown outlet {}", payload.eventId(), payload.outletId());
            return;
        }

        WebhookEventEntity event;
        try {
            event = events.saveAndFlush(
                    new WebhookEventEntity(payload.eventId(), payload.eventName(), payload.orderReference()));
        } catch (DataIntegrityViolationException duplicate) {
            log.info("Duplicate webhook {} ignored", payload.eventId());
            return;
        }

        try {
            boolean found = paymentApi.refreshFromGateway(payload.orderReference());
            event.result = found ? "PAYMENT_REFRESHED" : "UNKNOWN_ORDER";
            log.info("Webhook {} {} for order {}: {}", payload.eventId(), payload.eventName(),
                    payload.orderReference(), event.result);
        } catch (RuntimeException ex) {
            event.result = "ERROR: " + ex.getClass().getSimpleName();
            log.error("Processing webhook {} failed", payload.eventId(), ex);
        }
        event.processedAt = Instant.now();
        events.save(event);
    }
}
