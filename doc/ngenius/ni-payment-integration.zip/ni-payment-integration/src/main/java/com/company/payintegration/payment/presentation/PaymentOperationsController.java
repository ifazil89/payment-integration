package com.company.payintegration.payment.presentation;

import com.company.payintegration.payment.application.CapturePaymentUseCase;
import com.company.payintegration.payment.application.RefundPaymentUseCase;
import com.company.payintegration.payment.application.ReversePaymentUseCase;
import com.company.payintegration.payment.presentation.request.CapturePaymentRequest;
import com.company.payintegration.payment.presentation.request.RefundPaymentRequest;
import com.company.payintegration.payment.presentation.response.PaymentResponse;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Operations on an existing payment: capture, reverse (void the authorisation), refund. */
@RestController
@RequestMapping("/api/v1/payments/{paymentId}")
class PaymentOperationsController {

    private final CapturePaymentUseCase capturePayment;
    private final ReversePaymentUseCase reversePayment;
    private final RefundPaymentUseCase refundPayment;

    PaymentOperationsController(CapturePaymentUseCase capturePayment, ReversePaymentUseCase reversePayment,
                                RefundPaymentUseCase refundPayment) {
        this.capturePayment = capturePayment;
        this.reversePayment = reversePayment;
        this.refundPayment = refundPayment;
    }

    @PostMapping("/capture")
    PaymentResponse capture(@PathVariable String paymentId,
                            @Valid @RequestBody(required = false) CapturePaymentRequest request) {
        var amount = request != null && request.amount() != null ? request.amount().toDomain() : null;
        return PaymentPresentationMapper.toResponse(capturePayment.execute(paymentId, amount));
    }

    @PostMapping("/reverse")
    PaymentResponse reverse(@PathVariable String paymentId) {
        return PaymentPresentationMapper.toResponse(reversePayment.execute(paymentId));
    }

    @PostMapping("/refunds")
    PaymentResponse refund(@PathVariable String paymentId, @Valid @RequestBody RefundPaymentRequest request) {
        return PaymentPresentationMapper.toResponse(refundPayment.execute(paymentId, request.amount().toDomain()));
    }
}
