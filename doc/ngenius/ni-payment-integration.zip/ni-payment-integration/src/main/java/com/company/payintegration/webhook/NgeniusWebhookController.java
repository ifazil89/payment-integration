package com.company.payintegration.webhook;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * PUBLIC endpoint registered in the N-Genius portal (and allow-listed by N-Genius).
 * Must answer 200/201 within 15 seconds; each event is sent only once.
 */
@RestController
class NgeniusWebhookController {

    private static final Logger log = LoggerFactory.getLogger(NgeniusWebhookController.class);

    private final WebhookSecretVerifier verifier;
    private final ProcessWebhookService processor;

    NgeniusWebhookController(WebhookSecretVerifier verifier, ProcessWebhookService processor) {
        this.verifier = verifier;
        this.processor = processor;
    }

    @PostMapping("/ngenius/webhooks")
    ResponseEntity<Void> receive(HttpServletRequest request, @RequestBody NgeniusWebhookPayload payload) {
        if (!verifier.isValid(request)) {
            log.warn("Rejected webhook with missing/invalid secret header from {}", request.getRemoteAddr());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        processor.process(payload);
        return ResponseEntity.ok().build();
    }
}
