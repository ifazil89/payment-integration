package com.company.payintegration.payment.presentation;

import com.company.payintegration.payment.application.CreateCardPaymentCommand;
import com.company.payintegration.payment.application.CreateSavedCardPaymentCommand;
import com.company.payintegration.payment.application.NewPaymentData;
import com.company.payintegration.payment.application.PaymentOutcome;
import com.company.payintegration.payment.application.port.CardData;
import com.company.payintegration.payment.application.port.CustomerDetails;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentMethodType;
import com.company.payintegration.payment.presentation.request.BrowserInfoDto;
import com.company.payintegration.payment.presentation.request.CardDetailsDto;
import com.company.payintegration.payment.presentation.request.CreateCardPaymentRequest;
import com.company.payintegration.payment.presentation.request.CreateSavedCardPaymentRequest;
import com.company.payintegration.payment.presentation.request.CustomerDto;
import com.company.payintegration.payment.presentation.response.NextActionDto;
import com.company.payintegration.payment.presentation.response.PaymentResponse;
import com.company.payintegration.shared.presentation.MoneyDto;
import com.company.payintegration.threeds.BrowserInfo;
import com.company.payintegration.threeds.ThreeDsChallenge;

/** JSON <-> application types. The only class that knows both sides. */
final class PaymentPresentationMapper {

    private PaymentPresentationMapper() {
    }

    static CreateCardPaymentCommand toCommand(String idempotencyKey, CreateCardPaymentRequest r) {
        NewPaymentData data = new NewPaymentData(idempotencyKey, r.merchantOrderId(), r.customerId(),
                r.amount().toDomain(), PaymentMethodType.CARD, Boolean.TRUE.equals(r.saveCard()),
                toCustomer(r.customer()), toBrowserInfo(r.browserInfo()), r.returnUrl());
        return new CreateCardPaymentCommand(data, toCard(r.card()));
    }

    static CreateSavedCardPaymentCommand toCommand(String idempotencyKey, CreateSavedCardPaymentRequest r) {
        NewPaymentData data = new NewPaymentData(idempotencyKey, r.merchantOrderId(), r.customerId(),
                r.amount().toDomain(), PaymentMethodType.SAVED_CARD, false,
                toCustomer(r.customer()), toBrowserInfo(r.browserInfo()), r.returnUrl());
        return new CreateSavedCardPaymentCommand(data, r.savedCardId(), r.cvv());
    }

    static PaymentResponse toResponse(PaymentOutcome outcome) {
        Payment p = outcome.payment();
        ThreeDsChallenge challenge = outcome.threeDsChallenge();
        NextActionDto nextAction = challenge == null ? null : new NextActionDto(NextActionDto.THREEDS_CHALLENGE,
                challenge.challengePageUrl(), challenge.acsUrl(), challenge.creq());
        return new PaymentResponse(
                p.getId(),
                p.getMerchantOrderId(),
                p.getStatus().name(),
                MoneyDto.from(p.getAmount()),
                MoneyDto.from(p.getCapturedAmount()),
                MoneyDto.from(p.getRefundedAmount()),
                p.getGatewayReference() != null ? p.getGatewayReference().orderReference() : null,
                p.getFailureReason(),
                nextAction,
                p.getCreatedAt(),
                p.getUpdatedAt());
    }

    static PaymentResponse toResponse(Payment payment) {
        return toResponse(PaymentOutcome.of(payment));
    }

    private static CustomerDetails toCustomer(CustomerDto c) {
        return new CustomerDetails(c.email(), c.firstName(), c.lastName());
    }

    private static CardData toCard(CardDetailsDto c) {
        return new CardData(c.pan(), c.expiry(), c.cvv(), c.cardholderName());
    }

    private static BrowserInfo toBrowserInfo(BrowserInfoDto b) {
        return new BrowserInfo(b.acceptHeader(), b.javaEnabled(), b.language(), b.timeZoneOffset(), b.userAgent(),
                b.colorDepth(), b.screenHeight(), b.screenWidth(), b.javascriptEnabled(), b.ip(),
                b.challengeWindowSize());
    }
}
