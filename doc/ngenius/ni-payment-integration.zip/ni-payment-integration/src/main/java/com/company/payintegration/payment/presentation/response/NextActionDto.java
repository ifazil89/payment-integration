package com.company.payintegration.payment.presentation.response;

/**
 * What the frontend must do next. type = THREEDS_CHALLENGE:
 *  - simplest: redirect the browser to redirectUrl (our page auto-posts creq to the ACS), or
 *  - render your own form: POST field "creq" to acsUrl (full page or iframe).
 */
public record NextActionDto(String type, String redirectUrl, String acsUrl, String creq) {

    public static final String THREEDS_CHALLENGE = "THREEDS_CHALLENGE";
}
