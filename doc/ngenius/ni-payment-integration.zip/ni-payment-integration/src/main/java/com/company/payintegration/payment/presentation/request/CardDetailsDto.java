package com.company.payintegration.payment.presentation.request;

import com.company.payintegration.shared.util.SensitiveDataMasker;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Raw card details (Direct API). PCI DSS: never log, never store. toString is masked so an
 * accidental log statement cannot leak them.
 */
public record CardDetailsDto(
        @NotBlank @Pattern(regexp = "\\d{12,19}", message = "must be 12-19 digits") String pan,
        @NotBlank @Pattern(regexp = "\\d{4}-(0[1-9]|1[0-2])", message = "must be YYYY-MM") String expiry,
        @NotBlank @Pattern(regexp = "\\d{3,4}", message = "must be 3-4 digits") String cvv,
        @NotBlank @Size(max = 100) String cardholderName) {

    @Override
    public String toString() {
        return "CardDetailsDto[pan=" + SensitiveDataMasker.maskPan(pan) + ", expiry=" + expiry + ", cvv=***]";
    }
}
