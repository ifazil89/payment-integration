package com.company.payintegration.payment.presentation.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CustomerDto(
        @NotBlank @Email @Size(max = 254) String email,
        @NotBlank @Size(max = 60) String firstName,
        @NotBlank @Size(max = 60) String lastName) {
}
