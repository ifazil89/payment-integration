package com.company.payintegration.payment.presentation.request;

import com.company.payintegration.shared.presentation.MoneyDto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record CreateSavedCardPaymentRequest(
        @NotBlank @Size(max = 64) String merchantOrderId,
        @NotBlank @Size(max = 64) String customerId,
        @NotNull @Valid MoneyDto amount,
        @NotNull @Valid CustomerDto customer,
        @NotBlank String savedCardId,
        @NotBlank @Pattern(regexp = "\\d{3,4}", message = "must be 3-4 digits") String cvv,
        @NotNull @Valid BrowserInfoDto browserInfo,
        @NotBlank @Size(max = 2048) String returnUrl) {

    @Override
    public String toString() {
        return "CreateSavedCardPaymentRequest[merchantOrderId=" + merchantOrderId + ", savedCardId=" + savedCardId
                + ", cvv=***]";
    }
}
