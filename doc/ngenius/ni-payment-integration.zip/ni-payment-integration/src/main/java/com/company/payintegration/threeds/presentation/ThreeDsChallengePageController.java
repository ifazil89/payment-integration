package com.company.payintegration.threeds.presentation;

import com.company.payintegration.threeds.ThreeDsChallenge;
import com.company.payintegration.threeds.application.GetChallengePageUseCase;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.HtmlUtils;

/**
 * PUBLIC page the frontend can redirect the shopper to (nextAction.redirectUrl).
 * It auto-submits the form {creq} to the bank's ACS, as EMV 3DS requires.
 * Frontends that prefer an iframe can post the creq to acsUrl themselves instead.
 */
@RestController
@RequestMapping("/ngenius/3ds/challenge")
class ThreeDsChallengePageController {

    private final GetChallengePageUseCase getChallengePage;

    ThreeDsChallengePageController(GetChallengePageUseCase getChallengePage) {
        this.getChallengePage = getChallengePage;
    }

    @GetMapping(path = "/{sessionId}", produces = MediaType.TEXT_HTML_VALUE)
    ResponseEntity<String> page(@PathVariable String sessionId) {
        return getChallengePage.execute(sessionId)
                .map(challenge -> ResponseEntity.ok()
                        .cacheControl(CacheControl.noStore())
                        .body(autoSubmitForm(challenge)))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.GONE)
                        .cacheControl(CacheControl.noStore())
                        .body("<!doctype html><html><body><p>This payment verification is no longer available.</p>"
                                + "</body></html>"));
    }

    private static String autoSubmitForm(ThreeDsChallenge challenge) {
        String acsUrl = HtmlUtils.htmlEscape(challenge.acsUrl());
        String creq = HtmlUtils.htmlEscape(challenge.creq());
        return """
                <!doctype html>
                <html lang="en">
                <head><meta charset="utf-8"><title>Verifying your card</title></head>
                <body onload="document.forms[0].submit()">
                  <p>Redirecting to your bank to verify the payment&hellip;</p>
                  <form method="POST" action="%s">
                    <input type="hidden" name="creq" value="%s">
                    <noscript><button type="submit">Continue</button></noscript>
                  </form>
                </body>
                </html>
                """.formatted(acsUrl, creq);
    }
}
