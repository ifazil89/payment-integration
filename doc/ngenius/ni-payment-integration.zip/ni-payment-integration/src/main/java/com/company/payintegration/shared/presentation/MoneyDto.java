package com.company.payintegration.shared.presentation;

import com.company.payintegration.shared.domain.Money;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.math.BigDecimal;

/** Amount in MAJOR units as our backend sends it: {"value": 125.50, "currency": "AED"}. */
public record MoneyDto(
        @NotNull @DecimalMin("0.001") BigDecimal value,
        @NotNull @Pattern(regexp = "[A-Z]{3}") String currency) {

    public Money toDomain() {
        return new Money(value, currency);
    }

    public static MoneyDto from(Money money) {
        return new MoneyDto(money.amount(), money.currency());
    }
}
