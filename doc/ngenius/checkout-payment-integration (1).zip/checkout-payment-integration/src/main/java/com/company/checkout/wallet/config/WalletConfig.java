package com.company.checkout.wallet.config;

import com.company.checkout.wallet.applepay.ApplePayCrypto;
import com.company.checkout.wallet.applepay.ApplePayDecryptor;
import com.company.checkout.wallet.applepay.ApplePayProperties;
import com.company.checkout.wallet.applepay.ApplePaySignatureVerifier;
import com.company.checkout.wallet.googlepay.GooglePayDecryptor;
import com.company.checkout.wallet.googlepay.GooglePayProperties;
import com.google.crypto.tink.apps.paymentmethodtoken.GooglePaymentsPublicKeysManager;
import com.google.crypto.tink.apps.paymentmethodtoken.PaymentMethodTokenRecipient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import tools.jackson.databind.ObjectMapper;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Clock;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds the wallet decryptors from "wallet.*" properties. Everything is checked at STARTUP: a missing
 * key, a broken certificate or a missing Apple root stops the app with a clear message instead of
 * failing the first payment. A wallet with enabled=false gets no decryptor (WALLET_NOT_ENABLED).
 */
@Configuration
@EnableConfigurationProperties({ApplePayProperties.class, GooglePayProperties.class})
@Slf4j
public class WalletConfig {

    @Bean
    @ConditionalOnProperty(name = "wallet.apple-pay.enabled", havingValue = "true", matchIfMissing = true)
    ApplePayDecryptor applePayDecryptor(ApplePayProperties properties, ResourceLoader resourceLoader,
                                        ObjectMapper objectMapper) throws Exception {
        require(properties.merchantIdentifier(), "wallet.apple-pay.merchant-identifier (APPLE_PAY_MERCHANT_ID)");

        Map<String, PrivateKey> keysByPublicKeyHash = new LinkedHashMap<>();
        List<ApplePayProperties.Key> keys = properties.keys() == null ? List.of() : properties.keys();
        for (ApplePayProperties.Key key : keys) {
            require(key.certificate(), "wallet.apple-pay.keys[].certificate (APPLE_PAY_CERTIFICATE)");
            require(key.privateKey(), "wallet.apple-pay.keys[].private-key (APPLE_PAY_PRIVATE_KEY)");
            X509Certificate certificate = certificate(decode(key.certificate()));
            String publicKeyHash = ApplePayCrypto.publicKeyHash(certificate.getPublicKey());
            keysByPublicKeyHash.put(publicKeyHash, ecPrivateKey(decode(key.privateKey())));
            log.info("Apple Pay key loaded: publicKeyHash {}, certificate valid until {}",
                    publicKeyHash, certificate.getNotAfter());
        }
        if (keysByPublicKeyHash.isEmpty()) {
            throw new IllegalStateException("Apple Pay is enabled but wallet.apple-pay.keys is empty");
        }

        Resource root = resourceLoader.getResource(properties.rootCaCertificate());
        if (!root.exists()) {
            throw new IllegalStateException("Apple Root CA - G3 not found at " + properties.rootCaCertificate()
                    + ". Download it from https://www.apple.com/certificateauthority/ (see README), "
                    + "or set wallet.apple-pay.enabled=false");
        }
        X509Certificate appleRoot;
        try (InputStream in = root.getInputStream()) {
            appleRoot = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(in);
        }
        log.info("Apple Pay root CA loaded: {}", appleRoot.getSubjectX500Principal().getName());

        ApplePaySignatureVerifier verifier =
                new ApplePaySignatureVerifier(appleRoot, properties.maxTokenAge(), Clock.systemUTC());
        return new ApplePayDecryptor(verifier, keysByPublicKeyHash,
                ApplePayCrypto.merchantIdentifierHash(properties.merchantIdentifier()), objectMapper);
    }

    @Bean
    @ConditionalOnProperty(name = "wallet.google-pay.enabled", havingValue = "true", matchIfMissing = true)
    GooglePayDecryptor googlePayDecryptor(GooglePayProperties properties, ObjectMapper objectMapper)
            throws GeneralSecurityException {
        require(properties.merchantId(), "wallet.google-pay.merchant-id (GOOGLE_PAY_MERCHANT_ID)");
        List<String> privateKeys = properties.privateKeys() == null ? List.of()
                : properties.privateKeys().stream().filter(k -> k != null && !k.isBlank()).toList();
        if (privateKeys.isEmpty()) {
            throw new IllegalStateException(
                    "Google Pay is enabled but wallet.google-pay.private-keys (GOOGLE_PAY_PRIVATE_KEYS) is empty");
        }

        PaymentMethodTokenRecipient.Builder builder = new PaymentMethodTokenRecipient.Builder()
                .fetchSenderVerifyingKeysWith(properties.environment() == GooglePayProperties.Environment.PRODUCTION
                        ? GooglePaymentsPublicKeysManager.INSTANCE_PRODUCTION
                        : GooglePaymentsPublicKeysManager.INSTANCE_TEST)
                .recipientId("merchant:" + properties.merchantId())
                .protocolVersion("ECv2");
        for (String privateKey : privateKeys) {
            builder.addRecipientPrivateKey(base64Pkcs8(privateKey));
        }
        PaymentMethodTokenRecipient recipient = builder.build();
        log.info("Google Pay decryption ready: environment {}, merchant {}, {} key(s)",
                properties.environment(), properties.merchantId(), privateKeys.size());
        return new GooglePayDecryptor(recipient::unseal, objectMapper, Clock.systemUTC());
    }

    // ------------------------------------------------------------------ key helpers

    private static void require(String value, String property) {
        if (value == null || value.isBlank()) {
            throw new IllegalStateException(property + " is not set (or switch the wallet off with enabled=false)");
        }
    }

    /** Accepts base64 DER, or PEM ("-----BEGIN ...-----" lines are removed). */
    static byte[] decode(String base64OrPem) {
        String body = base64OrPem.replaceAll("-----[A-Z ]+-----", "").replaceAll("\\s", "");
        return Base64.getDecoder().decode(body);
    }

    /** Tink wants base64 PKCS#8 without PEM armour. */
    private static String base64Pkcs8(String base64OrPem) {
        return Base64.getEncoder().encodeToString(decode(base64OrPem));
    }

    private static X509Certificate certificate(byte[] der) throws GeneralSecurityException {
        return (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(der));
    }

    private static PrivateKey ecPrivateKey(byte[] pkcs8) throws GeneralSecurityException {
        return KeyFactory.getInstance("EC").generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
    }
}
