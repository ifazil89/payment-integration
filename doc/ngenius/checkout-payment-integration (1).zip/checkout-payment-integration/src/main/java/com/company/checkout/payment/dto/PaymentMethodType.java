package com.company.checkout.payment.dto;

/**
 * How the shopper pays. Decides which part of {@link PaymentMethod} must be filled in.
 *
 *   CARD           paymentMethod.card          plain card (number, expiry, cvv) -> Checkout.com "card" source + 3DS
 *   NETWORK_TOKEN  paymentMethod.networkToken  VTS / MDES token + cryptogram   -> Checkout.com "network_token" source
 *   APPLE_PAY      paymentMethod.walletToken   encrypted Apple Pay token, decrypted here
 *   GOOGLE_PAY     paymentMethod.walletToken   encrypted Google Pay token, decrypted here
 */
public enum PaymentMethodType {
    CARD,
    NETWORK_TOKEN,
    APPLE_PAY,
    GOOGLE_PAY;

    public boolean isWallet() {
        return this == APPLE_PAY || this == GOOGLE_PAY;
    }
}
