package com.company.checkout.wallet;

import com.company.checkout.wallet.applepay.ApplePayDecryptor;
import com.company.checkout.wallet.googlepay.GooglePayDecryptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

/**
 * The one entry point: verify + decrypt a wallet token. A wallet switched off in configuration
 * (wallet.apple-pay.enabled / wallet.google-pay.enabled = false) has no decryptor bean.
 */
@Component
@Slf4j
public class WalletDecryptor {

    private final ApplePayDecryptor applePay;
    private final GooglePayDecryptor googlePay;

    public WalletDecryptor(ObjectProvider<ApplePayDecryptor> applePay, ObjectProvider<GooglePayDecryptor> googlePay) {
        this.applePay = applePay.getIfAvailable();
        this.googlePay = googlePay.getIfAvailable();
    }

    public DecryptedWalletCard decrypt(WalletType walletType, String walletToken) {
        long start = System.nanoTime();
        DecryptedWalletCard card = switch (walletType) {
            case APPLE_PAY -> require(applePay, walletType).decrypt(walletToken);
            case GOOGLE_PAY -> require(googlePay, walletType).decrypt(walletToken);
        };
        log.atInfo()
                .setMessage("Wallet token decrypted: {} {} card ****{} ({} ms)")
                .addArgument(walletType).addArgument(card.authMethod()).addArgument(card.last4())
                .addArgument((System.nanoTime() - start) / 1_000_000)
                .addKeyValue("wallet.type", walletType.name())
                .addKeyValue("wallet.auth_method", card.authMethod().name())
                .addKeyValue("wallet.transaction_id", card.walletTransactionId())
                .log();
        return card;
    }

    private static <T> T require(T decryptor, WalletType walletType) {
        if (decryptor == null) {
            throw new WalletDecryptionException(WalletDecryptionException.NOT_ENABLED,
                    walletType + " is not enabled", walletType + " decryptor is switched off in configuration");
        }
        return decryptor;
    }
}
