package com.company.checkout.payment.openapi;

import com.company.checkout.payment.dto.BillingInfo;
import com.company.checkout.payment.dto.CardDetails;
import com.company.checkout.payment.dto.NetworkTokenDetails;
import com.company.checkout.payment.dto.PaymentMethod;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.dto.PaymentResponse;
import com.company.checkout.payment.openapi.schema.BillingInfoSchema;
import com.company.checkout.payment.openapi.schema.CardDetailsSchema;
import com.company.checkout.payment.openapi.schema.NetworkTokenDetailsSchema;
import com.company.checkout.payment.openapi.schema.PaymentMethodSchema;
import com.company.checkout.payment.openapi.schema.PaymentRequestSchema;
import com.company.checkout.payment.openapi.schema.PaymentResponseSchema;
import org.springdoc.core.utils.SpringDocUtils;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * Payment DTO -> its documentation class: springdoc documents the right-hand class wherever the
 * left-hand one appears. New DTO = new Schema class + one line here (DocSchemaTest checks both).
 */
@Configuration
public class PaymentOpenApiConfig {

    public static final Map<Class<?>, Class<?>> DOC_SCHEMAS = Map.of(
            PaymentRequest.class, PaymentRequestSchema.class,
            PaymentMethod.class, PaymentMethodSchema.class,
            CardDetails.class, CardDetailsSchema.class,
            NetworkTokenDetails.class, NetworkTokenDetailsSchema.class,
            BillingInfo.class, BillingInfoSchema.class,
            PaymentResponse.class, PaymentResponseSchema.class);

    static {
        DOC_SCHEMAS.forEach((dto, schema) -> SpringDocUtils.getConfig().replaceWithClass(dto, schema));
    }
}
