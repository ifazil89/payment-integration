package com.company.checkout.wallet.applepay;

import com.company.checkout.wallet.WalletDecryptionException;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.Time;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder;

import java.security.cert.X509Certificate;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import java.util.HexFormat;

/**
 * Proves an Apple Pay token really comes from Apple and is fresh (Apple's "Payment Token Format
 * Reference", "Verify the signature"):
 *
 *   1. the detached PKCS#7 signature covers ephemeralPublicKey || data || transactionId || applicationData
 *   2. the leaf certificate carries OID 1.2.840.113635.100.6.29, the intermediate 1.2.840.113635.100.6.2.14
 *   3. leaf is signed by intermediate, intermediate by Apple Root CA - G3 (OUR copy, never the token's)
 *   4. the signer is the leaf, and the signature verifies with its key
 *   5. signing time is recent (max-token-age): an old token is a replay
 */
public class ApplePaySignatureVerifier {

    static final String LEAF_OID = "1.2.840.113635.100.6.29";
    static final String INTERMEDIATE_OID = "1.2.840.113635.100.6.2.14";
    private static final Duration CLOCK_SKEW = Duration.ofMinutes(1);

    private final X509Certificate appleRootCa;
    private final Duration maxTokenAge;
    private final Clock clock;

    public ApplePaySignatureVerifier(X509Certificate appleRootCa, Duration maxTokenAge, Clock clock) {
        this.appleRootCa = appleRootCa;
        this.maxTokenAge = maxTokenAge;
        this.clock = clock;
    }

    public void verify(ApplePayToken token) {
        Instant signedAt;
        try {
            CMSSignedData cms = new CMSSignedData(new CMSProcessableByteArray(signedContent(token)),
                    Base64.getDecoder().decode(token.signature()));

            Collection<SignerInformation> signers = cms.getSignerInfos().getSigners();
            if (signers.size() != 1) {
                throw WalletDecryptionException.invalid("expected 1 signer, found " + signers.size());
            }
            SignerInformation signer = signers.iterator().next();

            JcaX509CertificateConverter converter = new JcaX509CertificateConverter();
            X509Certificate leaf = null;
            X509Certificate intermediate = null;
            X509CertificateHolder leafHolder = null;
            for (X509CertificateHolder holder : cms.getCertificates().getMatches(null)) {
                X509Certificate certificate = converter.getCertificate(holder);
                if (certificate.getExtensionValue(LEAF_OID) != null) {
                    leaf = certificate;
                    leafHolder = holder;
                } else if (certificate.getExtensionValue(INTERMEDIATE_OID) != null) {
                    intermediate = certificate;
                }
            }
            if (leaf == null || intermediate == null) {
                throw WalletDecryptionException.invalid("Apple leaf or intermediate certificate missing");
            }
            if (!signer.getSID().match(leafHolder)) {
                throw WalletDecryptionException.invalid("token is not signed by the Apple leaf certificate");
            }

            Date signingTime = signingTime(signer);
            leaf.verify(intermediate.getPublicKey());
            intermediate.verify(appleRootCa.getPublicKey());
            leaf.checkValidity(signingTime);
            intermediate.checkValidity(signingTime);

            if (!signer.verify(new JcaSimpleSignerInfoVerifierBuilder().build(leaf))) {
                throw WalletDecryptionException.invalid("signature does not match the token content");
            }
            signedAt = signingTime.toInstant();
        } catch (WalletDecryptionException e) {
            throw e;
        } catch (Exception e) {
            throw WalletDecryptionException.invalid("signature verification failed: " + e.getMessage(), e);
        }

        Instant now = clock.instant();
        if (signedAt.isBefore(now.minus(maxTokenAge))) {
            throw WalletDecryptionException.expired("token signed at " + signedAt + ", older than " + maxTokenAge);
        }
        if (signedAt.isAfter(now.plus(CLOCK_SKEW))) {
            throw WalletDecryptionException.invalid("token signing time " + signedAt + " is in the future");
        }
    }

    /** ephemeralPublicKey || data || transactionId || applicationData (the last two hex, the first two base64). */
    static byte[] signedContent(ApplePayToken token) {
        ApplePayToken.Header header = token.header();
        byte[] applicationData = header.applicationData() == null || header.applicationData().isBlank()
                ? new byte[0] : HexFormat.of().parseHex(header.applicationData());
        return ApplePayCrypto.concat(
                Base64.getDecoder().decode(header.ephemeralPublicKey()),
                Base64.getDecoder().decode(token.data()),
                HexFormat.of().parseHex(header.transactionId()),
                applicationData);
    }

    private static Date signingTime(SignerInformation signer) {
        AttributeTable attributes = signer.getSignedAttributes();
        Attribute attribute = attributes == null ? null : attributes.get(CMSAttributes.signingTime);
        if (attribute == null) {
            throw WalletDecryptionException.invalid("signature has no signing time");
        }
        return Time.getInstance(attribute.getAttrValues().getObjectAt(0)).getDate();
    }
}
