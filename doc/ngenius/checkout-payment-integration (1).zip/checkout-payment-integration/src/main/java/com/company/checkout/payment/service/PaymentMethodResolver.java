package com.company.checkout.payment.service;

import com.company.checkout.cko.config.CkoProperties;
import com.company.checkout.common.exception.ApiException;
import com.company.checkout.common.exception.ApiException.FieldViolation;
import com.company.checkout.payment.dto.CardDetails;
import com.company.checkout.payment.dto.NetworkTokenDetails;
import com.company.checkout.payment.dto.PaymentMethod;
import com.company.checkout.payment.dto.PaymentMethodType;
import com.company.checkout.wallet.AuthMethod;
import com.company.checkout.wallet.DecryptedWalletCard;
import com.company.checkout.wallet.WalletDecryptor;
import com.company.checkout.wallet.WalletType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.ZoneOffset;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

/**
 * Checks the payment method and turns it into a {@link ResolvedPaymentMethod}:
 *
 *   CARD           Luhn + not expired -> card source with cvv; 3DS if cko.three-ds-for-cards (default true)
 *   NETWORK_TOKEN  not expired        -> network_token source (vts / mdes) with cryptogram, no 3DS
 *   APPLE_PAY      decrypt            -> network_token source (applepay), no 3DS
 *   GOOGLE_PAY     decrypt            -> CRYPTOGRAM_3DS: network_token (googlepay), no 3DS
 *                                        PAN_ONLY:       card source, 3DS
 *
 * Bean Validation already checked the fields inside card / networkToken. This class checks what the
 * annotations cannot: the part that matches the type is present, the others are not (400 VALIDATION_ERROR).
 */
@Component
@RequiredArgsConstructor
public class PaymentMethodResolver {

    private final WalletDecryptor walletDecryptor;
    private final CkoProperties ckoProperties;

    /** Structure only, no decryption: called before the idempotency check. */
    public void validate(PaymentMethod method) {
        List<FieldViolation> errors = new ArrayList<>();
        PaymentMethodType type = method.type();
        expect(errors, "paymentMethod.card", method.card() != null, type == PaymentMethodType.CARD, type);
        expect(errors, "paymentMethod.networkToken", method.networkToken() != null,
                type == PaymentMethodType.NETWORK_TOKEN, type);
        expect(errors, "paymentMethod.walletToken", method.walletToken() != null && !method.walletToken().isBlank(),
                type.isWallet(), type);
        if (type == PaymentMethodType.CARD && method.card() != null && !luhn(method.card().number())) {
            errors.add(new FieldViolation("paymentMethod.card.number", "is not a valid card number"));
        }
        if (!errors.isEmpty()) {
            throw ApiException.validation(errors);
        }
    }

    /** validate() must have passed. Decrypts wallet tokens; card data stays in memory only. */
    public ResolvedPaymentMethod resolve(PaymentMethod method) {
        return switch (method.type()) {
            case CARD -> fromCard(method.card());
            case NETWORK_TOKEN -> fromNetworkToken(method.networkToken());
            case APPLE_PAY -> fromWallet(walletDecryptor.decrypt(WalletType.APPLE_PAY, method.walletToken()));
            case GOOGLE_PAY -> fromWallet(walletDecryptor.decrypt(WalletType.GOOGLE_PAY, method.walletToken()));
        };
    }

    private ResolvedPaymentMethod fromCard(CardDetails card) {
        checkNotExpired(card.expiryMonth(), card.expiryYear(), "CARD_EXPIRED", "The card has expired");
        return new ResolvedPaymentMethod(PaymentMethodType.CARD, AuthMethod.PAN_ONLY, card.number(),
                card.expiryMonth(), card.expiryYear(), card.cvv(), null, null, null, blankToNull(card.name()),
                ckoProperties.threeDsForCards(), null, null, null);
    }

    private ResolvedPaymentMethod fromNetworkToken(NetworkTokenDetails token) {
        checkNotExpired(token.expiryMonth(), token.expiryYear(), "NETWORK_TOKEN_EXPIRED", "The network token has expired");
        return new ResolvedPaymentMethod(PaymentMethodType.NETWORK_TOKEN, AuthMethod.CRYPTOGRAM_3DS, token.token(),
                token.expiryMonth(), token.expiryYear(), null, token.cryptogram(), token.eci(),
                token.tokenType().name().toLowerCase(), null, false, null, null, null);
    }

    private static ResolvedPaymentMethod fromWallet(DecryptedWalletCard card) {
        boolean apple = card.walletType() == WalletType.APPLE_PAY;
        boolean panOnly = card.authMethod() == AuthMethod.PAN_ONLY;
        return new ResolvedPaymentMethod(
                apple ? PaymentMethodType.APPLE_PAY : PaymentMethodType.GOOGLE_PAY,
                card.authMethod(), card.pan(), card.expiryMonth(), card.expiryYear(), null,
                card.cryptogram(), card.eci(), panOnly ? null : (apple ? "applepay" : "googlepay"), null,
                panOnly, card.walletTransactionId(), card.amountMinor(), card.currencyNumeric());
    }

    // ------------------------------------------------------------------ checks

    /** present must equal required: "is required for type X" or "must not be sent for type X". */
    private static void expect(List<FieldViolation> errors, String field, boolean present, boolean required,
                               PaymentMethodType type) {
        if (required && !present) {
            errors.add(new FieldViolation(field, "is required for type " + type));
        } else if (!required && present) {
            errors.add(new FieldViolation(field, "must not be sent for type " + type));
        }
    }

    /** A card is valid until the end of its expiry month. */
    private void checkNotExpired(int month, int year, String code, String message) {
        if (YearMonth.of(year, month).isBefore(YearMonth.now(ZoneOffset.UTC))) {
            throw ApiException.unprocessable(code, message);
        }
    }

    /** Luhn (mod 10) check digit: catches typos before Checkout.com does. */
    static boolean luhn(String number) {
        if (number == null || number.isEmpty()) {
            return false;
        }
        int sum = 0;
        boolean doubleIt = false;
        for (int i = number.length() - 1; i >= 0; i--) {
            int digit = number.charAt(i) - '0';
            if (digit < 0 || digit > 9) {
                return false;
            }
            if (doubleIt) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            sum += digit;
            doubleIt = !doubleIt;
        }
        return sum % 10 == 0;
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
