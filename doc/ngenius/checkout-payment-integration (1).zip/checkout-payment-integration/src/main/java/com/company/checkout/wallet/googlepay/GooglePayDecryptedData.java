package com.company.checkout.wallet.googlepay;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The decrypted Google Pay message (ECv2 signedMessage, after Tink verified and decrypted it).
 *
 * @param messageExpiration milliseconds since epoch, as a string
 * @param messageId         unique per token
 * @param paymentMethod     "CARD"
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record GooglePayDecryptedData(
        String messageExpiration,
        String messageId,
        String paymentMethod,
        PaymentMethodDetails paymentMethodDetails) {

    /**
     * @param authMethod "CRYPTOGRAM_3DS" (DPAN + cryptogram) or "PAN_ONLY" (real card number, no cryptogram)
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record PaymentMethodDetails(
            String pan,
            Integer expirationMonth,
            Integer expirationYear,
            String authMethod,
            String cryptogram,
            String eciIndicator) {
    }

    @Override
    public String toString() {
        return "GooglePayDecryptedData[messageId=" + messageId + ", ***]";
    }
}
