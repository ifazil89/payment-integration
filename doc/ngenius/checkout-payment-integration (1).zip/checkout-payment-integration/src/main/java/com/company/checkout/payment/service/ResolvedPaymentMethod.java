package com.company.checkout.payment.service;

import com.company.checkout.payment.dto.PaymentMethodType;
import com.company.checkout.wallet.AuthMethod;

/**
 * Whatever the shopper paid with, reduced to what Checkout.com needs. Built by PaymentMethodResolver
 * (wallet tokens are decrypted there). Lives only in memory during one request: never stored, never logged
 * (toString shows last 4 digits only).
 *
 *   type           CARD / NETWORK_TOKEN / APPLE_PAY / GOOGLE_PAY (what the client sent)
 *   authMethod     CRYPTOGRAM_3DS -> Checkout.com "network_token" source (token + cryptogram)
 *                  PAN_ONLY       -> Checkout.com "card" source (number, cvv if any)
 *   tokenType      Checkout.com token_type for network tokens: vts, mdes, applepay, googlepay
 *   threeDs        ask Checkout.com for 3DS (plain cards if cko.three-ds-for-cards, Google Pay PAN_ONLY)
 *   walletTransactionId / walletAmountMinor / walletCurrencyNumeric   wallets only (one payment per token,
 *                  Apple Pay amount check)
 */
public record ResolvedPaymentMethod(
        PaymentMethodType type,
        AuthMethod authMethod,
        String number,
        int expiryMonth,
        int expiryYear,
        String cvv,
        String cryptogram,
        String eci,
        String tokenType,
        String cardholderName,
        boolean threeDs,
        String walletTransactionId,
        Long walletAmountMinor,
        String walletCurrencyNumeric) {

    public boolean isNetworkToken() {
        return authMethod == AuthMethod.CRYPTOGRAM_3DS;
    }

    public String last4() {
        return number == null || number.length() < 4 ? null : number.substring(number.length() - 4);
    }

    @Override
    public String toString() {
        return "ResolvedPaymentMethod[" + type + ", " + authMethod + ", number=****" + last4()
                + ", expiry=" + expiryMonth + "/" + expiryYear + ", cvv=" + (cvv == null ? null : "***")
                + ", cryptogram=" + (cryptogram == null ? null : "***") + ", eci=" + eci + ", tokenType=" + tokenType
                + ", threeDs=" + threeDs + ", walletTransactionId=" + walletTransactionId + "]";
    }
}
