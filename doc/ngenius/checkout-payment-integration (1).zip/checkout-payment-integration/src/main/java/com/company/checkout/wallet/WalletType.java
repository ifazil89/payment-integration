package com.company.checkout.wallet;

/** The wallet the shopper paid with. */
public enum WalletType {
    APPLE_PAY,
    GOOGLE_PAY
}
