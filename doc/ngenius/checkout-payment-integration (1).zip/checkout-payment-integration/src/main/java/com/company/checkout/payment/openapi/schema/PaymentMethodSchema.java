package com.company.checkout.payment.openapi.schema;

import com.company.checkout.payment.dto.PaymentMethodType;
import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for payment.dto.PaymentMethod (never instantiated). */
@Schema(name = "PaymentMethod", description = """
        How the shopper pays. Send exactly the part that belongs to `type`, nothing else:
        CARD -> `card`, NETWORK_TOKEN -> `networkToken`, APPLE_PAY / GOOGLE_PAY -> `walletToken`.""")
public record PaymentMethodSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = """
                CARD: plain card, sent to Checkout.com with 3DS (status CHALLENGE_REQUIRED). \
                NETWORK_TOKEN: VTS / MDES token + cryptogram, no 3DS. \
                APPLE_PAY / GOOGLE_PAY: encrypted wallet token, decrypted by this service.""")
        PaymentMethodType type,

        @Schema(description = "Required for CARD, must be absent otherwise")
        CardDetailsSchema card,

        @Schema(description = "Required for NETWORK_TOKEN, must be absent otherwise")
        NetworkTokenDetailsSchema networkToken,

        @Schema(maxLength = 20000, description = """
                Required for APPLE_PAY / GOOGLE_PAY, must be absent otherwise. The ENCRYPTED wallet token exactly \
                as the device returned it, as a string. Apple Pay: PKPaymentToken.paymentData (its JSON as a string, \
                or that JSON base64-encoded). Google Pay: paymentMethodData.tokenizationData.token (tokenization type \
                DIRECT). Never decrypt or change it before sending.""")
        String walletToken) {
}
