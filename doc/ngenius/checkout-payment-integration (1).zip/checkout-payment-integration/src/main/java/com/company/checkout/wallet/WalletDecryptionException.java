package com.company.checkout.wallet;

import lombok.Getter;

/**
 * The wallet token can't be used. The client gets {@code code} + a short public message (422);
 * the detailed reason (getMessage) is only logged: never tell a caller WHY a signature check failed.
 */
@Getter
public class WalletDecryptionException extends RuntimeException {

    public static final String INVALID = "WALLET_TOKEN_INVALID";
    public static final String EXPIRED = "WALLET_TOKEN_EXPIRED";
    public static final String UNSUPPORTED = "WALLET_TOKEN_UNSUPPORTED";
    public static final String NOT_ENABLED = "WALLET_NOT_ENABLED";
    public static final String AMOUNT_MISMATCH = "WALLET_AMOUNT_MISMATCH";

    private final String code;
    private final String publicMessage;

    public WalletDecryptionException(String code, String publicMessage, String detail) {
        super(detail);
        this.code = code;
        this.publicMessage = publicMessage;
    }

    public WalletDecryptionException(String code, String publicMessage, String detail, Throwable cause) {
        super(detail, cause);
        this.code = code;
        this.publicMessage = publicMessage;
    }

    public static WalletDecryptionException invalid(String detail) {
        return new WalletDecryptionException(INVALID, "The wallet token could not be verified or decrypted", detail);
    }

    public static WalletDecryptionException invalid(String detail, Throwable cause) {
        return new WalletDecryptionException(INVALID, "The wallet token could not be verified or decrypted", detail, cause);
    }

    public static WalletDecryptionException expired(String detail) {
        return new WalletDecryptionException(EXPIRED, "The wallet token has expired; ask the shopper to pay again", detail);
    }

    public static WalletDecryptionException unsupported(String detail) {
        return new WalletDecryptionException(UNSUPPORTED, "This kind of wallet token is not supported", detail);
    }
}
