package com.company.checkout.wallet;

/**
 * How the card is authenticated (stored per payment in auth_method). Used for every payment method:
 * CARD = PAN_ONLY (card + cvv, 3DS), NETWORK_TOKEN = CRYPTOGRAM_3DS. For wallets:
 *
 *   CRYPTOGRAM_3DS  device token (DPAN) + one-time cryptogram: sent to Checkout.com as a network token,
 *                   no 3DS needed (Apple Pay always; Google Pay on Android devices)
 *   PAN_ONLY        the real card number, no cryptogram (Google Pay cards saved in a Google account):
 *                   sent as a card WITH 3DS
 */
public enum AuthMethod {
    CRYPTOGRAM_3DS,
    PAN_ONLY
}
