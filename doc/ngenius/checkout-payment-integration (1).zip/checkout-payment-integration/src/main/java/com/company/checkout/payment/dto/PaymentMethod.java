package com.company.checkout.payment.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * How the shopper pays. Fill in exactly the part that belongs to the type:
 *
 *   { "type": "CARD",          "card":         { "number": .., "expiryMonth": .., "expiryYear": .., "cvv": .. } }
 *   { "type": "NETWORK_TOKEN", "networkToken": { "token": .., "tokenType": "VTS", .., "cryptogram": .. } }
 *   { "type": "APPLE_PAY",     "walletToken":  "<encrypted token as a string>" }
 *   { "type": "GOOGLE_PAY",    "walletToken":  "<encrypted token as a string>" }
 *
 * "Exactly the right part" is checked in PaymentMethodResolver (field errors like the annotations).
 *
 * @param walletToken the ENCRYPTED token exactly as the device returned it:
 *                    Apple Pay = PKPaymentToken.paymentData (JSON string, or that JSON base64-encoded),
 *                    Google Pay = paymentMethodData.tokenizationData.token (string)
 */
public record PaymentMethod(
        @NotNull PaymentMethodType type,
        @Valid CardDetails card,
        @Valid NetworkTokenDetails networkToken,
        @Size(max = 20000) String walletToken) {

    /** Never prints card data or the wallet token. */
    @Override
    public String toString() {
        return "PaymentMethod[type=" + type + ", card=" + card + ", networkToken=" + networkToken
                + ", walletToken=" + (walletToken == null ? null : "***") + "]";
    }
}
