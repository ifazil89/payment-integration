package com.company.checkout.common.exception;

import com.company.checkout.common.logging.LogFields;
import com.company.checkout.cko.exception.CkoException;
import com.company.checkout.wallet.WalletDecryptionException;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.method.ParameterErrors;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.method.annotation.HandlerMethodValidationException;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

/**
 * Every error -> ErrorResponse {code, message, correlationId, traceId, timestamp, errors}
 * (common/exception/ErrorResponse + ErrorDetail, documented by common/openapi/schema).
 *
 *   400 VALIDATION_ERROR / MALFORMED_REQUEST / MISSING_HEADER
 *   404, 409, 422         ApiException (its own status and code)
 *   422 WALLET_TOKEN_*    the wallet token could not be verified / decrypted / is expired
 *   502 GATEWAY_ERROR     Checkout.com server error, or our credentials/configuration were refused (401/403/404)
 *   503 GATEWAY_BUSY      Checkout.com rate limit (429): retry later with the same Idempotency-Key
 *   504 GATEWAY_TIMEOUT   Checkout.com did not answer: outcome UNKNOWN, check with GET /payments/{id}
 *   500 INTERNAL_ERROR
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ErrorResponse> invalidBody(MethodArgumentNotValidException ex) {
        List<ErrorDetail> errors = new ArrayList<>();
        ex.getBindingResult().getFieldErrors().forEach(e -> errors.add(detail(e.getField(), e.getDefaultMessage())));
        ex.getBindingResult().getGlobalErrors().forEach(e -> errors.add(detail(e.getObjectName(), e.getDefaultMessage())));
        return build(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", "Request validation failed", errors);
    }

    /** Spring MVC method validation (constraints on headers / parameters, and on the body in some setups). */
    @ExceptionHandler(HandlerMethodValidationException.class)
    ResponseEntity<ErrorResponse> invalidParameter(HandlerMethodValidationException ex) {
        List<ErrorDetail> errors = new ArrayList<>();
        ex.getParameterValidationResults().forEach(result -> {
            if (result instanceof ParameterErrors parameterErrors) {
                parameterErrors.getFieldErrors().forEach(e -> errors.add(detail(e.getField(), e.getDefaultMessage())));
            } else {
                String name = result.getMethodParameter().getParameterName();
                result.getResolvableErrors().forEach(e -> errors.add(detail(name, e.getDefaultMessage())));
            }
        });
        return build(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", "Request validation failed", errors);
    }

    /** Bean Validation on method parameters through an AOP proxy (@Validated). */
    @ExceptionHandler(ConstraintViolationException.class)
    ResponseEntity<ErrorResponse> constraintViolation(ConstraintViolationException ex) {
        List<ErrorDetail> errors = new ArrayList<>();
        ex.getConstraintViolations().forEach(v -> errors.add(detail(lastNode(v.getPropertyPath().toString()), v.getMessage())));
        return build(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", "Request validation failed", errors);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    ResponseEntity<ErrorResponse> unreadable(HttpMessageNotReadableException ex) {
        return build(HttpStatus.BAD_REQUEST, "MALFORMED_REQUEST",
                "Request body is not valid JSON or has a wrong value (e.g. unknown paymentMethod.type)", null);
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    ResponseEntity<ErrorResponse> missingHeader(MissingRequestHeaderException ex) {
        return build(HttpStatus.BAD_REQUEST, "MISSING_HEADER", "Header " + ex.getHeaderName() + " is required", null);
    }

    @ExceptionHandler(ApiException.class)
    ResponseEntity<ErrorResponse> api(ApiException ex) {
        List<ErrorDetail> errors = ex.getViolations().stream().map(v -> detail(v.field(), v.message())).toList();
        return build(ex.getStatus(), ex.getCode(), ex.getMessage(), errors);
    }

    /** Detailed reason is logged; the client only gets a stable code (never key or crypto details). */
    @ExceptionHandler(WalletDecryptionException.class)
    ResponseEntity<ErrorResponse> wallet(WalletDecryptionException ex) {
        log.atWarn().setMessage("Wallet token rejected: {} ({})").addArgument(ex.getCode()).addArgument(ex.getMessage())
                .addKeyValue("wallet.error", ex.getCode())
                .log();
        return build(HttpStatus.valueOf(422), ex.getCode(), ex.getPublicMessage(), null);
    }

    /** Checkout.com errors that reach here: everything except 422 on a payment (that becomes status FAILED). */
    @ExceptionHandler(CkoException.class)
    ResponseEntity<ErrorResponse> cko(CkoException ex) {
        log.atError().setMessage("Checkout.com error: {}").addArgument(ex.getMessage())
                .addKeyValue("cko.status_code", ex.getStatus())
                .addKeyValue("cko.request_id", ex.getRequestId())
                .addKeyValue("cko.error_codes", ex.getErrorCodes())
                .log();
        if (ex.getStatus() == 429) {
            return build(HttpStatus.SERVICE_UNAVAILABLE, "GATEWAY_BUSY",
                    "Checkout.com is rate limiting; retry later with the same Idempotency-Key", null);
        }
        if (ex.getStatus() == 422) {
            return build(HttpStatus.valueOf(422), "GATEWAY_REJECTED", "Checkout.com rejected the request", null);
        }
        return build(HttpStatus.BAD_GATEWAY, "GATEWAY_ERROR", "Checkout.com returned an error", null);
    }

    @ExceptionHandler(ResourceAccessException.class)
    ResponseEntity<ErrorResponse> timeout(ResourceAccessException ex) {
        log.error("Checkout.com did not answer: {}", ex.getMessage());
        return build(HttpStatus.GATEWAY_TIMEOUT, "GATEWAY_TIMEOUT",
                "Checkout.com did not answer; the outcome is unknown. Check it with GET /api/v1/payments/{paymentId}.", null);
    }

    /**
     * Everything else.
     * Spring MVC's own errors (404 no route, 405 wrong method, 415 wrong content type, ...) implement
     * Spring's interface org.springframework.web.ErrorResponse and keep their own HTTP status.
     * (Checked with instanceof on purpose: our API model is ALSO called ErrorResponse, and an
     * @ExceptionHandler(ErrorResponse.class) would pick the wrong one.)
     */
    @ExceptionHandler(Exception.class)
    ResponseEntity<ErrorResponse> unexpected(Exception ex) {
        if (ex instanceof org.springframework.web.ErrorResponse springError) {
            return build(springError.getStatusCode(), "REQUEST_ERROR", ex.getMessage(), null);
        }
        log.error("Unexpected error", ex);   // full stack trace; ECS puts it in error.stack_trace
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "Unexpected error", null);
    }

    // ------------------------------------------------------------------ helpers

    private static ResponseEntity<ErrorResponse> build(HttpStatusCode status, String code, String message,
                                                       List<ErrorDetail> errors) {
        if (status.is4xxClientError()) {
            log.atWarn().setMessage("Request rejected: {} {}").addArgument(code).addArgument(message)
                    .addKeyValue("error.code", code)
                    .addKeyValue("error.fields", errors == null ? List.of() : errors.stream().map(ErrorDetail::field).toList())
                    .log();
        }
        ErrorResponse body = new ErrorResponse(
                code,
                message,
                MDC.get(LogFields.CORRELATION_ID),
                MDC.get(LogFields.TRACE_ID),
                OffsetDateTime.now(ZoneOffset.UTC),
                errors == null || errors.isEmpty() ? null : errors);
        return ResponseEntity.status(status).body(body);
    }

    private static ErrorDetail detail(String field, String message) {
        return new ErrorDetail(field, message);
    }

    /** "createPayment.idempotencyKey" -> "idempotencyKey" */
    private static String lastNode(String path) {
        int dot = path.lastIndexOf('.');
        return dot < 0 ? path : path.substring(dot + 1);
    }
}
