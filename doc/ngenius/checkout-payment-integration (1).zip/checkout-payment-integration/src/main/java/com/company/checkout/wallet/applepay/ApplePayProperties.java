package com.company.checkout.wallet.applepay;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.time.Duration;
import java.util.List;

/**
 * "wallet.apple-pay.*"
 *
 * @param merchantIdentifier  the Apple merchant id, e.g. merchant.com.company.shop
 * @param rootCaCertificate   location of Apple Root CA - G3 ("classpath:..." or "file:...")
 * @param maxTokenAge         tokens signed longer ago are rejected
 * @param keys                Payment Processing Certificates + their private keys (two during a rotation)
 */
@ConfigurationProperties("wallet.apple-pay")
public record ApplePayProperties(
        @DefaultValue("true") boolean enabled,
        String merchantIdentifier,
        String rootCaCertificate,
        @DefaultValue("5m") Duration maxTokenAge,
        List<Key> keys) {

    /**
     * @param certificate base64 DER (or PEM) of the Payment Processing Certificate from Apple
     * @param privateKey  base64 (or PEM) PKCS#8 EC P-256 private key that belongs to it
     */
    public record Key(String certificate, String privateKey) {

        @Override
        public String toString() {
            return "Key[certificate=..., privateKey=***]";
        }
    }
}
