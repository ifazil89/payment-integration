package com.company.checkout.payment.service;

import com.company.checkout.cko.client.CkoClient;
import com.company.checkout.cko.config.CkoProperties;
import com.company.checkout.cko.dto.CkoPaymentResponse;
import com.company.checkout.cko.exception.CkoException;
import com.company.checkout.common.exception.ApiException;
import com.company.checkout.common.logging.LogFields;
import com.company.checkout.common.util.Amounts;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.dto.PaymentResponse;
import com.company.checkout.payment.entity.Payment;
import com.company.checkout.payment.mapper.PaymentCkoMapper;
import com.company.checkout.payment.mapper.PaymentMapper;
import com.company.checkout.payment.repository.PaymentRepository;
import com.company.checkout.payment.dto.PaymentMethod;
import com.company.checkout.wallet.WalletDecryptionException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Currency;
import java.util.HexFormat;
import java.util.Optional;

/**
 * Payments (plain card, network token, Apple Pay, Google Pay), step by step.
 *
 * POST /api/v1/payments
 *   1. Validate amount (decimals per currency) and the payment method's structure (+ Luhn for cards)
 *   2. Idempotency: same client + Idempotency-Key -> the existing payment (no decryption, no new charge)
 *   3. Resolve the payment method: card / network token as sent (not expired), wallets verified + decrypted
 *   4. Apple Pay: the amount in the token must be the amount requested
 *   5. Wallets: one payment per token (transaction id); then save the payment as CREATED
 *   6. Checkout.com POST /payments (auto capture), Cko-Idempotency-Key = our payment id
 *        NETWORK_TOKEN, Apple Pay, Google Pay CRYPTOGRAM_3DS -> network_token source (no 3DS)
 *        CARD -> card source + cvv (+ 3DS, cko.three-ds-for-cards); Google Pay PAN_ONLY -> card source + 3DS
 *   7. Save and return the status
 *
 * GET /api/v1/payments/{id}
 *   while the outcome can still change, ask Checkout.com again; otherwise answer from the database
 *
 * Card data (number, cvv, token, cryptogram) lives only in memory until step 6; never stored or logged.
 * Checkout.com 422 = refused -> FAILED (200). Other errors / timeout -> payment stays PENDING (502/503/504).
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository repository;
    private final PaymentMapper paymentMapper;
    private final PaymentCkoMapper ckoMapper;
    private final PaymentMethodResolver methodResolver;
    private final CkoClient ckoClient;
    private final CkoProperties ckoProperties;

    public PaymentResponse createPayment(String clientId, String idempotencyKey, PaymentRequest request) {
        // 1. Validate
        checkIdempotencyKey(idempotencyKey);
        String currency = request.amount().currency();
        BigDecimal amount = Amounts.normalize(request.amount().value(), currency);          // 422 INVALID_AMOUNT
        long amountMinor = Amounts.toMinorUnits(amount, currency);
        methodResolver.validate(request.paymentMethod());                                    // 400 VALIDATION_ERROR
        String requestHash = requestHash(request);

        // 2. Idempotency
        Optional<Payment> existing = repository.findByClientIdAndIdempotencyKey(clientId, idempotencyKey);
        if (existing.isPresent()) {
            return replay(existing.get(), requestHash);
        }

        // 3. Resolve (decrypt wallets)
        ResolvedPaymentMethod method = methodResolver.resolve(request.paymentMethod());

        // 4. Amount in the Apple Pay sheet = amount requested
        checkWalletAmount(method, amountMinor, currency);

        // 5. One payment per wallet token, then save CREATED
        if (method.walletTransactionId() != null && repository.existsByWalletTransactionId(method.walletTransactionId())) {
            throw ApiException.conflict("WALLET_TOKEN_ALREADY_USED", "This wallet token was already used for a payment");
        }
        Payment payment = paymentMapper.toEntity(request);
        payment.setAmount(amount);
        payment.start(clientId, idempotencyKey, requestHash, method.walletTransactionId(), method.authMethod(), method.last4());
        payment = insert(payment);

        try (MDC.MDCCloseable ignored = MDC.putCloseable(LogFields.PAYMENT_ID, payment.getId())) {
            log.atInfo()
                    .setMessage("Payment created: {} {} {} {} for order {}")
                    .addArgument(method.type()).addArgument(method.authMethod())
                    .addArgument(payment.getCurrency()).addArgument(payment.getAmount())
                    .addArgument(payment.getMerchantOrderId())
                    .addKeyValue("payment.method", method.type().name())
                    .addKeyValue("payment.auth_method", method.authMethod().name())
                    .addKeyValue("payment.three_ds", method.threeDs())
                    .addKeyValue("payment.amount", payment.getAmount().toPlainString())
                    .addKeyValue("payment.currency", payment.getCurrency())
                    .addKeyValue("payment.merchant_order_id", payment.getMerchantOrderId())
                    .addKeyValue("payment.idempotency_key", idempotencyKey)
                    .log();

            // 6. Checkout.com
            try {
                CkoPaymentResponse response = ckoClient.requestPayment(
                        ckoMapper.toPaymentRequest(request, method, payment.getId(), amountMinor, ckoProperties),
                        payment.getId());
                payment.applyProviderResult(ckoMapper.toResult(response));
            } catch (CkoException ex) {
                if (!ex.isUnprocessable()) {
                    throw ex;              // 401/403/429/5xx: payment stays CREATED (PENDING) -> 502 / 503
                }
                log.atWarn().setMessage("Checkout.com refused the payment: {} {}")
                        .addArgument(ex.getErrorType()).addArgument(ex.getErrorCodes())
                        .addKeyValue("cko.request_id", ex.getRequestId())
                        .addKeyValue("cko.error_codes", ex.getErrorCodes())
                        .log();
                payment.fail("Rejected by Checkout.com: " + ex.getErrorType() + " " + ex.getErrorCodes());
            } catch (ResourceAccessException ex) {
                log.error("No answer from Checkout.com, outcome unknown, payment stays PENDING: {}", ex.getMessage());
                throw ex;                  // 504; GET /payments/{id} or the Dashboard resolves it
            }

            // 7. Save and answer
            payment = repository.save(payment);
            logFinished(payment);
            return paymentMapper.toResponse(payment);
        }
    }

    public PaymentResponse getPayment(String clientId, String paymentId) {
        Payment payment = repository.findByIdAndClientId(paymentId, clientId)
                .orElseThrow(() -> ApiException.notFound("PAYMENT_NOT_FOUND", "No payment " + paymentId));

        try (MDC.MDCCloseable ignored = MDC.putCloseable(LogFields.PAYMENT_ID, payment.getId())) {
            if (payment.getState().needsRefresh() && payment.getCkoPaymentId() != null) {
                try {
                    CkoPaymentResponse response = ckoClient.getPayment(payment.getCkoPaymentId());
                    String before = payment.getState().name();
                    payment.applyProviderResult(ckoMapper.toResult(response));
                    payment = repository.save(payment);
                    log.info("Payment refreshed from Checkout.com: {} -> {}", before, payment.getState());
                } catch (CkoException | ResourceAccessException ex) {
                    // The stored status is still a valid answer; the next GET tries again.
                    log.warn("Could not refresh the payment from Checkout.com, returning the last known status: {}",
                            ex.getMessage());
                }
            }
            return paymentMapper.toResponse(payment);
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Apple Pay signs the amount the shopper approved; a different amount here is tampering or a bug. */
    private static void checkWalletAmount(ResolvedPaymentMethod method, long amountMinor, String currency) {
        if (method.walletAmountMinor() == null) {
            return;   // cards, network tokens and Google Pay tokens carry no amount
        }
        String currencyNumeric = String.format("%03d", Currency.getInstance(currency).getNumericCode());
        if (method.walletAmountMinor() != amountMinor || !currencyNumeric.equals(method.walletCurrencyNumeric())) {
            throw new WalletDecryptionException(WalletDecryptionException.AMOUNT_MISMATCH,
                    "The amount does not match the amount approved in the wallet",
                    "wallet " + method.walletAmountMinor() + " " + method.walletCurrencyNumeric()
                            + " vs request " + amountMinor + " " + currencyNumeric);
        }
    }

    /** Same Idempotency-Key: same request -> same answer; different request -> 409. */
    private PaymentResponse replay(Payment existing, String requestHash) {
        if (!existing.getRequestHash().equals(requestHash)) {
            throw ApiException.conflict("IDEMPOTENCY_KEY_REUSED",
                    "This Idempotency-Key was already used for a different request");
        }
        log.atInfo().setMessage("Idempotent replay of payment {} ({})")
                .addArgument(existing.getId()).addArgument(existing.getState())
                .addKeyValue(LogFields.PAYMENT_ID, existing.getId())
                .log();
        return paymentMapper.toResponse(existing);
    }

    private Payment insert(Payment payment) {
        try {
            return repository.saveAndFlush(payment);
        } catch (DataIntegrityViolationException ex) {
            // Same key or same wallet token at the same moment: the other request won.
            if (payment.getWalletTransactionId() != null
                    && repository.existsByWalletTransactionId(payment.getWalletTransactionId())) {
                throw ApiException.conflict("WALLET_TOKEN_ALREADY_USED", "This wallet token was already used for a payment");
            }
            throw ApiException.conflict("REQUEST_IN_PROGRESS", "A request with this Idempotency-Key is already being processed");
        }
    }

    private static void logFinished(Payment payment) {
        log.atInfo()
                .setMessage("Payment finished: {} (Checkout.com {} {})")
                .addArgument(payment.getState()).addArgument(payment.getCkoStatus()).addArgument(payment.getCkoResponseCode())
                .addKeyValue("payment.state", payment.getState().name())
                .addKeyValue("payment.cko_status", payment.getCkoStatus())
                .addKeyValue("payment.cko_payment_id", payment.getCkoPaymentId())
                .addKeyValue("payment.card_scheme", payment.getCardScheme())
                .log();
    }

    private static void checkIdempotencyKey(String key) {
        if (key == null || key.isBlank() || key.length() > 100) {
            throw ApiException.badRequest("MISSING_HEADER", "Idempotency-Key must be 1-100 characters");
        }
    }

    /** Fingerprint of the request. Card data / tokens go in only as a hash, and the result is a hash too. */
    private static String requestHash(PaymentRequest r) {
        return sha256(String.join("|", r.merchantOrderId(), r.paymentMethod().type().name(),
                r.amount().value().stripTrailingZeros().toPlainString(), r.amount().currency(),
                sha256(secretPart(r.paymentMethod()))));
    }

    /** What identifies the card / token in the request (validate() guarantees the right part is there). */
    private static String secretPart(PaymentMethod m) {
        return switch (m.type()) {
            case CARD -> m.card().number() + "|" + m.card().expiryMonth() + "/" + m.card().expiryYear();
            case NETWORK_TOKEN -> m.networkToken().token() + "|" + m.networkToken().cryptogram();
            case APPLE_PAY, GOOGLE_PAY -> m.walletToken();
        };
    }

    private static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
