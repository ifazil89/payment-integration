Put Apple Root CA - G3 here as AppleRootCA-G3.cer (DER), downloaded from Apple:
  https://www.apple.com/certificateauthority/   ->  "Apple Root CA - G3 Root"
It is public (not a secret) but must come from Apple, never from a token or a third party.
Or point APPLE_PAY_ROOT_CA to another location, e.g. file:/etc/payment/AppleRootCA-G3.cer
