package com.company.checkout.openapi;

import com.company.checkout.common.dto.Amount;
import com.company.checkout.common.openapi.OpenApiConfig;
import com.company.checkout.payment.dto.BillingInfo;
import com.company.checkout.payment.dto.CardDetails;
import com.company.checkout.payment.dto.NetworkTokenDetails;
import com.company.checkout.payment.dto.PaymentMethod;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.openapi.PaymentOpenApiConfig;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.RecordComponent;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * The DTOs carry no documentation; their doc twins (openapi/schema/*Schema) do. This test keeps
 * each pair identical, so the published API docs can't drift from the code:
 *
 *   - same field names, in the same order
 *   - same field types (a nested DTO must be documented by its own Schema class)
 *   - request DTOs: a field is @NotNull/@NotBlank exactly when its doc says REQUIRED
 *   - every DTO used inside a documented DTO is documented too
 */
class DocSchemaTest {

    /** All registrations, exactly as springdoc gets them. */
    private static final Map<Class<?>, Class<?>> DOCS = new HashMap<>();

    static {
        DOCS.putAll(OpenApiConfig.DOC_SCHEMAS);
        DOCS.putAll(PaymentOpenApiConfig.DOC_SCHEMAS);
    }

    /** DTOs we receive: Bean Validation and the documented "required" must agree. */
    private static final Set<Class<?>> REQUEST_DTOS =
            Set.of(PaymentRequest.class, PaymentMethod.class, CardDetails.class, NetworkTokenDetails.class,
                    BillingInfo.class, Amount.class);

    @Test
    void docSchemasMatchTheirDtos() throws Exception {
        List<String> problems = new ArrayList<>();

        for (Map.Entry<Class<?>, Class<?>> pair : DOCS.entrySet()) {
            Class<?> dto = pair.getKey();
            Class<?> doc = pair.getValue();
            RecordComponent[] dtoFields = dto.getRecordComponents();
            RecordComponent[] docFields = doc.getRecordComponents();

            List<String> dtoNames = names(dtoFields);
            List<String> docNames = names(docFields);
            if (!dtoNames.equals(docNames)) {
                problems.add(dto.getSimpleName() + " fields " + dtoNames + " but " + doc.getSimpleName() + " has " + docNames);
                continue;
            }

            for (int i = 0; i < dtoFields.length; i++) {
                String field = dto.getSimpleName() + "." + dtoFields[i].getName();
                Type dtoType = dtoFields[i].getGenericType();
                Type docType = docFields[i].getGenericType();
                if (!documentedAs(dtoType).equals(docType.getTypeName())) {
                    problems.add(field + " is " + dtoType.getTypeName() + ", documented as " + docType.getTypeName()
                            + " (expected " + documentedAs(dtoType) + ")");
                }

                if (REQUEST_DTOS.contains(dto)) {
                    Field dtoField = dto.getDeclaredField(dtoFields[i].getName());
                    boolean required = dtoField.isAnnotationPresent(NotNull.class) || dtoField.isAnnotationPresent(NotBlank.class);
                    Schema schema = doc.getDeclaredField(docFields[i].getName()).getAnnotation(Schema.class);
                    boolean documentedRequired = schema != null && schema.requiredMode() == Schema.RequiredMode.REQUIRED;
                    if (required != documentedRequired) {
                        problems.add(field + (required ? " is required but not documented as REQUIRED"
                                : " is optional but documented as REQUIRED"));
                    }
                }
            }
        }

        assertThat(problems).as("DTOs and their OpenAPI doc schemas differ").isEmpty();
    }

    @Test
    void everyNestedDtoIsDocumented() {
        List<String> missing = new ArrayList<>();
        for (Class<?> dto : DOCS.keySet()) {
            for (RecordComponent component : dto.getRecordComponents()) {
                Class<?> type = elementType(component.getGenericType());
                if (type.isRecord() && !DOCS.containsKey(type)) {
                    missing.add(dto.getSimpleName() + "." + component.getName() + " -> " + type.getSimpleName());
                }
            }
        }
        assertThat(missing).as("DTOs without a Schema class + replaceWithClass registration").isEmpty();
    }

    /** The type a doc schema must use for a DTO field: the DTO's doc twin, or the same type. */
    private static String documentedAs(Type dtoType) {
        if (dtoType instanceof ParameterizedType parameterized) {
            Type element = parameterized.getActualTypeArguments()[0];
            return parameterized.getRawType().getTypeName() + "<" + documentedAs(element) + ">";
        }
        Class<?> doc = DOCS.get((Class<?>) dtoType);
        return doc != null ? doc.getName() : dtoType.getTypeName();
    }

    private static Class<?> elementType(Type type) {
        if (type instanceof ParameterizedType parameterized) {
            return (Class<?>) parameterized.getActualTypeArguments()[0];
        }
        return (Class<?>) type;
    }

    private static List<String> names(RecordComponent[] components) {
        List<String> names = new ArrayList<>();
        for (RecordComponent component : components) {
            names.add(component.getName());
        }
        return names;
    }
}
