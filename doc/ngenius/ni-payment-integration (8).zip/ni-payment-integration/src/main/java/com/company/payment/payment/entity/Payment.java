package com.company.payment.payment.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * A payment. No card number and no CVV are ever stored here: only the masked PAN.
 *
 * Fields copied from the request (merchantOrderId, cardType, amount...) have setters, used by
 * PaymentMapper. Everything that changes during the flow goes through the methods at the bottom.
 */
@Entity
@Table(name = "payment")
public class Payment {

    @Id
    private String id;
    @Column(name = "client_id", nullable = false)
    private String clientId;
    @Column(name = "idempotency_key", nullable = false)
    private String idempotencyKey;
    /** Fingerprint of the request: the same Idempotency-Key with a different request is rejected. */
    @Column(name = "request_hash", nullable = false)
    private String requestHash;

    @Column(name = "merchant_order_id", nullable = false)
    private String merchantOrderId;
    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "card_type", nullable = false)
    private PaymentCardType cardType;
    @Column(name = "masked_pan")
    private String maskedPan;
    @Column(nullable = false, precision = 19, scale = 3)
    private BigDecimal amount;
    @Column(nullable = false, length = 3)
    private String currency;
    @Column(nullable = false)
    private String email;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(nullable = false)
    private PaymentState state;
    @Column(name = "failure_reason")
    private String failureReason;

    @Column(name = "ni_order_reference")
    private String niOrderReference;
    @Column(name = "ni_payment_reference")
    private String niPaymentReference;
    /** Last state reported by N-Genius (raw), for support. */
    @Column(name = "ni_state")
    private String niState;

    @Column(name = "threeds_trans_status")
    private String threeDsTransStatus;
    @Column(name = "threeds_acs_url")
    private String threeDsAcsUrl;
    /** Base64 challenge request, needed by the 3DS API when state = CHALLENGE_REQUIRED. */
    @Column(name = "threeds_creq")
    private String threeDsCreq;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Version
    private Long version;

    public Payment() {
        // for JPA and MapStruct
    }

    // ------------------------------------------------------------------ flow

    /** Before the first save. */
    public void start(String clientId, String idempotencyKey, String requestHash) {
        this.id = UUID.randomUUID().toString();
        this.clientId = clientId;
        this.idempotencyKey = idempotencyKey;
        this.requestHash = requestHash;
        this.state = PaymentState.CREATED;
        this.createdAt = Instant.now();
        this.updatedAt = this.createdAt;
    }

    public void orderCreated(String niOrderReference, String niPaymentReference) {
        this.niOrderReference = niOrderReference;
        this.niPaymentReference = niPaymentReference;
        touch();
    }

    /** Applies what N-Genius answered. An unknown N-Genius state keeps our current state. */
    public void niAnswered(String niState) {
        this.niState = niState;
        PaymentState mapped = PaymentState.fromNi(niState);
        if (mapped != null) {
            this.state = mapped;
        }
        touch();
    }

    public void challengeRequired(String niState, String transStatus, String acsUrl, String creq) {
        this.niState = niState;
        this.threeDsTransStatus = transStatus;
        this.threeDsAcsUrl = acsUrl;
        this.threeDsCreq = creq;
        this.state = PaymentState.CHALLENGE_REQUIRED;
        touch();
    }

    public void threeDsAuthenticated(String niState, String transStatus) {
        this.threeDsTransStatus = transStatus;
        niAnswered(niState);
    }

    public void fail(String reason) {
        this.state = PaymentState.FAILED;
        this.failureReason = reason;
        touch();
    }

    private void touch() {
        this.updatedAt = Instant.now();
    }

    // ------------------------------------------------------------------ set by PaymentMapper

    public void setMerchantOrderId(String merchantOrderId) { this.merchantOrderId = merchantOrderId; }
    public void setCardType(PaymentCardType cardType) { this.cardType = cardType; }
    public void setMaskedPan(String maskedPan) { this.maskedPan = maskedPan; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public void setCurrency(String currency) { this.currency = currency; }
    public void setEmail(String email) { this.email = email; }

    // ------------------------------------------------------------------ getters

    public String getId() { return id; }
    public String getClientId() { return clientId; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public String getRequestHash() { return requestHash; }
    public String getMerchantOrderId() { return merchantOrderId; }
    public PaymentCardType getCardType() { return cardType; }
    public String getMaskedPan() { return maskedPan; }
    public BigDecimal getAmount() { return amount; }
    public String getCurrency() { return currency; }
    public String getEmail() { return email; }
    public PaymentState getState() { return state; }
    public String getFailureReason() { return failureReason; }
    public String getNiOrderReference() { return niOrderReference; }
    public String getNiPaymentReference() { return niPaymentReference; }
    public String getNiState() { return niState; }
    public String getThreeDsTransStatus() { return threeDsTransStatus; }
    public String getThreeDsAcsUrl() { return threeDsAcsUrl; }
    public String getThreeDsCreq() { return threeDsCreq; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public Long getVersion() { return version; }
}
