package com.company.payment.payment.controller;

import com.company.payment.api.PaymentsApi;
import com.company.payment.payment.dto.PaymentRequest;
import com.company.payment.payment.dto.PaymentResponse;
import com.company.payment.common.security.ApiKeyFilter;
import com.company.payment.payment.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Implements PaymentsApi: the only class GENERATED from payment-api.yaml (target/generated-sources/openapi);
 * its methods use our own DTOs (payment/dto).
 * Path, headers and Bean Validation come from the interface; this class only hands over to PaymentService.
 * If the contract changes, the build regenerates the interface and @Override shows what to update.
 */
@RestController
public class PaymentController implements PaymentsApi {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @Override
    public ResponseEntity<PaymentResponse> createPayment(String idempotencyKey, PaymentRequest paymentRequest) {
        return ResponseEntity.ok(
                paymentService.createPayment(ApiKeyFilter.currentClientId(), idempotencyKey, paymentRequest));
    }
}
