# checkout-payment-integration

Apple Pay and Google Pay payments for downstream clients, processed by **Checkout.com**.

- **Decryption model:** this service verifies and decrypts the wallet token itself and sends the card data to Checkout.com.
- **Auto capture:** Checkout.com captures approved payments automatically.
- **APIs:** `POST /api/v1/payments` and `GET /api/v1/payments/{paymentId}`.

**Stack:**
- Spring Boot 4.1.1, Java 21, Lombok, MapStruct 1.6.3.
- Google Tink 1.15.0 for Google Pay, BouncyCastle 1.85.0 for Apple Pay signatures.
- Oracle (qa/prod) and H2 (local).
- OpenAPI docs built from code; OpenTelemetry tracing; ECS JSON logs.

> **PCI DSS:** decrypting wallet tokens yourself puts this service in **full PCI DSS scope**: it handles card numbers (DPAN/FPAN) and cryptograms in memory. Google requires a PCI Attestation of Compliance for the `DIRECT` integration. Keys are in properties for now (as agreed); move them to a vault/KMS/HSM before production (section 8).

---

## 1. Run

**Prerequisites:** JDK 21 and Maven 3.9+.

```bash
# Checkout.com sandbox (Dashboard -> Developers): your account's base URL, secret key, processing channel
export CKO_BASE_URL='https://<prefix>.api.sandbox.checkout.com'
export CKO_SECRET_KEY='sk_sbox_...'
export CKO_PROCESSING_CHANNEL_ID='pc_...'

# Without wallet keys yet: switch both wallets off (requests then return 422 WALLET_NOT_ENABLED)
export APPLE_PAY_ENABLED=false GOOGLE_PAY_ENABLED=false

mvn clean verify          # build + all tests (no Checkout.com account or keys needed for the tests)
mvn spring-boot:run       # profile "local": H2 in memory, port 8086
```

- **Swagger UI:** `http://localhost:8086/swagger-ui.html` (API key `sandbox-key`).
- **OpenAPI file:** `/v3/api-docs.yaml`.
- **H2 console:** `/h2-console` (JDBC URL `jdbc:h2:mem:checkout`, user `sa`).
- **Example requests:** [`api-examples.http`](api-examples.http).

| Profile | Database | Checkout.com | Start |
|---|---|---|---|
| `local` (default) | H2 in memory | sandbox | `mvn spring-boot:run` |
| `qa` | **Oracle** (`DB_URL`, `DB_USERNAME`, `DB_PASSWORD`) | sandbox | `SPRING_PROFILES_ACTIVE=qa` |
| `prod` | Oracle | live | `SPRING_PROFILES_ACTIVE=prod` (no Swagger UI, 10 % trace sampling) |

**Database:** Flyway runs `db/migration/{vendor}/V1__payment.sql`, so `h2/` locally and `oracle/` in qa/prod. It's the same table, written in each database's own types.

---

## 2. Structure: feature first, then layers

```
com.company.checkout
├── payment/                          FEATURE: wallet payments (create + get)
│   ├── openapi/PaymentApi            interface: mappings + all API docs (@Operation, examples)
│   ├── openapi/schema/               doc-only twins of the DTOs (@Schema), registered in PaymentOpenApiConfig
│   ├── controller/PaymentController  implements PaymentApi
│   ├── dto/                          PaymentRequest, BillingInfo, PaymentResponse, PaymentStatus (records)
│   ├── service/PaymentService        the flow, step by step
│   ├── mapper/PaymentMapper          MapStruct: DTO <-> entity
│   ├── mapper/PaymentCkoMapper       MapStruct: request + decrypted card -> Checkout.com request; response -> ProviderResult
│   ├── entity/Payment, PaymentState, ProviderResult
│   └── repository/PaymentRepository
│
├── wallet/                           decryption, SHARED (future: recurring, tokens)
│   ├── WalletDecryptor               one entry point: decrypt(walletType, token) -> DecryptedWalletCard
│   ├── DecryptedWalletCard           DPAN/PAN, expiry, cryptogram, ECI (memory only, masked toString)
│   ├── applepay/                     ApplePayDecryptor, ApplePaySignatureVerifier (BouncyCastle), ApplePayCrypto (JDK)
│   ├── googlepay/                    GooglePayDecryptor (Tink)
│   └── config/WalletConfig           loads + checks keys at startup
│
├── cko/                              Checkout.com, SHARED (future: refund, void, webhooks)
│   ├── client/CkoClient              requestPayment, getPayment
│   ├── config/CkoConfig, CkoProperties   pooled HTTP client, timeouts, no auto-retry, Bearer secret key
│   ├── dto/                          CkoPaymentRequest, CkoSource, CkoPaymentResponse, CkoErrorResponse, …
│   └── exception/CkoException
│
└── common/                           from the N-Genius project: errors, logging + masking, API key, OpenAPI, Amounts
```

---

## 3. Flow

### `POST /api/v1/payments`

Headers:
- `X-Api-Key`
- `Idempotency-Key`
- `X-Correlation-Id` (optional)

| # | Step | Detail |
|---|---|---|
| 1 | Validate | Bean Validation; amount decimals per currency (422 `INVALID_AMOUNT`) |
| 2 | Idempotency | same client + key → stored payment (no decryption, no new charge); different request → 409 |
| 3 | **Decrypt** | Apple Pay EC_v1: signature (Apple Root CA G3, OIDs, signing time ≤ 5 min) → ECDH + KDF → AES-256-GCM. Google Pay ECv2: Tink verifies Google's signature chain + decrypts; expiry checked |
| 4 | Amount check | Apple Pay only: the amount in the token (what the shopper approved) must equal the request → else 422 `WALLET_AMOUNT_MISMATCH` |
| 5 | One payment per token | Apple `transactionId` / Google `messageId` is unique in the DB → 409 `WALLET_TOKEN_ALREADY_USED` |
| 6 | Checkout.com `POST /payments` | `capture: true`, `Cko-Idempotency-Key` = our payment id, `reference` = merchantOrderId |
| 7 | Save and answer | status from Checkout.com |

What step 6 sends, by wallet:

| Wallet / auth method | Checkout.com `source` | 3DS |
|---|---|---|
| Apple Pay (always `CRYPTOGRAM_3DS`) | `network_token`, `token_type: applepay`, DPAN + `cryptogram` + `eci` | no |
| Google Pay `CRYPTOGRAM_3DS` (device token) | `network_token`, `token_type: googlepay` | no |
| Google Pay `PAN_ONLY` (card in a Google account) | `card` (real card number) | **yes**: `3ds.enabled`, `success_url` / `failure_url` |

### `GET /api/v1/payments/{paymentId}`

- **Only the caller's own payments:** another client's payment returns 404.
- **While the outcome can still change** (`PENDING`, `CHALLENGE_REQUIRED`, `APPROVED`), it asks Checkout.com (`GET /payments/{id}`) and saves the new status. For example, `APPROVED` becomes `CAPTURED` after the auto capture.
- **If Checkout.com is unreachable,** it returns the last known status.

### Status and next step for the client

| status | Meaning | Next |
|---|---|---|
| `APPROVED` | authorised; Checkout.com captures it automatically | done (GET later shows `CAPTURED`) |
| `CAPTURED` | money taken | done |
| `CHALLENGE_REQUIRED` | Google Pay PAN_ONLY: 3DS needed | send the shopper to `threeDsRedirectUrl`; after the redirect back, `GET` the payment |
| `PENDING` | outcome not known yet | `GET` the payment |
| `DECLINED` / `FAILED` | refused (`failureReason`) | stop; a new attempt needs a new wallet token |
| `CANCELLED` / `REFUNDED` | changed later in Checkout.com | — |

### Errors

The body is `{code, message, correlationId, traceId, timestamp, errors[]}`.

| HTTP | code |
|---|---|
| 400 | `VALIDATION_ERROR`, `MALFORMED_REQUEST`, `MISSING_HEADER` |
| 401 | `UNAUTHORIZED` |
| 404 | `PAYMENT_NOT_FOUND` |
| 409 | `IDEMPOTENCY_KEY_REUSED`, `WALLET_TOKEN_ALREADY_USED`, `REQUEST_IN_PROGRESS` |
| 422 | `WALLET_TOKEN_INVALID`, `WALLET_TOKEN_EXPIRED`, `WALLET_TOKEN_UNSUPPORTED`, `WALLET_NOT_ENABLED`, `WALLET_AMOUNT_MISMATCH`, `INVALID_AMOUNT` |
| 502 | `GATEWAY_ERROR`: Checkout.com 5xx, or our key/channel refused (401/403/404: check configuration) |
| 503 | `GATEWAY_BUSY`: Checkout.com 429 |
| 504 | `GATEWAY_TIMEOUT`: outcome unknown; `GET` the payment |

- **Checkout.com 422 on a payment:** returned as `200` with `status: FAILED`.
- **Why a token failed:** the reason is logged, never returned. The client only gets the code.

---

## 4. Keys: Apple Pay

These steps follow Apple's developer process; check them against Apple's current documentation when you set up the account.

1. **Merchant ID:** Apple Developer → Certificates, IDs & Profiles → Identifiers → Merchant IDs (e.g. `merchant.com.company.shop`) → `APPLE_PAY_MERCHANT_ID`.
2. **Payment Processing Certificate:** create your own EC P-256 key and CSR, and upload the CSR under that merchant id:
   ```bash
   openssl ecparam -name prime256v1 -genkey -noout -out applepay.key
   openssl req -new -sha256 -key applepay.key -out applepay.csr -subj "/CN=company-applepay"
   # upload applepay.csr in the Apple Developer portal, download apple_pay.cer
   ```
3. **Into the properties:**
   ```bash
   export APPLE_PAY_PRIVATE_KEY=$(openssl pkcs8 -topk8 -nocrypt -in applepay.key -outform DER | base64 -w0)
   export APPLE_PAY_CERTIFICATE=$(base64 -w0 apple_pay.cer)
   ```
4. **Apple Root CA - G3:**
   - Download `AppleRootCA-G3.cer` from https://www.apple.com/certificateauthority/ into `src/main/resources/apple/`.
   - Or set `APPLE_PAY_ROOT_CA=file:/path/AppleRootCA-G3.cer`.
5. **Rotation:** Apple certificates expire. Add the new certificate and key as a second entry under `wallet.apple-pay.keys`, then activate it at Apple. The token's `publicKeyHash` picks the right key, and the startup log shows each certificate's expiry date.

The *Merchant Identity* certificate (Apple Pay on the web, "merchant validation") is separate and belongs to the frontend/session backend, not this service.

## 5. Keys: Google Pay

1. **Merchant id:** Google Pay & Wallet Console → `GOOGLE_PAY_MERCHANT_ID`. The `DIRECT` integration needs your PCI AOC uploaded there.
2. **Encryption key pair:**
   ```bash
   openssl ecparam -name prime256v1 -genkey -noout -out gpay.key
   openssl ec -in gpay.key -pubout -outform DER | base64 -w0      # public key: register it in the Console
   export GOOGLE_PAY_PRIVATE_KEYS=$(openssl pkcs8 -topk8 -nocrypt -in gpay.key -outform DER | base64 -w0)
   ```
3. **Frontend tokenization:**
   ```json
   "tokenizationSpecification": { "type": "DIRECT",
     "parameters": { "protocolVersion": "ECv2", "publicKey": "<base64 public key>" } },
   "allowedAuthMethods": ["PAN_ONLY", "CRYPTOGRAM_3DS"]
   ```
4. **Environment:** `GOOGLE_PAY_ENVIRONMENT=TEST` locally and in QA (prod profile sets `PRODUCTION`).
5. **Egress:** Tink downloads Google's signing keys over HTTPS, so allow outbound HTTPS to Google's payment key endpoint.
6. **Rotation:** list two private keys (comma-separated) while the new public key is rolled out.

## 6. Checkout.com setup

- **Ask your Checkout.com account manager to enable payments with pre-decrypted Apple Pay / Google Pay tokens** (`network_token` source with `token_type` `applepay`/`googlepay`) on your processing channel.
- **Configure the 3DS return pages:** `CKO_3DS_SUCCESS_URL` / `CKO_3DS_FAILURE_URL` (with `{paymentId}`) are **your frontend pages**. Checkout.com sends the shopper there after a Google Pay PAN_ONLY challenge, and the page then calls `GET /api/v1/payments/{paymentId}`.
- **Check the request shape in the sandbox** before relying on it:
  - field types (`expiry_month` and `expiry_year` are sent as numbers);
  - ECI handling for Mastercard tokens (no ECI is sent when the wallet gives none).

  Every Checkout.com request and response is logged (masked), so one sandbox run shows exactly what was sent.

---

## 7. Configuration

| Property | Env var | Notes |
|---|---|---|
| `cko.base-url` | `CKO_BASE_URL` | `https://{prefix}.api.sandbox.checkout.com` / `https://{prefix}.api.checkout.com` |
| `cko.secret-key` | `CKO_SECRET_KEY` | `sk_sbox_…` / `sk_…` |
| `cko.processing-channel-id` | `CKO_PROCESSING_CHANNEL_ID` | `pc_…` |
| `cko.capture` | — | `true` (auto capture) |
| `cko.three-ds-success-url` / `-failure-url` | `CKO_3DS_SUCCESS_URL` / `CKO_3DS_FAILURE_URL` | your pages, `{paymentId}` replaced |
| `cko.connect-timeout` / `response-timeout` / `connection-request-timeout` / `max-connections` | — | 3 s / 20 s / 1 s / 100 |
| `wallet.apple-pay.enabled` | `APPLE_PAY_ENABLED` | `false` = 422 `WALLET_NOT_ENABLED` |
| `wallet.apple-pay.merchant-identifier` | `APPLE_PAY_MERCHANT_ID` | |
| `wallet.apple-pay.keys[0].certificate` / `.private-key` | `APPLE_PAY_CERTIFICATE` / `APPLE_PAY_PRIVATE_KEY` | base64 (or PEM) |
| `wallet.apple-pay.root-ca-certificate` | `APPLE_PAY_ROOT_CA` | default `classpath:apple/AppleRootCA-G3.cer` |
| `wallet.apple-pay.max-token-age` | — | `5m` |
| `wallet.google-pay.enabled` | `GOOGLE_PAY_ENABLED` | |
| `wallet.google-pay.environment` | `GOOGLE_PAY_ENVIRONMENT` | `TEST` / `PRODUCTION` |
| `wallet.google-pay.merchant-id` | `GOOGLE_PAY_MERCHANT_ID` | |
| `wallet.google-pay.private-keys` | `GOOGLE_PAY_PRIVATE_KEYS` | base64 PKCS#8, comma-separated |
| `app.security.api-keys` | `API_KEYS` | `client1:key1,client2:key2` |
| `spring.datasource.*` | `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` | qa/prod: Oracle `jdbc:oracle:thin:@//host:1521/SERVICE` |

An enabled wallet with a missing key, a broken certificate or a missing Apple root **stops the app at startup** with a message naming the property.

## 8. Security notes

- **Never stored:**
  - the decrypted card number or DPAN;
  - the cryptogram;
  - the encrypted wallet token (only its SHA-256, inside the request hash).

  Stored are: last 4 digits, card scheme, wallet type and the wallet transaction id.
- **Never logged:**
  - the `walletToken`, `token`, `number`, `cryptogram`, Apple's `data`/`signature` and Google's `signedMessage`/`signedKey` are masked in every logged body;
  - `toString()` of the request, card and token objects is masked;
  - the build fails if a DPAN, cryptogram, token data or API key reaches the log (`PaymentApiTest.noCardDataOrWalletTokenInLogs`).
- **In memory:** Java `String`s can't be wiped reliably, so the decrypted card only lives for the length of one request, is never cached, and goes out of scope right after the Checkout.com call. The decrypted Apple Pay bytes are zeroed after parsing (Tink returns Google Pay's message as a `String`, which can't be zeroed).
- **Keys:** for now in properties (as agreed). Before production, move them to a vault or KMS: AWS KMS / Secrets Manager, Azure Key Vault, HashiCorp Vault, or an HSM. Only `WalletConfig` reads them, so that's the one class to change.
- **No automatic HTTP retries** to Checkout.com. `Cko-Idempotency-Key` makes a deliberate retry safe.

## 9. Tests

```bash
mvn test
```

| Test | Covers |
|---|---|
| `ApplePayDecryptorTest` | builds Apple Pay tokens the way Apple does (ECDH, KDF, AES-GCM, written independently) and decrypts them; wrong certificate, wrong merchant id, tampering, failed signature, RSA/EMV tokens |
| `GooglePayDecryptorTest` | Tink output → card: CRYPTOGRAM_3DS, PAN_ONLY, expired, missing cryptogram, unknown auth method, failed verification |
| `PaymentApiTest` | the whole API with wallet decryption and Checkout.com mocked: Apple Pay network token, Google Pay PAN_ONLY + 3DS, declined, Checkout.com 422/5xx/timeout, invalid token, amount mismatch, token reuse, idempotency, auth, GET refresh / fallback / 404, no card data in logs |
| `PaymentMappersTest` | Checkout.com request shapes, status mapping, response handling |
| `SensitiveDataMaskerTest`, `DocSchemaTest`, `ApiDocsTest` | masking, API docs match the DTOs, generated OpenAPI |

**Testing with real wallets.** The unit tests can't create Apple- or Google-signed tokens. The signature checks run for real only with real tokens:
- **Apple Pay:** a sandbox tester account on a device with your Payment Processing Certificate.
- **Google Pay:** the TEST environment with your registered public key.

Send one of each to the QA environment before go-live; the logs show each step (decrypted, sent, Checkout.com status).

## 10. Next steps

- **Webhooks:** Checkout.com notifications (captured, refunded, chargeback) instead of polling with GET.
- **Reconciliation:** a job for payments stuck in `PENDING`.
- **Refund / void APIs:** `CkoClient` is ready to grow.
- **Production keys:** move them to a vault or KMS.
