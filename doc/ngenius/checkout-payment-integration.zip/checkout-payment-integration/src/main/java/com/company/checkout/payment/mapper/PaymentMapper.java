package com.company.checkout.payment.mapper;

import com.company.checkout.common.dto.Amount;
import com.company.checkout.common.util.Amounts;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.dto.PaymentResponse;
import com.company.checkout.payment.dto.PaymentStatus;
import com.company.checkout.payment.entity.Payment;
import com.company.checkout.payment.entity.PaymentState;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

/** API DTOs <-> Payment entity. MapStruct generates the implementation at compile time. */
@Mapper
public interface PaymentMapper {

    /** Only the request fields; ids, state and wallet/provider data are set by PaymentService. */
    @BeanMapping(unmappedTargetPolicy = ReportingPolicy.IGNORE)
    @Mapping(target = "amount", source = "amount.value")
    @Mapping(target = "currency", source = "amount.currency")
    @Mapping(target = "email", source = "billingInfo.email")
    Payment toEntity(PaymentRequest request);

    @Mapping(target = "paymentId", source = "id")
    @Mapping(target = "status", expression = "java(toStatus(payment.getState()))")
    @Mapping(target = "amount", expression = "java(toAmount(payment))")
    @Mapping(target = "providerPaymentId", source = "ckoPaymentId")
    @Mapping(target = "threeDsRedirectUrl", expression = "java(challengeUrl(payment))")
    PaymentResponse toResponse(Payment payment);

    /** Internal state -> API status. A plain switch: a new PaymentState not mapped here is a compile error. */
    default PaymentStatus toStatus(PaymentState state) {
        if (state == null) {
            return null;
        }
        return switch (state) {
            case CREATED, PENDING -> PaymentStatus.PENDING;
            case CHALLENGE_REQUIRED -> PaymentStatus.CHALLENGE_REQUIRED;
            case APPROVED -> PaymentStatus.APPROVED;
            case CAPTURED -> PaymentStatus.CAPTURED;
            case DECLINED -> PaymentStatus.DECLINED;
            case FAILED -> PaymentStatus.FAILED;
            case CANCELLED -> PaymentStatus.CANCELLED;
            case REFUNDED -> PaymentStatus.REFUNDED;
        };
    }

    /** Always with the currency's scale: 250.000 (from the DB) -> 250.00 for AED. */
    default Amount toAmount(Payment payment) {
        return new Amount(Amounts.normalize(payment.getAmount().stripTrailingZeros(), payment.getCurrency()),
                payment.getCurrency());
    }

    /** The 3DS page is only useful while the challenge is open. */
    default String challengeUrl(Payment payment) {
        return payment.getState() == PaymentState.CHALLENGE_REQUIRED ? payment.getThreeDsRedirectUrl() : null;
    }

    default OffsetDateTime toOffsetDateTime(Instant instant) {
        return instant == null ? null : instant.atOffset(ZoneOffset.UTC);
    }
}
