package com.company.checkout.wallet;

/**
 * How the card inside the wallet token is authenticated.
 *
 *   CRYPTOGRAM_3DS  device token (DPAN) + one-time cryptogram: sent to Checkout.com as a network token,
 *                   no 3DS needed (Apple Pay always; Google Pay on Android devices)
 *   PAN_ONLY        the real card number, no cryptogram (Google Pay cards saved in a Google account):
 *                   sent as a card WITH 3DS
 */
public enum AuthMethod {
    CRYPTOGRAM_3DS,
    PAN_ONLY
}
