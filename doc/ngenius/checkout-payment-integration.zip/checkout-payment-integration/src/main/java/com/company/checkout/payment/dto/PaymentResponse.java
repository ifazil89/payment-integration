package com.company.checkout.payment.dto;

import com.company.checkout.common.dto.Amount;
import com.company.checkout.wallet.WalletType;

import java.time.OffsetDateTime;

/**
 * The payment as the client sees it. Null fields are not sent.
 *
 * @param providerPaymentId  Checkout.com payment id (pay_...), for support and reconciliation
 * @param threeDsRedirectUrl only when status = CHALLENGE_REQUIRED
 */
public record PaymentResponse(
        String paymentId,
        String merchantOrderId,
        WalletType walletType,
        PaymentStatus status,
        Amount amount,
        String cardScheme,
        String cardLast4,
        String providerPaymentId,
        String threeDsRedirectUrl,
        String failureReason,
        OffsetDateTime createdAt,
        OffsetDateTime updatedAt) {
}
