package com.company.checkout.payment.openapi.schema;

import com.company.checkout.common.openapi.schema.AmountSchema;
import com.company.checkout.payment.dto.PaymentStatus;
import com.company.checkout.wallet.WalletType;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;

/** DOCUMENTATION ONLY for payment.dto.PaymentResponse (never instantiated). */
@Schema(name = "PaymentResponse")
public record PaymentResponseSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "7f3c2a9e-1b4d-4e8f-9a2b-3c4d5e6f7a8b",
                description = "Our payment id: use it with GET /api/v1/payments/{paymentId}")
        String paymentId,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "SO-1001")
        String merchantOrderId,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        WalletType walletType,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = """
                APPROVED / CAPTURED -> done (captured automatically); CHALLENGE_REQUIRED -> send the shopper to \
                threeDsRedirectUrl, then GET the payment; PENDING -> GET the payment; DECLINED / FAILED -> stop""")
        PaymentStatus status,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        AmountSchema amount,

        @Schema(example = "Visa")
        String cardScheme,

        @Schema(example = "4242", description = "Last 4 digits of the wallet's device card number (not the plastic card)")
        String cardLast4,

        @Schema(example = "pay_mbabizu24mvu3mela5njyhpit4",
                description = "Checkout.com payment id, for support and reconciliation")
        String providerPaymentId,

        @Schema(description = "Only when status = CHALLENGE_REQUIRED: the 3DS page to send the shopper to")
        String threeDsRedirectUrl,

        @Schema(description = "Why the payment was declined or failed", example = "Insufficient Funds (20051)")
        String failureReason,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "2026-11-18T19:40:01.412Z")
        OffsetDateTime createdAt,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "2026-11-18T19:40:02.104Z")
        OffsetDateTime updatedAt) {
}
