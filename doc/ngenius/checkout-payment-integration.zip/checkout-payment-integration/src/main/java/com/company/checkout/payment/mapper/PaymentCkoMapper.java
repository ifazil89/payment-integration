package com.company.checkout.payment.mapper;

import com.company.checkout.cko.config.CkoProperties;
import com.company.checkout.cko.dto.CkoAddress;
import com.company.checkout.cko.dto.CkoCustomer;
import com.company.checkout.cko.dto.CkoPaymentRequest;
import com.company.checkout.cko.dto.CkoPaymentResponse;
import com.company.checkout.cko.dto.CkoSource;
import com.company.checkout.cko.dto.CkoThreeDs;
import com.company.checkout.payment.dto.BillingInfo;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.entity.ProviderResult;
import com.company.checkout.wallet.AuthMethod;
import com.company.checkout.wallet.DecryptedWalletCard;
import com.company.checkout.wallet.WalletType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Map;

/**
 * Our request + decrypted wallet card -> Checkout.com POST /payments body, and Checkout.com's answer ->
 * ProviderResult. MapStruct generates the field mappings; the source choice is written out by hand.
 */
@Mapper
public interface PaymentCkoMapper {

    /**
     * CRYPTOGRAM_3DS (Apple Pay, most Google Pay) -> network_token source, no 3DS (the cryptogram proves it).
     * PAN_ONLY (Google Pay card on file in a Google account) -> card source + 3DS with success/failure URLs.
     */
    default CkoPaymentRequest toPaymentRequest(PaymentRequest request, DecryptedWalletCard card, String paymentId,
                                               long amountMinor, CkoProperties properties) {
        CkoAddress address = toAddress(request.billingInfo());
        boolean panOnly = card.authMethod() == AuthMethod.PAN_ONLY;
        CkoSource source = panOnly
                ? CkoSource.card(card.pan(), card.expiryMonth(), card.expiryYear(), fullName(request.billingInfo()), address)
                : CkoSource.networkToken(card.pan(), tokenType(card.walletType()), card.expiryMonth(), card.expiryYear(),
                        card.cryptogram(), card.eci(), address);
        return new CkoPaymentRequest(
                source,
                amountMinor,
                request.amount().currency(),
                request.merchantOrderId(),
                properties.capture(),
                properties.processingChannelId(),
                "Regular",
                toCustomer(request.billingInfo()),
                panOnly ? new CkoThreeDs(true) : null,
                panOnly ? properties.threeDsSuccessUrl(paymentId) : null,
                panOnly ? properties.threeDsFailureUrl(paymentId) : null,
                Map.of("payment_id", paymentId, "wallet_type", card.walletType().name()));
    }

    @Mapping(target = "addressLine1", source = "address")
    @Mapping(target = "zip", ignore = true)
    @Mapping(target = "country", source = "countryCode")
    CkoAddress toAddress(BillingInfo billingInfo);

    @Mapping(target = "name", expression = "java(fullName(billingInfo))")
    CkoCustomer toCustomer(BillingInfo billingInfo);

    @Mapping(target = "providerPaymentId", source = "id")
    @Mapping(target = "redirectUrl", expression = "java(response.redirectUrl().orElse(null))")
    @Mapping(target = "cardScheme", source = "source.scheme")
    @Mapping(target = "cardLast4", source = "source.last4")
    ProviderResult toResult(CkoPaymentResponse response);

    default String fullName(BillingInfo billingInfo) {
        return billingInfo == null ? null : (billingInfo.firstName() + " " + billingInfo.lastName()).trim();
    }

    default String tokenType(WalletType walletType) {
        return walletType == WalletType.APPLE_PAY ? "applepay" : "googlepay";
    }
}
