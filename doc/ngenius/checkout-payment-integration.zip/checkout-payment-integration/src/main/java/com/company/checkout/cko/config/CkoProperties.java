package com.company.checkout.cko.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.time.Duration;

/**
 * "cko.*" Checkout.com settings.
 *
 * @param baseUrl              https://{prefix}.api.sandbox.checkout.com or https://{prefix}.api.checkout.com
 * @param secretKey            sk_sbox_... / sk_... sent as "Authorization: Bearer"
 * @param processingChannelId  pc_... (required by Checkout.com on every payment)
 * @param capture              true = Checkout.com captures approved payments automatically
 * @param threeDsSuccessUrl    where Checkout.com sends the shopper after a successful 3DS challenge ({paymentId})
 * @param threeDsFailureUrl    ... after a failed one
 */
@ConfigurationProperties("cko")
public record CkoProperties(
        String baseUrl,
        String secretKey,
        String processingChannelId,
        @DefaultValue("true") boolean capture,
        String threeDsSuccessUrl,
        String threeDsFailureUrl,
        @DefaultValue("3s") Duration connectTimeout,
        @DefaultValue("20s") Duration responseTimeout,
        @DefaultValue("1s") Duration connectionRequestTimeout,
        @DefaultValue("100") int maxConnections) {

    public String threeDsSuccessUrl(String paymentId) {
        return threeDsSuccessUrl.replace("{paymentId}", paymentId);
    }

    public String threeDsFailureUrl(String paymentId) {
        return threeDsFailureUrl.replace("{paymentId}", paymentId);
    }

    @Override
    public String toString() {
        return "CkoProperties[baseUrl=" + baseUrl + ", secretKey=***, processingChannelId=" + processingChannelId
                + ", capture=" + capture + "]";
    }
}
