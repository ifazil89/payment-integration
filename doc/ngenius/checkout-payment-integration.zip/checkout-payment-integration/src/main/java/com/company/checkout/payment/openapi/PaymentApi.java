package com.company.checkout.payment.openapi;

import com.company.checkout.common.exception.ErrorResponse;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.dto.PaymentResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import static com.company.checkout.payment.openapi.PaymentApiExamples.*;

/**
 * The payment API contract: HTTP mapping + OpenAPI documentation, in one place.
 * PaymentController implements it and contains no documentation; the DTOs contain none either.
 */
@Tag(name = "Payments", description = "Apple Pay and Google Pay payments, captured automatically")
@RequestMapping(path = "/api/v1/payments", produces = MediaType.APPLICATION_JSON_VALUE)
public interface PaymentApi {

    @Operation(
            operationId = "createPayment",
            summary = "Pay with an Apple Pay or Google Pay token",
            description = """
                    1. Verifies and decrypts the wallet token on our side (Apple Pay EC_v1, Google Pay ECv2).
                    2. Apple Pay: checks that `amount` is the amount the shopper approved in the wallet.
                    3. Sends the payment to Checkout.com with **auto capture**:
                       Apple Pay and Google Pay `CRYPTOGRAM_3DS` as a network token (no 3DS needed);
                       Google Pay `PAN_ONLY` as a card **with 3DS** (status `CHALLENGE_REQUIRED` + `threeDsRedirectUrl`).

                    A wallet token pays once. The same `Idempotency-Key` returns the same payment: never charged twice.""",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(required = true, content = @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = PaymentRequest.class),
                    examples = {
                            @ExampleObject(name = "applePay", summary = "Apple Pay", value = APPLE_PAY_REQUEST),
                            @ExampleObject(name = "googlePay", summary = "Google Pay", value = GOOGLE_PAY_REQUEST)})),
            parameters = @Parameter(name = "X-Correlation-Id", in = ParameterIn.HEADER, required = false,
                    description = "Optional. Returned in every response and logged on every line.",
                    schema = @Schema(type = "string", maxLength = 64, pattern = "^[A-Za-z0-9._-]{1,64}$"),
                    example = "demo-1"),
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Processed. The outcome is in `status` (also for DECLINED / FAILED).",
                            content = @Content(schema = @Schema(implementation = PaymentResponse.class), examples = {
                                    @ExampleObject(name = "approved", value = APPROVED),
                                    @ExampleObject(name = "challengeRequired", summary = "Google Pay PAN_ONLY",
                                            value = CHALLENGE_REQUIRED),
                                    @ExampleObject(name = "declined", value = DECLINED)})),
                    @ApiResponse(responseCode = "400", description = "VALIDATION_ERROR, MALFORMED_REQUEST, MISSING_HEADER",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class), examples = {
                                    @ExampleObject(name = "validationError", value = VALIDATION_ERROR),
                                    @ExampleObject(name = "missingHeader", value = MISSING_HEADER)})),
                    @ApiResponse(responseCode = "401", description = "Missing or invalid X-Api-Key",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                                    examples = @ExampleObject(name = "unauthorized", value = UNAUTHORIZED))),
                    @ApiResponse(responseCode = "409",
                            description = "IDEMPOTENCY_KEY_REUSED, WALLET_TOKEN_ALREADY_USED, REQUEST_IN_PROGRESS",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class), examples = {
                                    @ExampleObject(name = "keyReused", value = IDEMPOTENCY_KEY_REUSED),
                                    @ExampleObject(name = "tokenUsed", value = WALLET_TOKEN_ALREADY_USED)})),
                    @ApiResponse(responseCode = "422", description = """
                            WALLET_TOKEN_INVALID, WALLET_TOKEN_EXPIRED, WALLET_TOKEN_UNSUPPORTED, WALLET_NOT_ENABLED, \
                            WALLET_AMOUNT_MISMATCH, INVALID_AMOUNT""",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class), examples = {
                                    @ExampleObject(name = "tokenInvalid", value = WALLET_TOKEN_INVALID),
                                    @ExampleObject(name = "tokenExpired", value = WALLET_TOKEN_EXPIRED),
                                    @ExampleObject(name = "amountMismatch", value = WALLET_AMOUNT_MISMATCH),
                                    @ExampleObject(name = "invalidAmount", value = INVALID_AMOUNT)})),
                    @ApiResponse(responseCode = "500", description = "INTERNAL_ERROR",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                                    examples = @ExampleObject(name = "internalError", value = INTERNAL_ERROR))),
                    @ApiResponse(responseCode = "502", description = "GATEWAY_ERROR - Checkout.com error or configuration",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                                    examples = @ExampleObject(name = "gatewayError", value = GATEWAY_ERROR))),
                    @ApiResponse(responseCode = "503", description = "GATEWAY_BUSY - Checkout.com rate limit",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                                    examples = @ExampleObject(name = "gatewayBusy", value = GATEWAY_BUSY))),
                    @ApiResponse(responseCode = "504", description = "GATEWAY_TIMEOUT - outcome UNKNOWN; GET the payment",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                                    examples = @ExampleObject(name = "gatewayTimeout", value = GATEWAY_TIMEOUT)))})
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<PaymentResponse> createPayment(
            @Parameter(description = "Unique per payment attempt. Reuse the same value when retrying the same attempt.",
                    schema = @Schema(minLength = 1, maxLength = 100), example = "SO-1001-attempt-1")
            @RequestHeader("Idempotency-Key") String idempotencyKey,
            @Valid @RequestBody PaymentRequest paymentRequest);

    @Operation(
            operationId = "getPayment",
            summary = "Get a payment (current status)",
            description = """
                    Returns the payment. While its outcome can still change (`PENDING`, `CHALLENGE_REQUIRED`, `APPROVED`), \
                    the current status is fetched from Checkout.com first: e.g. `CAPTURED` after the auto capture, or \
                    the result of a 3DS challenge. If Checkout.com can't be reached, the last known status is returned.""",
            parameters = @Parameter(name = "X-Correlation-Id", in = ParameterIn.HEADER, required = false,
                    schema = @Schema(type = "string", maxLength = 64), example = "demo-2"),
            responses = {
                    @ApiResponse(responseCode = "200", description = "The payment",
                            content = @Content(schema = @Schema(implementation = PaymentResponse.class), examples = {
                                    @ExampleObject(name = "captured", value = CAPTURED),
                                    @ExampleObject(name = "approved", value = APPROVED)})),
                    @ApiResponse(responseCode = "401", description = "Missing or invalid X-Api-Key",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                                    examples = @ExampleObject(name = "unauthorized", value = UNAUTHORIZED))),
                    @ApiResponse(responseCode = "404", description = "PAYMENT_NOT_FOUND (or another client's payment)",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class),
                                    examples = @ExampleObject(name = "notFound", value = NOT_FOUND)))})
    @GetMapping("/{paymentId}")
    ResponseEntity<PaymentResponse> getPayment(
            @Parameter(description = "Our payment id, from the create response", example = "7f3c2a9e-1b4d-4e8f-9a2b-3c4d5e6f7a8b")
            @PathVariable("paymentId") String paymentId);
}
