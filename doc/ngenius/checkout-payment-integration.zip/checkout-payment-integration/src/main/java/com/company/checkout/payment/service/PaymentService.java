package com.company.checkout.payment.service;

import com.company.checkout.cko.client.CkoClient;
import com.company.checkout.cko.config.CkoProperties;
import com.company.checkout.cko.dto.CkoPaymentResponse;
import com.company.checkout.cko.exception.CkoException;
import com.company.checkout.common.exception.ApiException;
import com.company.checkout.common.logging.LogFields;
import com.company.checkout.common.util.Amounts;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.dto.PaymentResponse;
import com.company.checkout.payment.entity.Payment;
import com.company.checkout.payment.mapper.PaymentCkoMapper;
import com.company.checkout.payment.mapper.PaymentMapper;
import com.company.checkout.payment.repository.PaymentRepository;
import com.company.checkout.wallet.DecryptedWalletCard;
import com.company.checkout.wallet.WalletDecryptionException;
import com.company.checkout.wallet.WalletDecryptor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Currency;
import java.util.HexFormat;
import java.util.Optional;

/**
 * Wallet payments, step by step.
 *
 * POST /api/v1/payments
 *   1. Validate amount (decimals per currency)
 *   2. Idempotency: same client + Idempotency-Key -> the existing payment (no decryption, no new charge)
 *   3. Verify + decrypt the wallet token (Apple Pay EC_v1 / Google Pay ECv2)
 *   4. Apple Pay: the amount in the token must be the amount requested
 *   5. One payment per wallet token (transaction id), then save the payment as CREATED
 *   6. Checkout.com POST /payments (auto capture), Cko-Idempotency-Key = our payment id
 *        CRYPTOGRAM_3DS -> network_token source; Google Pay PAN_ONLY -> card source + 3DS
 *   7. Save and return the status
 *
 * GET /api/v1/payments/{id}
 *   while the outcome can still change, ask Checkout.com again; otherwise answer from the database
 *
 * The decrypted card lives only in memory during step 6; it is never stored or logged.
 * Checkout.com 422 = refused -> FAILED (200). Other errors / timeout -> payment stays PENDING (502/503/504).
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository repository;
    private final PaymentMapper paymentMapper;
    private final PaymentCkoMapper ckoMapper;
    private final WalletDecryptor walletDecryptor;
    private final CkoClient ckoClient;
    private final CkoProperties ckoProperties;

    public PaymentResponse createPayment(String clientId, String idempotencyKey, PaymentRequest request) {
        // 1. Validate
        checkIdempotencyKey(idempotencyKey);
        String currency = request.amount().currency();
        BigDecimal amount = Amounts.normalize(request.amount().value(), currency);          // 422 INVALID_AMOUNT
        long amountMinor = Amounts.toMinorUnits(amount, currency);
        String requestHash = requestHash(request);

        // 2. Idempotency
        Optional<Payment> existing = repository.findByClientIdAndIdempotencyKey(clientId, idempotencyKey);
        if (existing.isPresent()) {
            return replay(existing.get(), requestHash);
        }

        // 3. Decrypt
        DecryptedWalletCard card = walletDecryptor.decrypt(request.walletType(), request.walletToken());

        // 4. Amount in the Apple Pay sheet = amount requested
        checkWalletAmount(card, amountMinor, currency);

        // 5. One payment per token, then save CREATED
        if (card.walletTransactionId() != null && repository.existsByWalletTransactionId(card.walletTransactionId())) {
            throw ApiException.conflict("WALLET_TOKEN_ALREADY_USED", "This wallet token was already used for a payment");
        }
        Payment payment = paymentMapper.toEntity(request);
        payment.setAmount(amount);
        payment.start(clientId, idempotencyKey, requestHash, card.walletTransactionId(), card.authMethod(), card.last4());
        payment = insert(payment);

        try (MDC.MDCCloseable ignored = MDC.putCloseable(LogFields.PAYMENT_ID, payment.getId())) {
            log.atInfo()
                    .setMessage("Payment created: {} {} {} {} for order {}")
                    .addArgument(request.walletType()).addArgument(card.authMethod())
                    .addArgument(payment.getCurrency()).addArgument(payment.getAmount())
                    .addArgument(payment.getMerchantOrderId())
                    .addKeyValue("payment.wallet_type", request.walletType().name())
                    .addKeyValue("payment.auth_method", card.authMethod().name())
                    .addKeyValue("payment.amount", payment.getAmount().toPlainString())
                    .addKeyValue("payment.currency", payment.getCurrency())
                    .addKeyValue("payment.merchant_order_id", payment.getMerchantOrderId())
                    .addKeyValue("payment.idempotency_key", idempotencyKey)
                    .log();

            // 6. Checkout.com
            try {
                CkoPaymentResponse response = ckoClient.requestPayment(
                        ckoMapper.toPaymentRequest(request, card, payment.getId(), amountMinor, ckoProperties),
                        payment.getId());
                payment.applyProviderResult(ckoMapper.toResult(response));
            } catch (CkoException ex) {
                if (!ex.isUnprocessable()) {
                    throw ex;              // 401/403/429/5xx: payment stays CREATED (PENDING) -> 502 / 503
                }
                log.atWarn().setMessage("Checkout.com refused the payment: {} {}")
                        .addArgument(ex.getErrorType()).addArgument(ex.getErrorCodes())
                        .addKeyValue("cko.request_id", ex.getRequestId())
                        .addKeyValue("cko.error_codes", ex.getErrorCodes())
                        .log();
                payment.fail("Rejected by Checkout.com: " + ex.getErrorType() + " " + ex.getErrorCodes());
            } catch (ResourceAccessException ex) {
                log.error("No answer from Checkout.com, outcome unknown, payment stays PENDING: {}", ex.getMessage());
                throw ex;                  // 504; GET /payments/{id} or the Dashboard resolves it
            }

            // 7. Save and answer
            payment = repository.save(payment);
            logFinished(payment);
            return paymentMapper.toResponse(payment);
        }
    }

    public PaymentResponse getPayment(String clientId, String paymentId) {
        Payment payment = repository.findByIdAndClientId(paymentId, clientId)
                .orElseThrow(() -> ApiException.notFound("PAYMENT_NOT_FOUND", "No payment " + paymentId));

        try (MDC.MDCCloseable ignored = MDC.putCloseable(LogFields.PAYMENT_ID, payment.getId())) {
            if (payment.getState().needsRefresh() && payment.getCkoPaymentId() != null) {
                try {
                    CkoPaymentResponse response = ckoClient.getPayment(payment.getCkoPaymentId());
                    String before = payment.getState().name();
                    payment.applyProviderResult(ckoMapper.toResult(response));
                    payment = repository.save(payment);
                    log.info("Payment refreshed from Checkout.com: {} -> {}", before, payment.getState());
                } catch (CkoException | ResourceAccessException ex) {
                    // The stored status is still a valid answer; the next GET tries again.
                    log.warn("Could not refresh the payment from Checkout.com, returning the last known status: {}",
                            ex.getMessage());
                }
            }
            return paymentMapper.toResponse(payment);
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Apple Pay signs the amount the shopper approved; a different amount here is tampering or a bug. */
    private static void checkWalletAmount(DecryptedWalletCard card, long amountMinor, String currency) {
        if (card.amountMinor() == null) {
            return;   // Google Pay tokens carry no amount
        }
        String currencyNumeric = String.format("%03d", Currency.getInstance(currency).getNumericCode());
        if (card.amountMinor() != amountMinor || !currencyNumeric.equals(card.currencyNumeric())) {
            throw new WalletDecryptionException(WalletDecryptionException.AMOUNT_MISMATCH,
                    "The amount does not match the amount approved in the wallet",
                    "wallet " + card.amountMinor() + " " + card.currencyNumeric()
                            + " vs request " + amountMinor + " " + currencyNumeric);
        }
    }

    /** Same Idempotency-Key: same request -> same answer; different request -> 409. */
    private PaymentResponse replay(Payment existing, String requestHash) {
        if (!existing.getRequestHash().equals(requestHash)) {
            throw ApiException.conflict("IDEMPOTENCY_KEY_REUSED",
                    "This Idempotency-Key was already used for a different request");
        }
        log.atInfo().setMessage("Idempotent replay of payment {} ({})")
                .addArgument(existing.getId()).addArgument(existing.getState())
                .addKeyValue(LogFields.PAYMENT_ID, existing.getId())
                .log();
        return paymentMapper.toResponse(existing);
    }

    private Payment insert(Payment payment) {
        try {
            return repository.saveAndFlush(payment);
        } catch (DataIntegrityViolationException ex) {
            // Same key or same wallet token at the same moment: the other request won.
            if (payment.getWalletTransactionId() != null
                    && repository.existsByWalletTransactionId(payment.getWalletTransactionId())) {
                throw ApiException.conflict("WALLET_TOKEN_ALREADY_USED", "This wallet token was already used for a payment");
            }
            throw ApiException.conflict("REQUEST_IN_PROGRESS", "A request with this Idempotency-Key is already being processed");
        }
    }

    private static void logFinished(Payment payment) {
        log.atInfo()
                .setMessage("Payment finished: {} (Checkout.com {} {})")
                .addArgument(payment.getState()).addArgument(payment.getCkoStatus()).addArgument(payment.getCkoResponseCode())
                .addKeyValue("payment.state", payment.getState().name())
                .addKeyValue("payment.cko_status", payment.getCkoStatus())
                .addKeyValue("payment.cko_payment_id", payment.getCkoPaymentId())
                .addKeyValue("payment.card_scheme", payment.getCardScheme())
                .log();
    }

    private static void checkIdempotencyKey(String key) {
        if (key == null || key.isBlank() || key.length() > 100) {
            throw ApiException.badRequest("MISSING_HEADER", "Idempotency-Key must be 1-100 characters");
        }
    }

    /** Fingerprint of the request. The wallet token is only hashed, never stored. */
    private static String requestHash(PaymentRequest r) {
        return sha256(String.join("|", r.merchantOrderId(), r.walletType().name(),
                r.amount().value().stripTrailingZeros().toPlainString(), r.amount().currency(),
                sha256(r.walletToken())));
    }

    private static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
