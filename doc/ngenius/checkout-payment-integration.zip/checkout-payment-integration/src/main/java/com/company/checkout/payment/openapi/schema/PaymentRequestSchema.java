package com.company.checkout.payment.openapi.schema;

import com.company.checkout.common.openapi.schema.AmountSchema;
import com.company.checkout.wallet.WalletType;
import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for payment.dto.PaymentRequest (never instantiated). */
@Schema(name = "PaymentRequest")
public record PaymentRequestSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, minLength = 1, maxLength = 64, example = "SO-1001",
                description = "Your order id (sent to Checkout.com as reference)")
        String merchantOrderId,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "APPLE_PAY or GOOGLE_PAY")
        WalletType walletType,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, minLength = 1, maxLength = 20000, description = """
                The ENCRYPTED wallet token exactly as the device returned it, as a string.
                Apple Pay: PKPaymentToken.paymentData (its JSON as a string, or that JSON base64-encoded).
                Google Pay: paymentMethodData.tokenizationData.token (already a string; tokenization type DIRECT).
                Never decrypt or change it before sending.""")
        String walletToken,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED,
                description = "Must equal the amount shown in the Apple Pay / Google Pay sheet")
        AmountSchema amount,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        BillingInfoSchema billingInfo) {
}
