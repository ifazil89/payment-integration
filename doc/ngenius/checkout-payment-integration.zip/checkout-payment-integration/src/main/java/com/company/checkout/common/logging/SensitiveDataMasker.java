package com.company.checkout.common.logging;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;
import java.util.StringJoiner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Makes payloads and headers safe to log (PCI DSS: no full card number, never a CVV or cryptogram).
 *
 *   card numbers  "pan" / "number" / "applicationPrimaryAccountNumber" -> first 6 + last 4 ("411111******1111")
 *   secrets       cvv, token (the wallet DPAN sent to Checkout.com), cryptogram, walletToken (the encrypted
 *                 wallet token), Apple/Google token parts (data, signature, signedMessage, signedKey),
 *                 OAuth and password fields                                            -> "***"
 *   headers       Authorization, Proxy-Authorization, X-Api-Key, Cookie, Set-Cookie   -> "***"
 *
 * Works on raw JSON text (also on invalid or cut-off JSON), so it never needs to parse the body.
 * A new API with a new secret = add its field name to SECRET_FIELDS (the regex is built from the lists).
 */
@RequiredArgsConstructor
public class SensitiveDataMasker {

    static final String MASK = "***";

    private static final Set<String> PAN_FIELDS = Set.of("pan", "number", "applicationprimaryaccountnumber");
    private static final Set<String> SECRET_FIELDS = Set.of(
            "cvv", "token", "cardtoken", "cryptogram", "onlinepaymentcryptogram",
            "wallettoken", "data", "signature", "signedmessage", "signedkey",
            "access_token", "refresh_token", "client_secret", "password");
    private static final Set<String> SECRET_HEADERS =
            Set.of("authorization", "proxy-authorization", "x-api-key", "cookie", "set-cookie");

    /** "field" : "string value"  or  "field" : 12345  (a string cut off at the end is matched too). */
    private static final Pattern JSON_FIELD = Pattern.compile(
            "\"(" + String.join("|", PAN_FIELDS) + "|" + String.join("|", SECRET_FIELDS) + ")\"(\\s*:\\s*)"
                    + "(\"(?:[^\"\\\\]|\\\\.)*(?:\"|$)|-?\\d+)",
            Pattern.CASE_INSENSITIVE);

    private final LoggingProperties properties;

    /** Body for the log: masked, cut to the max length; binary content is not logged. */
    public String body(byte[] content, String contentType) {
        if (!properties.logBodies()) {
            return "[not logged]";
        }
        if (content == null || content.length == 0) {
            return "";
        }
        if (!isText(contentType)) {
            return "[" + content.length + " bytes " + contentType + "]";
        }
        return truncate(maskJson(new String(content, StandardCharsets.UTF_8)));
    }

    public String maskJson(String json) {
        if (json == null || json.isEmpty()) {
            return json;
        }
        Matcher matcher = JSON_FIELD.matcher(json);
        return matcher.replaceAll(match -> {
            String field = match.group(1);
            String value = match.group(3);
            String masked = PAN_FIELDS.contains(field.toLowerCase(Locale.ROOT)) ? maskPan(unquote(value)) : MASK;
            return Matcher.quoteReplacement("\"" + field + "\"" + match.group(2) + "\"" + masked + "\"");
        });
    }

    public String headers(HttpHeaders headers) {
        StringJoiner joiner = new StringJoiner(", ", "{", "}");
        headers.forEach((name, values) -> joiner.add(name + "=" + headerValue(name, String.join(",", values))));
        return joiner.toString();
    }

    public String headerValue(String name, String value) {
        return SECRET_HEADERS.contains(name.toLowerCase(Locale.ROOT)) ? MASK : value;
    }

    /** 4111111111111111 -> 411111******1111; too short to be a card number -> *** */
    static String maskPan(String pan) {
        String digits = pan.replaceAll("\\D", "");
        if (digits.length() < 10) {
            return MASK;
        }
        return digits.substring(0, 6) + "*".repeat(digits.length() - 10) + digits.substring(digits.length() - 4);
    }

    private String truncate(String text) {
        int max = properties.maxBodyLength();
        return text.length() <= max ? text : text.substring(0, max) + "...[truncated, " + text.length() + " chars]";
    }

    private static String unquote(String value) {
        String result = value.startsWith("\"") ? value.substring(1) : value;
        return result.endsWith("\"") ? result.substring(0, result.length() - 1) : result;
    }

    private static boolean isText(String contentType) {
        if (contentType == null) {
            return true;   // some error responses omit it; masking still applies
        }
        try {
            MediaType type = MediaType.parseMediaType(contentType);
            return "text".equals(type.getType())
                    || type.getSubtype().contains("json")          // application/json, application/vnd.ni-payment.v2+json
                    || type.getSubtype().contains("xml")
                    || type.isCompatibleWith(MediaType.APPLICATION_FORM_URLENCODED);
        } catch (RuntimeException ex) {
            return false;
        }
    }
}
