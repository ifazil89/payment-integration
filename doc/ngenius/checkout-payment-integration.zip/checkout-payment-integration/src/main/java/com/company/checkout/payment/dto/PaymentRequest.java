package com.company.checkout.payment.dto;

import com.company.checkout.common.dto.Amount;
import com.company.checkout.wallet.WalletType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * POST /api/v1/payments. No documentation annotations here: the API docs come from
 * payment/openapi/schema/PaymentRequestSchema (DocSchemaTest keeps the two the same).
 *
 * @param walletToken the ENCRYPTED token exactly as the device returned it:
 *                    Apple Pay = PKPaymentToken.paymentData (JSON string, or that JSON base64-encoded),
 *                    Google Pay = paymentMethodData.tokenizationData.token (string)
 */
public record PaymentRequest(
        @NotBlank @Size(max = 64) String merchantOrderId,
        @NotNull WalletType walletType,
        @NotBlank @Size(max = 20000) String walletToken,
        @NotNull @Valid Amount amount,
        @NotNull @Valid BillingInfo billingInfo) {

    /** Never print the wallet token. */
    @Override
    public String toString() {
        return "PaymentRequest[merchantOrderId=" + merchantOrderId + ", walletType=" + walletType
                + ", walletToken=***, amount=" + amount + "]";
    }
}
