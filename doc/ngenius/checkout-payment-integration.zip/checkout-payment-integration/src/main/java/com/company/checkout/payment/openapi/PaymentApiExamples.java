package com.company.checkout.payment.openapi;

/**
 * JSON examples shown in Swagger UI. Documentation only.
 * Annotation values must be compile-time constants: only literals and "+" here.
 */
final class PaymentApiExamples {

    static final String APPLE_PAY_REQUEST = """
            {
              "merchantOrderId": "SO-1001",
              "walletType": "APPLE_PAY",
              "walletToken": "{\\"version\\":\\"EC_v1\\",\\"data\\":\\"<base64>\\",\\"signature\\":\\"<base64>\\",\\"header\\":{\\"ephemeralPublicKey\\":\\"<base64>\\",\\"publicKeyHash\\":\\"<base64>\\",\\"transactionId\\":\\"<hex>\\"}}",
              "amount": { "value": 250.00, "currency": "AED" },
              "billingInfo": { "firstName": "Jane", "lastName": "Doe", "email": "jane@example.com",
                               "address": "Sheikh Zayed Road 1", "city": "Dubai", "countryCode": "AE" }
            }""";

    static final String GOOGLE_PAY_REQUEST = """
            {
              "merchantOrderId": "SO-1002",
              "walletType": "GOOGLE_PAY",
              "walletToken": "{\\"signature\\":\\"<base64>\\",\\"intermediateSigningKey\\":{...},\\"protocolVersion\\":\\"ECv2\\",\\"signedMessage\\":\\"<json>\\"}",
              "amount": { "value": 99.00, "currency": "AED" },
              "billingInfo": { "firstName": "Jane", "lastName": "Doe", "email": "jane@example.com" }
            }""";

    static final String APPROVED = """
            { "paymentId": "7f3c2a9e-1b4d-4e8f-9a2b-3c4d5e6f7a8b", "merchantOrderId": "SO-1001", "walletType": "APPLE_PAY",
              "status": "APPROVED", "amount": { "value": 250.00, "currency": "AED" }, "cardScheme": "Visa",
              "cardLast4": "4242", "providerPaymentId": "pay_mbabizu24mvu3mela5njyhpit4",
              "createdAt": "2026-11-18T19:40:01.412Z", "updatedAt": "2026-11-18T19:40:02.104Z" }""";

    static final String CHALLENGE_REQUIRED = """
            { "paymentId": "7f3c2a9e-1b4d-4e8f-9a2b-3c4d5e6f7a8b", "merchantOrderId": "SO-1002", "walletType": "GOOGLE_PAY",
              "status": "CHALLENGE_REQUIRED", "amount": { "value": 99.00, "currency": "AED" },
              "providerPaymentId": "pay_mbabizu24mvu3mela5njyhpit4",
              "threeDsRedirectUrl": "https://api.sandbox.checkout.com/3ds/pay_mbabizu24mvu3mela5njyhpit4",
              "createdAt": "2026-11-18T19:40:01.412Z", "updatedAt": "2026-11-18T19:40:02.104Z" }""";

    static final String DECLINED = """
            { "paymentId": "7f3c2a9e-1b4d-4e8f-9a2b-3c4d5e6f7a8b", "merchantOrderId": "SO-1001", "walletType": "APPLE_PAY",
              "status": "DECLINED", "amount": { "value": 250.00, "currency": "AED" },
              "providerPaymentId": "pay_mbabizu24mvu3mela5njyhpit4", "failureReason": "Insufficient Funds (20051)",
              "createdAt": "2026-11-18T19:40:01.412Z", "updatedAt": "2026-11-18T19:40:02.104Z" }""";

    static final String CAPTURED = """
            { "paymentId": "7f3c2a9e-1b4d-4e8f-9a2b-3c4d5e6f7a8b", "merchantOrderId": "SO-1001", "walletType": "APPLE_PAY",
              "status": "CAPTURED", "amount": { "value": 250.00, "currency": "AED" }, "cardScheme": "Visa",
              "cardLast4": "4242", "providerPaymentId": "pay_mbabizu24mvu3mela5njyhpit4",
              "createdAt": "2026-11-18T19:40:01.412Z", "updatedAt": "2026-11-18T19:41:10.000Z" }""";

    // ------------------------------------------------------------------ errors

    private static final String META = "\"correlationId\": \"demo-1\", "
            + "\"traceId\": \"4bf92f3577b34da6a3ce929d0e0e4736\", \"timestamp\": \"2026-11-18T19:40:01.412Z\"";

    static final String VALIDATION_ERROR = "{ \"code\": \"VALIDATION_ERROR\", \"message\": \"Request validation failed\", "
            + META + ", \"errors\": [ { \"field\": \"walletToken\", \"message\": \"must not be blank\" } ] }";
    static final String MISSING_HEADER =
            "{ \"code\": \"MISSING_HEADER\", \"message\": \"Header Idempotency-Key is required\", " + META + " }";
    static final String UNAUTHORIZED =
            "{ \"code\": \"UNAUTHORIZED\", \"message\": \"Missing or invalid X-Api-Key\", " + META + " }";
    static final String NOT_FOUND =
            "{ \"code\": \"PAYMENT_NOT_FOUND\", \"message\": \"No payment 7f3c2a9e-...\", " + META + " }";
    static final String IDEMPOTENCY_KEY_REUSED = "{ \"code\": \"IDEMPOTENCY_KEY_REUSED\", "
            + "\"message\": \"This Idempotency-Key was already used for a different request\", " + META + " }";
    static final String WALLET_TOKEN_ALREADY_USED = "{ \"code\": \"WALLET_TOKEN_ALREADY_USED\", "
            + "\"message\": \"This wallet token was already used for a payment\", " + META + " }";
    static final String WALLET_TOKEN_INVALID = "{ \"code\": \"WALLET_TOKEN_INVALID\", "
            + "\"message\": \"The wallet token could not be verified or decrypted\", " + META + " }";
    static final String WALLET_TOKEN_EXPIRED = "{ \"code\": \"WALLET_TOKEN_EXPIRED\", "
            + "\"message\": \"The wallet token has expired; ask the shopper to pay again\", " + META + " }";
    static final String WALLET_AMOUNT_MISMATCH = "{ \"code\": \"WALLET_AMOUNT_MISMATCH\", "
            + "\"message\": \"The amount does not match the amount approved in the wallet\", " + META + " }";
    static final String INVALID_AMOUNT =
            "{ \"code\": \"INVALID_AMOUNT\", \"message\": \"AED allows 2 decimals, got 10.001\", " + META + " }";
    static final String INTERNAL_ERROR =
            "{ \"code\": \"INTERNAL_ERROR\", \"message\": \"Unexpected error\", " + META + " }";
    static final String GATEWAY_ERROR =
            "{ \"code\": \"GATEWAY_ERROR\", \"message\": \"Checkout.com returned an error\", " + META + " }";
    static final String GATEWAY_BUSY = "{ \"code\": \"GATEWAY_BUSY\", "
            + "\"message\": \"Checkout.com is rate limiting; retry later with the same Idempotency-Key\", " + META + " }";
    static final String GATEWAY_TIMEOUT = "{ \"code\": \"GATEWAY_TIMEOUT\", \"message\": \"Checkout.com did not "
            + "answer; the outcome is unknown. Check it with GET /api/v1/payments/{paymentId}.\", " + META + " }";

    private PaymentApiExamples() {
    }
}
