package com.company.checkout.cko.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The payment source, in one of two shapes:
 *
 *   network_token   decrypted Apple Pay / Google Pay CRYPTOGRAM_3DS: DPAN + cryptogram (+ ECI)
 *                   {"type":"network_token","token":"<DPAN>","token_type":"applepay|googlepay",
 *                    "expiry_month":..,"expiry_year":..,"cryptogram":"..","eci":".."}
 *   card            decrypted Google Pay PAN_ONLY: the real card number, no cryptogram (3DS is requested)
 *                   {"type":"card","number":"..","expiry_month":..,"expiry_year":..,"name":".."}
 *
 * Holds card data: toString masks it, and the logging masker hides token / number / cryptogram.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record CkoSource(
        @JsonProperty("type") String type,
        @JsonProperty("token") String token,
        @JsonProperty("token_type") String tokenType,
        @JsonProperty("number") String number,
        @JsonProperty("expiry_month") Integer expiryMonth,
        @JsonProperty("expiry_year") Integer expiryYear,
        @JsonProperty("cryptogram") String cryptogram,
        @JsonProperty("eci") String eci,
        @JsonProperty("name") String name,
        @JsonProperty("billing_address") CkoAddress billingAddress) {

    public static CkoSource networkToken(String token, String tokenType, int expiryMonth, int expiryYear,
                                         String cryptogram, String eci, CkoAddress billingAddress) {
        return new CkoSource("network_token", token, tokenType, null, expiryMonth, expiryYear, cryptogram, eci,
                null, billingAddress);
    }

    public static CkoSource card(String number, int expiryMonth, int expiryYear, String name, CkoAddress billingAddress) {
        return new CkoSource("card", null, null, number, expiryMonth, expiryYear, null, null, name, billingAddress);
    }

    @Override
    public String toString() {
        return "CkoSource[type=" + type + ", tokenType=" + tokenType + ", ***]";
    }
}
