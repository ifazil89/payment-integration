package com.company.checkout.payment;

import com.company.checkout.cko.client.CkoClient;
import com.company.checkout.cko.dto.CkoPaymentRequest;
import com.company.checkout.cko.dto.CkoPaymentResponse;
import com.company.checkout.cko.exception.CkoException;
import com.company.checkout.wallet.AuthMethod;
import com.company.checkout.wallet.DecryptedWalletCard;
import com.company.checkout.wallet.WalletDecryptionException;
import com.company.checkout.wallet.WalletDecryptor;
import com.company.checkout.wallet.WalletType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.client.ResourceAccessException;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * The payment API end to end (controller, validation, service, MapStruct, H2, Flyway, logging) with
 * only the wallet decryption and the Checkout.com client mocked: no keys or Checkout.com account needed.
 * Decryption itself is tested in ApplePayDecryptorTest / GooglePayDecryptorTest.
 */
@SpringBootTest
@ActiveProfiles({"local", "test"})
@AutoConfigureMockMvc
@ExtendWith(OutputCaptureExtension.class)
class PaymentApiTest {

    private static final String API_KEY = "sandbox-key";        // application-local.yml: local-client:sandbox-key
    private static final String DPAN = "4817499999999999";
    private static final String CRYPTOGRAM = "AOrEWbIACBzFTkgXZ1aWAoABFA==";
    private static final String WALLET_TOKEN = "{\"version\":\"EC_v1\",\"data\":\"U0VDUkVUREFUQQ==\"}";

    @Autowired
    MockMvc mvc;

    @MockitoBean
    WalletDecryptor walletDecryptor;

    @MockitoBean
    CkoClient ckoClient;

    // ------------------------------------------------------------------ create

    @Test
    void applePayIsApprovedAsNetworkToken() throws Exception {
        String txn = givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenReturn(ckoResponse("Authorized", true, null));

        mvc.perform(payment("key-1", request("APPLE_PAY", "250.00")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("APPROVED"))
                .andExpect(jsonPath("$.walletType").value("APPLE_PAY"))
                .andExpect(jsonPath("$.providerPaymentId").value("pay_test"))
                .andExpect(jsonPath("$.cardLast4").value("9999"))
                .andExpect(jsonPath("$.amount.value").value(250.00))
                .andExpect(jsonPath("$.threeDsRedirectUrl").doesNotExist());

        ArgumentCaptor<CkoPaymentRequest> sent = ArgumentCaptor.forClass(CkoPaymentRequest.class);
        ArgumentCaptor<String> idempotency = ArgumentCaptor.forClass(String.class);
        verify(ckoClient).requestPayment(sent.capture(), idempotency.capture());
        CkoPaymentRequest cko = sent.getValue();
        assertThat(cko.source().type()).isEqualTo("network_token");
        assertThat(cko.source().tokenType()).isEqualTo("applepay");
        assertThat(cko.source().token()).isEqualTo(DPAN);
        assertThat(cko.source().cryptogram()).isEqualTo(CRYPTOGRAM);
        assertThat(cko.source().expiryMonth()).isEqualTo(12);
        assertThat(cko.source().expiryYear()).isEqualTo(2030);
        assertThat(cko.amount()).isEqualTo(25000L);
        assertThat(cko.capture()).isTrue();
        assertThat(cko.processingChannelId()).isEqualTo("pc_test");
        assertThat(cko.threeDs()).isNull();
        assertThat(cko.reference()).isEqualTo("SO-1");
        assertThat(cko.metadata()).containsEntry("payment_id", idempotency.getValue());   // Cko-Idempotency-Key = our id
        assertThat(txn).isNotBlank();
    }

    @Test
    void googlePayPanOnlyGoesThrough3ds() throws Exception {
        when(walletDecryptor.decrypt(eq(WalletType.GOOGLE_PAY), anyString())).thenReturn(new DecryptedWalletCard(
                WalletType.GOOGLE_PAY, AuthMethod.PAN_ONLY, "4895370012003478", 12, 2028, null, null,
                UUID.randomUUID().toString(), null, null));
        when(ckoClient.requestPayment(any(), anyString()))
                .thenReturn(ckoResponse("Pending", null, "https://3ds.example/challenge/pay_test"));

        mvc.perform(payment("key-2", request("GOOGLE_PAY", "99.00")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("CHALLENGE_REQUIRED"))
                .andExpect(jsonPath("$.threeDsRedirectUrl").value("https://3ds.example/challenge/pay_test"));

        ArgumentCaptor<CkoPaymentRequest> sent = ArgumentCaptor.forClass(CkoPaymentRequest.class);
        verify(ckoClient).requestPayment(sent.capture(), anyString());
        assertThat(sent.getValue().source().type()).isEqualTo("card");
        assertThat(sent.getValue().source().number()).isEqualTo("4895370012003478");
        assertThat(sent.getValue().threeDs().enabled()).isTrue();
        assertThat(sent.getValue().successUrl()).contains(sent.getValue().metadata().get("payment_id"));
    }

    @Test
    void declinedIsReturnedWithReason() throws Exception {
        givenApplePayCard(25000L, "784");
        CkoPaymentResponse declined = new CkoPaymentResponse("pay_test", "act_1", 25000L, "AED", false, "Declined",
                null, "20051", "Insufficient Funds", "SO-1", null, Map.of());
        when(ckoClient.requestPayment(any(), anyString())).thenReturn(declined);

        mvc.perform(payment("key-3", request("APPLE_PAY", "250.00")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("DECLINED"))
                .andExpect(jsonPath("$.failureReason").value("Insufficient Funds (20051)"));
    }

    @Test
    void checkout422IsFailed() throws Exception {
        givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenThrow(
                new CkoException(422, "/payments", "req_1", "request_invalid", List.of("token_invalid"), "{}"));

        mvc.perform(payment("key-4", request("APPLE_PAY", "250.00")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("FAILED"))
                .andExpect(jsonPath("$.failureReason").value("Rejected by Checkout.com: request_invalid [token_invalid]"));
    }

    @Test
    void checkout5xxIs502AndPaymentStaysPending() throws Exception {
        givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenThrow(
                new CkoException(503, "/payments", "req_2", null, null, "unavailable"));

        mvc.perform(payment("key-5", request("APPLE_PAY", "250.00")))
                .andExpect(status().isBadGateway())
                .andExpect(jsonPath("$.code").value("GATEWAY_ERROR"));

        // a retry with the same key returns the stored payment (PENDING), it is not sent again
        mvc.perform(payment("key-5", request("APPLE_PAY", "250.00")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("PENDING"));
        verify(ckoClient, times(1)).requestPayment(any(), anyString());
    }

    @Test
    void timeoutIs504() throws Exception {
        givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenThrow(new ResourceAccessException("Read timed out"));

        mvc.perform(payment("key-6", request("APPLE_PAY", "250.00")))
                .andExpect(status().isGatewayTimeout())
                .andExpect(jsonPath("$.code").value("GATEWAY_TIMEOUT"));
    }

    // ------------------------------------------------------------------ wallet rules

    @Test
    void invalidWalletTokenIs422() throws Exception {
        when(walletDecryptor.decrypt(any(), anyString()))
                .thenThrow(WalletDecryptionException.invalid("signature does not match"));

        mvc.perform(payment("key-7", request("APPLE_PAY", "250.00")))
                .andExpect(status().is(422))
                .andExpect(jsonPath("$.code").value("WALLET_TOKEN_INVALID"))
                .andExpect(jsonPath("$.message").value("The wallet token could not be verified or decrypted"));
        verify(ckoClient, never()).requestPayment(any(), anyString());
    }

    @Test
    void applePayAmountMustMatchTheWalletSheet() throws Exception {
        givenApplePayCard(10000L, "784");    // shopper approved AED 100.00

        mvc.perform(payment("key-8", request("APPLE_PAY", "250.00")))
                .andExpect(status().is(422))
                .andExpect(jsonPath("$.code").value("WALLET_AMOUNT_MISMATCH"));
        verify(ckoClient, never()).requestPayment(any(), anyString());
    }

    @Test
    void walletTokenPaysOnlyOnce() throws Exception {
        String txn = UUID.randomUUID().toString();
        when(walletDecryptor.decrypt(any(), anyString())).thenReturn(applePayCard(25000L, "784", txn));
        when(ckoClient.requestPayment(any(), anyString())).thenReturn(ckoResponse("Authorized", true, null));

        mvc.perform(payment("key-9a", request("APPLE_PAY", "250.00"))).andExpect(status().isOk());
        mvc.perform(payment("key-9b", request("APPLE_PAY", "250.00")))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("WALLET_TOKEN_ALREADY_USED"));
        verify(ckoClient, times(1)).requestPayment(any(), anyString());
    }

    @Test
    void sameKeySameRequestReturnsSamePayment() throws Exception {
        givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenReturn(ckoResponse("Authorized", true, null));

        String first = mvc.perform(payment("key-10", request("APPLE_PAY", "250.00")))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String second = mvc.perform(payment("key-10", request("APPLE_PAY", "250.00")))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

        assertThat(second).isEqualTo(first);
        verify(walletDecryptor, times(1)).decrypt(any(), anyString());
    }

    @Test
    void sameKeyDifferentRequestIs409() throws Exception {
        givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenReturn(ckoResponse("Authorized", true, null));

        mvc.perform(payment("key-11", request("APPLE_PAY", "250.00"))).andExpect(status().isOk());
        mvc.perform(payment("key-11", request("APPLE_PAY", "260.00")))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("IDEMPOTENCY_KEY_REUSED"));
    }

    @Test
    void validationAndAuthentication() throws Exception {
        mvc.perform(payment("key-12", request("APPLE_PAY", "250.00").replace(WALLET_TOKEN.replace("\"", "\\\""), "")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"))
                .andExpect(jsonPath("$.errors[0].field").value("walletToken"));

        mvc.perform(post("/api/v1/payments").header("Idempotency-Key", "k")
                        .contentType(MediaType.APPLICATION_JSON).content(request("APPLE_PAY", "1.00")))
                .andExpect(status().isUnauthorized());

        mvc.perform(payment("key-13", request("SAMSUNG_PAY", "250.00")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("MALFORMED_REQUEST"));
    }

    // ------------------------------------------------------------------ get

    @Test
    void getRefreshesFromCheckoutUntilFinal() throws Exception {
        givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenReturn(ckoResponse("Authorized", true, null));
        String paymentId = createdPaymentId("key-14");

        when(ckoClient.getPayment("pay_test")).thenReturn(ckoResponse("Captured", true, null));
        mvc.perform(get("/api/v1/payments/" + paymentId).header("X-Api-Key", API_KEY))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("CAPTURED"));

        // CAPTURED is final: answered from the database
        mvc.perform(get("/api/v1/payments/" + paymentId).header("X-Api-Key", API_KEY))
                .andExpect(jsonPath("$.status").value("CAPTURED"));
        verify(ckoClient, times(1)).getPayment("pay_test");
    }

    @Test
    void getKeepsLastStatusWhenCheckoutIsDown() throws Exception {
        givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenReturn(ckoResponse("Authorized", true, null));
        String paymentId = createdPaymentId("key-15");

        when(ckoClient.getPayment("pay_test")).thenThrow(new ResourceAccessException("timeout"));
        mvc.perform(get("/api/v1/payments/" + paymentId).header("X-Api-Key", API_KEY))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("APPROVED"));
    }

    @Test
    void unknownPaymentIs404() throws Exception {
        mvc.perform(get("/api/v1/payments/does-not-exist").header("X-Api-Key", API_KEY))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("PAYMENT_NOT_FOUND"));
    }

    // ------------------------------------------------------------------ logging

    @Test
    void noCardDataOrWalletTokenInLogs(CapturedOutput output) throws Exception {
        givenApplePayCard(25000L, "784");
        when(ckoClient.requestPayment(any(), anyString())).thenReturn(ckoResponse("Authorized", true, null));

        mvc.perform(payment("key-16", request("APPLE_PAY", "250.00")).header("X-Correlation-Id", "log-test-16"))
                .andExpect(status().isOk());

        assertThat(output.getOut())
                .contains("HTTP IN  <-- 200 POST /api/v1/payments")
                .contains("log-test-16")
                .doesNotContain(DPAN)
                .doesNotContain(CRYPTOGRAM)
                .doesNotContain("U0VDUkVUREFUQQ")          // the wallet token's data
                .doesNotContain(API_KEY);
    }

    // ------------------------------------------------------------------ helpers

    private String createdPaymentId(String key) throws Exception {
        String body = mvc.perform(payment(key, request("APPLE_PAY", "250.00")))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        return body.replaceAll(".*\"paymentId\":\"([^\"]+)\".*", "$1");
    }

    private String givenApplePayCard(long amountMinor, String currencyNumeric) {
        String txn = UUID.randomUUID().toString();
        when(walletDecryptor.decrypt(eq(WalletType.APPLE_PAY), anyString()))
                .thenReturn(applePayCard(amountMinor, currencyNumeric, txn));
        return txn;
    }

    private static DecryptedWalletCard applePayCard(long amountMinor, String currencyNumeric, String txn) {
        return new DecryptedWalletCard(WalletType.APPLE_PAY, AuthMethod.CRYPTOGRAM_3DS, DPAN, 12, 2030, CRYPTOGRAM,
                "07", txn, amountMinor, currencyNumeric);
    }

    private static CkoPaymentResponse ckoResponse(String status, Boolean approved, String redirect) {
        return new CkoPaymentResponse("pay_test", "act_1", 25000L, "AED", approved, status, "123456",
                approved == Boolean.TRUE ? "10000" : null, approved == Boolean.TRUE ? "Approved" : null, "SO-1",
                new CkoPaymentResponse.Source("network_token", "Visa", "9999", "V001"),
                redirect == null ? Map.of() : Map.of("redirect", new CkoPaymentResponse.Link(redirect)));
    }

    private static MockHttpServletRequestBuilder payment(String idempotencyKey, String body) {
        return post("/api/v1/payments")
                .header("X-Api-Key", API_KEY)
                .header("Idempotency-Key", idempotencyKey)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body);
    }

    private static String request(String walletType, String amount) {
        return """
                {"merchantOrderId":"SO-1","walletType":"%s","walletToken":"%s",
                 "amount":{"value":%s,"currency":"AED"},
                 "billingInfo":{"firstName":"Jane","lastName":"Doe","email":"jane@example.com","countryCode":"AE"}}"""
                .formatted(walletType, WALLET_TOKEN.replace("\"", "\\\""), amount);
    }
}
