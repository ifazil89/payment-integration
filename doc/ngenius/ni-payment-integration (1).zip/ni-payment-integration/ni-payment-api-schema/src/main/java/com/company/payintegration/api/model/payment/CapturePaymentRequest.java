package com.company.payintegration.api.model.payment;

import com.company.payintegration.api.model.common.MoneyDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;

@Schema(name = "CapturePaymentRequest",
        description = "Omit the body (or the amount) to capture the full remaining authorised amount")
public record CapturePaymentRequest(

        @Schema(description = "Partial capture amount; must not exceed the remaining authorised amount")
        @Valid
        MoneyDto amount) {
}
