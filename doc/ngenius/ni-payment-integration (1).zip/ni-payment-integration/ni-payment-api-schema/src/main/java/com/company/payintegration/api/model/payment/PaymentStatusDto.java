package com.company.payintegration.api.model.payment;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Payment status as exposed by the API (independent of N-Genius naming).
 * A status only moves forward; REVERSED, DECLINED, FAILED and REFUNDED are final.
 */
@Schema(name = "PaymentStatus", description = """
        CREATED -> AWAITING_3DS -> AUTHORISED -> PARTIALLY_CAPTURED -> CAPTURED -> PARTIALLY_REFUNDED -> REFUNDED,
        or the final statuses REVERSED, DECLINED, FAILED.""")
public enum PaymentStatusDto {
    CREATED,
    AWAITING_3DS,
    AUTHORISED,
    PARTIALLY_CAPTURED,
    CAPTURED,
    PARTIALLY_REFUNDED,
    REFUNDED,
    REVERSED,
    DECLINED,
    FAILED
}
