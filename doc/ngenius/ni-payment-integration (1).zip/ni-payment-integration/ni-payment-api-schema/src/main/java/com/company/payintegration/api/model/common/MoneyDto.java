package com.company.payintegration.api.model.common;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.math.BigDecimal;

@Schema(name = "Money", description = "Amount in MAJOR units with an ISO 4217 currency (AED 250.00, KWD 1.250)")
public record MoneyDto(

        @Schema(description = "Amount in major units. Max decimals = the currency's decimals (AED 2, KWD 3)",
                example = "250.00", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @DecimalMin("0.001")
        BigDecimal value,

        @Schema(description = "ISO 4217 currency code", example = "AED", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Pattern(regexp = "[A-Z]{3}")
        String currency) {
}
