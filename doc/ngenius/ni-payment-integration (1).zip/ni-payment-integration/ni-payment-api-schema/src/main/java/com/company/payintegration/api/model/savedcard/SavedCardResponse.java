package com.company.payintegration.api.model.savedcard;

import io.swagger.v3.oas.annotations.media.Schema;

import java.time.Instant;

@Schema(name = "SavedCard", description = "A saved card as our backend sees it. The token is never exposed.")
public record SavedCardResponse(

        @Schema(example = "5d1e2c7a-8b9f-4a3e-bc12-0f1e2d3c4b5a")
        String savedCardId,

        @Schema(example = "411111******1111")
        String maskedPan,

        @Schema(example = "VISA")
        String scheme,

        @Schema(description = "YYYY-MM", example = "2030-12")
        String expiry,

        @Schema(example = "Jane Doe")
        String cardholderName,

        @Schema(description = "true = cannot be used for payments any more", example = "false")
        boolean expired,

        Instant createdAt) {
}
