package com.company.payintegration.api;

/**
 * Shared names used by the OpenAPI interfaces, the models and the service's OpenAPI config,
 * so the contract and its implementation can't drift apart.
 */
public final class ApiDocs {

    public static final String TITLE = "N-Genius Payment Integration API";
    public static final String VERSION = "v1";
    public static final String DESCRIPTION = """
            Middleware between our backend and N-Genius (Network International).
            Amounts are in MAJOR units (AED 250.00). The HTTP status says whether the request was processed;
            the payment outcome (AUTHORISED, DECLINED, ...) is in the body. Errors use RFC 9457 problem details
            with a stable `code` and the `correlationId`.""";

    // ---- tags
    public static final String TAG_PAYMENTS = "Payments";
    public static final String TAG_PAYMENT_OPERATIONS = "Payment operations";
    public static final String TAG_SAVED_CARDS = "Saved cards";
    public static final String TAG_THREEDS_CALLBACKS = "3DS callbacks (public)";
    public static final String TAG_NGENIUS_WEBHOOKS = "N-Genius webhooks (public)";

    // ---- security
    /** Name of the security scheme (API key in a header) protecting /api/**. */
    public static final String BACKEND_API_KEY = "backendApiKey";

    // ---- headers
    public static final String HEADER_API_KEY = "X-Api-Key";
    public static final String HEADER_IDEMPOTENCY_KEY = "Idempotency-Key";
    public static final String HEADER_CORRELATION_ID = "X-Correlation-Id";

    // ---- media types
    public static final String PROBLEM_JSON = "application/problem+json";

    private ApiDocs() {
    }
}
