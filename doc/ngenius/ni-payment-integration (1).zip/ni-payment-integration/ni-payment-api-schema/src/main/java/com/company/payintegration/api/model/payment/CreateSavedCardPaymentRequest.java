package com.company.payintegration.api.model.payment;

import com.company.payintegration.api.model.common.MoneyDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Schema(name = "CreateSavedCardPaymentRequest", description = "Authorise with a saved card. The CVV is always required.")
public record CreateSavedCardPaymentRequest(

        @Schema(example = "SO-1002", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 64)
        String merchantOrderId,

        @Schema(description = "Must be the owner of the saved card", example = "cust-42",
                requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 64)
        String customerId,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Valid
        MoneyDto amount,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Valid
        CustomerDto customer,

        @Schema(description = "Id from GET /api/v1/customers/{customerId}/saved-cards",
                example = "5d1e2c7a-8b9f-4a3e-bc12-0f1e2d3c4b5a", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank
        String savedCardId,

        @Schema(description = "CVV entered by the shopper (never stored)", example = "123",
                requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Pattern(regexp = "\\d{3,4}", message = "must be 3-4 digits")
        String cvv,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Valid
        BrowserInfoDto browserInfo,

        @Schema(example = "https://shop.example.com/checkout/result", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 2048)
        String returnUrl) {

    @Override
    public String toString() {
        return "CreateSavedCardPaymentRequest[merchantOrderId=" + merchantOrderId + ", savedCardId=" + savedCardId
                + ", cvv=***]";
    }
}
