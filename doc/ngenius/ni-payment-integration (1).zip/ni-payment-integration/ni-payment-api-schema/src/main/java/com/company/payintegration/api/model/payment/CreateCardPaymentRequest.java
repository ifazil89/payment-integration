package com.company.payintegration.api.model.payment;

import com.company.payintegration.api.model.common.MoneyDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Schema(name = "CreateCardPaymentRequest", description = "Authorise a new card (two-stage: AUTH now, capture later)")
public record CreateCardPaymentRequest(

        @Schema(description = "Our order id (sent to N-Genius as merchantOrderReference)", example = "SO-1001",
                requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 64)
        String merchantOrderId,

        @Schema(description = "Our customer id (owner of saved cards)", example = "cust-42",
                requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 64)
        String customerId,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Valid
        MoneyDto amount,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Valid
        CustomerDto customer,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Valid
        CardDetailsDto card,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Valid
        BrowserInfoDto browserInfo,

        @Schema(description = "Where the shopper's browser returns after 3DS (?paymentId=... is appended). "
                + "Must start with an allowed prefix.",
                example = "https://shop.example.com/checkout/result", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 2048)
        String returnUrl,

        @Schema(description = "Store the card token for later payments (requires tokenisation on the N-Genius account)",
                example = "true", defaultValue = "false")
        Boolean saveCard) {
}
