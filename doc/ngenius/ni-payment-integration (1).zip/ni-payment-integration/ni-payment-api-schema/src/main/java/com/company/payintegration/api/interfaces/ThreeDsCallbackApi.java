package com.company.payintegration.api.interfaces;

import com.company.payintegration.api.ApiDocs;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * PUBLIC 3DS endpoints, used by the shopper's browser (not by our backend). No API key:
 * they are protected by unguessable session ids and the allowed-return-URL list.
 */
@Tag(name = ApiDocs.TAG_THREEDS_CALLBACKS, description = "Browser-facing EMV 3DS 2.x endpoints")
public interface ThreeDsCallbackApi {

    @Operation(operationId = "threeDsChallengePage", summary = "Auto-submitting 3DS challenge page",
            description = "nextAction.redirectUrl points here. The page POSTs the creq to the bank ACS.")
    @ApiResponse(responseCode = "200", description = "HTML page that redirects to the bank",
            content = @Content(mediaType = MediaType.TEXT_HTML_VALUE, schema = @Schema(type = "string")))
    @ApiResponse(responseCode = "410", description = "Session expired, completed or unknown",
            content = @Content(mediaType = MediaType.TEXT_HTML_VALUE, schema = @Schema(type = "string")))
    @GetMapping(path = "/ngenius/3ds/challenge/{sessionId}", produces = MediaType.TEXT_HTML_VALUE)
    ResponseEntity<String> challengePage(
            @Parameter(description = "3DS session id") @PathVariable("sessionId") String sessionId);

    @Operation(operationId = "threeDsNotification", summary = "3DS challenge result from the bank ACS",
            description = """
                    This is the notificationURL sent to N-Genius. After the challenge the ACS makes the shopper's
                    browser POST the form field `cres` here. The result is passed to N-Genius unchanged and the
                    browser is redirected to the shop's returnUrl with ?paymentId=...""")
    @ApiResponse(responseCode = "303", description = "Redirect back to the shop",
            headers = @Header(name = "Location", description = "returnUrl?paymentId=...",
                    schema = @Schema(type = "string", format = "uri")))
    @PostMapping(path = "/ngenius/3ds/notification/{sessionId}",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    ResponseEntity<Void> challengeNotification(
            @Parameter(description = "3DS session id") @PathVariable("sessionId") String sessionId,
            @Parameter(description = "Challenge result from the ACS (Base64, passed through unchanged)")
            @RequestParam("cres") String cres);
}
