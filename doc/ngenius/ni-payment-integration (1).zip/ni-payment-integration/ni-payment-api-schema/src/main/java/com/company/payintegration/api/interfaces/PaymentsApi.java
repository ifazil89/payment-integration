package com.company.payintegration.api.interfaces;

import com.company.payintegration.api.ApiDocs;
import com.company.payintegration.api.model.common.ApiProblem;
import com.company.payintegration.api.model.payment.CreateCardPaymentRequest;
import com.company.payintegration.api.model.payment.CreateSavedCardPaymentRequest;
import com.company.payintegration.api.model.payment.PaymentResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Contract for creating and reading payments. Called by OUR backend only.
 *
 * The interface carries everything about the HTTP contract: paths, headers, validation,
 * OpenAPI documentation. The service's controller only implements the methods.
 *
 * Common error responses (400, 401, 500, 502, 504) are added to every /api operation by the
 * service's OpenAPI customizer, so they are not repeated here.
 */
@Tag(name = ApiDocs.TAG_PAYMENTS, description = "Authorise payments (two-stage) with a new or saved card, incl. 3DS")
public interface PaymentsApi {

    @Operation(
            operationId = "payWithCard",
            summary = "Authorise a new card",
            description = """
                    Creates an AUTH order at N-Genius and sends the card. Possible results in `status`:
                    AUTHORISED; AWAITING_3DS with `nextAction` (shopper must complete a 3DS challenge);
                    DECLINED / FAILED. Repeating the call with the same Idempotency-Key returns the same
                    payment and never charges twice.""",
            security = @SecurityRequirement(name = ApiDocs.BACKEND_API_KEY),
            parameters = @Parameter(in = ParameterIn.HEADER, name = ApiDocs.HEADER_CORRELATION_ID, required = false,
                    description = "Optional id to follow the request across services", schema = @Schema(type = "string")))
    @ApiResponse(responseCode = "200", description = "Processed; see `status` for the outcome",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = PaymentResponse.class)))
    @ApiResponse(responseCode = "409", description = "DUPLICATE_REQUEST: same Idempotency-Key is being processed",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @ApiResponse(responseCode = "422", description = "INVALID_AMOUNT, INVALID_RETURN_URL, THREEDS_REJECTED",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @PostMapping(path = "/api/v1/payments/card",
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    PaymentResponse payWithCard(
            @Parameter(description = "Unique per payment attempt (1-100 chars). Reuse it when retrying.",
                    required = true, example = "order-SO-1001-attempt-1")
            @RequestHeader(ApiDocs.HEADER_IDEMPOTENCY_KEY) String idempotencyKey,
            @Valid @RequestBody CreateCardPaymentRequest request);

    @Operation(
            operationId = "payWithSavedCard",
            summary = "Authorise a saved card",
            description = """
                    Same as payWithCard, but with a card saved from an earlier payment. The CVV is required
                    every time. The card must belong to `customerId` and not be expired.""",
            security = @SecurityRequirement(name = ApiDocs.BACKEND_API_KEY),
            parameters = @Parameter(in = ParameterIn.HEADER, name = ApiDocs.HEADER_CORRELATION_ID, required = false,
                    schema = @Schema(type = "string")))
    @ApiResponse(responseCode = "200", description = "Processed; see `status` for the outcome",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = PaymentResponse.class)))
    @ApiResponse(responseCode = "404", description = "SAVED_CARD_NOT_FOUND",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @ApiResponse(responseCode = "409", description = "DUPLICATE_REQUEST",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @ApiResponse(responseCode = "422", description = "SAVED_CARD_EXPIRED, INVALID_AMOUNT, INVALID_RETURN_URL",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @PostMapping(path = "/api/v1/payments/saved-card",
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    PaymentResponse payWithSavedCard(
            @Parameter(description = "Unique per payment attempt (1-100 chars)", required = true,
                    example = "order-SO-1002-attempt-1")
            @RequestHeader(ApiDocs.HEADER_IDEMPOTENCY_KEY) String idempotencyKey,
            @Valid @RequestBody CreateSavedCardPaymentRequest request);

    @Operation(
            operationId = "getPayment",
            summary = "Get a payment",
            description = "Stored status, or with refresh=true the latest status read from N-Genius first. "
                    + "Includes `nextAction` while a 3DS challenge is pending.",
            security = @SecurityRequirement(name = ApiDocs.BACKEND_API_KEY))
    @ApiResponse(responseCode = "200", description = "The payment",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = PaymentResponse.class)))
    @ApiResponse(responseCode = "404", description = "PAYMENT_NOT_FOUND",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @GetMapping(path = "/api/v1/payments/{paymentId}", produces = MediaType.APPLICATION_JSON_VALUE)
    PaymentResponse getPayment(
            @Parameter(description = "Our payment id", example = "7f3c2a9e-1b4d-4e8f-9a2b-3c4d5e6f7a8b")
            @PathVariable("paymentId") String paymentId,
            @Parameter(description = "true = ask N-Genius for the latest status first")
            @RequestParam(name = "refresh", defaultValue = "false") boolean refresh);
}
