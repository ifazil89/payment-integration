package com.company.payintegration.api.model.payment;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Raw card details (N-Genius Direct API). PCI DSS: never log, never store.
 * toString() is masked so an accidental log statement cannot leak them.
 */
@Schema(name = "CardDetails", description = "Raw card details. PCI DSS scope: never logged or stored.")
public record CardDetailsDto(

        @Schema(description = "Card number, digits only", example = "4111111111111111",
                requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Pattern(regexp = "\\d{12,19}", message = "must be 12-19 digits")
        String pan,

        @Schema(description = "Expiry YYYY-MM", example = "2030-12", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Pattern(regexp = "\\d{4}-(0[1-9]|1[0-2])", message = "must be YYYY-MM")
        String expiry,

        @Schema(description = "CVV / CSC", example = "123", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Pattern(regexp = "\\d{3,4}", message = "must be 3-4 digits")
        String cvv,

        @Schema(example = "Jane Doe", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 100)
        String cardholderName) {

    @Override
    public String toString() {
        String masked = pan == null || pan.length() < 10 ? "****"
                : pan.substring(0, 6) + "*".repeat(pan.length() - 10) + pan.substring(pan.length() - 4);
        return "CardDetailsDto[pan=" + masked + ", expiry=" + expiry + ", cvv=***]";
    }
}
