package com.company.payintegration.api.model.payment;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "NextActionType")
public enum NextActionType {
    /** The shopper must complete a 3DS challenge with their bank. */
    THREEDS_CHALLENGE
}
