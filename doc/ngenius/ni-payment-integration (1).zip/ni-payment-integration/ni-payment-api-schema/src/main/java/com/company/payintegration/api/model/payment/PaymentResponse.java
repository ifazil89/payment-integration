package com.company.payintegration.api.model.payment;

import com.company.payintegration.api.model.common.MoneyDto;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.Instant;

@Schema(name = "PaymentResponse")
public record PaymentResponse(

        @Schema(description = "Our payment id", example = "7f3c2a9e-1b4d-4e8f-9a2b-3c4d5e6f7a8b")
        String paymentId,

        @Schema(example = "SO-1001")
        String merchantOrderId,

        PaymentStatusDto status,

        MoneyDto amount,

        @Schema(description = "Total captured so far")
        MoneyDto capturedAmount,

        @Schema(description = "Total refunded so far")
        MoneyDto refundedAmount,

        @Schema(description = "N-Genius order reference (for support)", example = "a1b2c3d4-...")
        String gatewayOrderReference,

        @Schema(description = "Why the payment failed, if it did", example = "Gateway rejected card payment (HTTP 400)")
        String failureReason,

        @Schema(description = "Present only when the frontend must act (3DS challenge)")
        NextActionDto nextAction,

        Instant createdAt,

        Instant updatedAt) {
}
