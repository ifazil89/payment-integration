package com.company.payintegration.api.model.payment;

import com.company.payintegration.api.model.common.MoneyDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@Schema(name = "RefundPaymentRequest")
public record RefundPaymentRequest(

        @Schema(description = "Must not exceed captured minus already refunded",
                requiredMode = Schema.RequiredMode.REQUIRED)
        @NotNull @Valid
        MoneyDto amount) {
}
