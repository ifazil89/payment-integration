package com.company.payintegration.api.interfaces;

import com.company.payintegration.api.ApiDocs;
import com.company.payintegration.api.model.common.ApiProblem;
import com.company.payintegration.api.model.payment.CapturePaymentRequest;
import com.company.payintegration.api.model.payment.PaymentResponse;
import com.company.payintegration.api.model.payment.RefundPaymentRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/** Contract for operations on an authorised payment. Called by OUR backend only. */
@Tag(name = ApiDocs.TAG_PAYMENT_OPERATIONS, description = "Capture, reverse (void) and refund")
public interface PaymentOperationsApi {

    @Operation(
            operationId = "capturePayment",
            summary = "Capture an authorised payment (full or partial)",
            description = "No body (or no amount) captures the full remaining authorised amount. "
                    + "Several partial captures are allowed up to the authorised amount.",
            security = @SecurityRequirement(name = ApiDocs.BACKEND_API_KEY))
    @ApiResponse(responseCode = "200", description = "Captured",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = PaymentResponse.class)))
    @ApiResponse(responseCode = "404", description = "PAYMENT_NOT_FOUND",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @ApiResponse(responseCode = "409", description = "INVALID_PAYMENT_STATE (e.g. not authorised, reversed)",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @ApiResponse(responseCode = "422", description = "INVALID_AMOUNT (exceeds remaining, wrong currency), GATEWAY_REJECTED",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @PostMapping(path = "/api/v1/payments/{paymentId}/capture", produces = MediaType.APPLICATION_JSON_VALUE)
    PaymentResponse capturePayment(
            @Parameter(description = "Our payment id") @PathVariable("paymentId") String paymentId,
            @Valid @RequestBody(required = false) CapturePaymentRequest request);

    @Operation(
            operationId = "reversePayment",
            summary = "Reverse (void) an authorisation",
            description = "Releases the held funds. Only for an AUTHORISED payment without captures. Irreversible.",
            security = @SecurityRequirement(name = ApiDocs.BACKEND_API_KEY))
    @ApiResponse(responseCode = "200", description = "Reversed",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = PaymentResponse.class)))
    @ApiResponse(responseCode = "404", description = "PAYMENT_NOT_FOUND",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @ApiResponse(responseCode = "409", description = "INVALID_PAYMENT_STATE (has captures: refund instead)",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @PostMapping(path = "/api/v1/payments/{paymentId}/reverse", produces = MediaType.APPLICATION_JSON_VALUE)
    PaymentResponse reversePayment(
            @Parameter(description = "Our payment id") @PathVariable("paymentId") String paymentId);

    @Operation(
            operationId = "refundPayment",
            summary = "Refund all or part of the captured amount",
            security = @SecurityRequirement(name = ApiDocs.BACKEND_API_KEY))
    @ApiResponse(responseCode = "200", description = "Refunded",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = PaymentResponse.class)))
    @ApiResponse(responseCode = "404", description = "PAYMENT_NOT_FOUND",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @ApiResponse(responseCode = "409", description = "INVALID_PAYMENT_STATE (nothing captured)",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @ApiResponse(responseCode = "422", description = "INVALID_AMOUNT (exceeds refundable), GATEWAY_REJECTED",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @PostMapping(path = "/api/v1/payments/{paymentId}/refunds",
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    PaymentResponse refundPayment(
            @Parameter(description = "Our payment id") @PathVariable("paymentId") String paymentId,
            @Valid @RequestBody RefundPaymentRequest request);
}
