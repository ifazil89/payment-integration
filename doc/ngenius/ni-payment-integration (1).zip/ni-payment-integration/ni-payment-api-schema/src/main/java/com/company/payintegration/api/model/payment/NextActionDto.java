package com.company.payintegration.api.model.payment;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "NextAction", description = """
        What the frontend must do next. For THREEDS_CHALLENGE either redirect the browser to redirectUrl
        (our page auto-posts creq to the bank), or POST a form field "creq" to acsUrl yourself (e.g. in an iframe).""")
public record NextActionDto(

        @Schema(example = "THREEDS_CHALLENGE")
        NextActionType type,

        @Schema(description = "Our auto-submitting challenge page",
                example = "https://pay.example.com/ngenius/3ds/challenge/0c4b1f2e-...")
        String redirectUrl,

        @Schema(description = "Bank ACS URL", example = "https://acs.bank.example/challenge")
        String acsUrl,

        @Schema(description = "Base64 challenge request to POST as form field 'creq'", example = "eyJ0aHJlZURTU2Vy...")
        String creq) {
}
