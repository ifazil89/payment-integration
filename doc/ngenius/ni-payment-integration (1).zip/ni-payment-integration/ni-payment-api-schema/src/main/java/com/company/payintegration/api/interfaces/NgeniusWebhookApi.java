package com.company.payintegration.api.interfaces;

import com.company.payintegration.api.ApiDocs;
import com.company.payintegration.api.model.callback.NgeniusWebhookEvent;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * PUBLIC endpoint registered in the N-Genius portal. N-Genius sends each event once, never
 * retries, and does not sign the payload: the custom secret header is the only proof of origin.
 */
@Tag(name = ApiDocs.TAG_NGENIUS_WEBHOOKS, description = "Order events pushed by N-Genius")
public interface NgeniusWebhookApi {

    @Operation(operationId = "receiveNgeniusWebhook", summary = "Receive an N-Genius webhook",
            description = """
                    Checks the custom secret header (configured in the N-Genius portal), ignores duplicate eventIds,
                    then re-reads the order from N-Genius and updates the payment. Always answers within 15 s.""")
    @ApiResponse(responseCode = "200", description = "Accepted (also for duplicates and unknown orders)")
    @ApiResponse(responseCode = "401", description = "Missing or wrong secret header")
    @PostMapping(path = "/ngenius/webhooks", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Void> receiveWebhook(
            @Parameter(hidden = true) @RequestHeader HttpHeaders headers,
            @RequestBody NgeniusWebhookEvent event);
}
