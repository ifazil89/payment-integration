package com.company.payintegration.api.model.payment;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Schema(name = "Customer", description = "Shopper details sent to N-Genius with the order")
public record CustomerDto(

        @Schema(example = "jane@example.com", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Email @Size(max = 254)
        String email,

        @Schema(example = "Jane", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 60)
        String firstName,

        @Schema(example = "Doe", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 60)
        String lastName) {
}
