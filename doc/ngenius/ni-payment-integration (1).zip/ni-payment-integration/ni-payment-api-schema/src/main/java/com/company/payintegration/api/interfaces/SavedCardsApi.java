package com.company.payintegration.api.interfaces;

import com.company.payintegration.api.ApiDocs;
import com.company.payintegration.api.model.common.ApiProblem;
import com.company.payintegration.api.model.savedcard.SavedCardResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/** Contract for a customer's saved cards. Cards are saved automatically from payments with saveCard=true. */
@Tag(name = ApiDocs.TAG_SAVED_CARDS, description = "List and delete saved cards (tokens are never exposed)")
public interface SavedCardsApi {

    @Operation(operationId = "listSavedCards", summary = "List a customer's saved cards",
            security = @SecurityRequirement(name = ApiDocs.BACKEND_API_KEY))
    @ApiResponse(responseCode = "200", description = "Saved cards, newest first (empty list if none)",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                    array = @ArraySchema(schema = @Schema(implementation = SavedCardResponse.class))))
    @GetMapping(path = "/api/v1/customers/{customerId}/saved-cards", produces = MediaType.APPLICATION_JSON_VALUE)
    List<SavedCardResponse> listSavedCards(
            @Parameter(description = "Our customer id", example = "cust-42")
            @PathVariable("customerId") String customerId);

    @Operation(operationId = "deleteSavedCard", summary = "Delete a saved card",
            security = @SecurityRequirement(name = ApiDocs.BACKEND_API_KEY))
    @ApiResponse(responseCode = "204", description = "Deleted")
    @ApiResponse(responseCode = "404", description = "SAVED_CARD_NOT_FOUND (also when it belongs to another customer)",
            content = @Content(mediaType = ApiDocs.PROBLEM_JSON, schema = @Schema(implementation = ApiProblem.class)))
    @DeleteMapping(path = "/api/v1/customers/{customerId}/saved-cards/{savedCardId}")
    ResponseEntity<Void> deleteSavedCard(
            @Parameter(description = "Our customer id") @PathVariable("customerId") String customerId,
            @Parameter(description = "Saved card id") @PathVariable("savedCardId") String savedCardId);
}
