package com.company.payintegration.api.model.callback;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * N-Genius webhook body (only the fields we use; unknown fields are ignored).
 * Payloads are NOT signed; the service re-reads the order from N-Genius instead of trusting the state.
 */
@Schema(name = "NgeniusWebhookEvent", description = "Webhook sent by N-Genius (once, never retried)")
public record NgeniusWebhookEvent(

        @Schema(description = "Unique per event; used to ignore duplicates", example = "f2a9c1d0-...")
        String eventId,

        @Schema(description = "e.g. AUTHORISED, DECLINED, CAPTURED, REFUNDED, FULL_AUTH_REVERSED", example = "AUTHORISED")
        String eventName,

        @Schema(example = "5edab6d7-5946-43f4-b8c7-06b29c272bdd")
        String outletId,

        Order order) {

    @Schema(name = "NgeniusWebhookOrder")
    public record Order(

            @Schema(description = "N-Genius order reference", example = "a1b2c3d4-...")
            String reference,

            @Schema(example = "AUTH")
            String action) {
    }

    public String orderReference() {
        return order != null ? order.reference() : null;
    }
}
