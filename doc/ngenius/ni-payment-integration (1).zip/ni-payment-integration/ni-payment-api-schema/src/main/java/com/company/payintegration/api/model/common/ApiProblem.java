package com.company.payintegration.api.model.common;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Shape of every error response (RFC 9457 problem details, media type application/problem+json).
 * Used for documentation; the service returns Spring's ProblemDetail with these fields.
 */
@Schema(name = "ApiProblem", description = "Error response (RFC 9457 problem details)")
public record ApiProblem(

        @Schema(description = "Problem type URI", example = "about:blank")
        String type,

        @Schema(description = "Short summary of the HTTP status", example = "Conflict")
        String title,

        @Schema(description = "HTTP status code", example = "409")
        Integer status,

        @Schema(description = "Human-readable explanation",
                example = "Cannot capture payment 7f3c... in status REVERSED")
        String detail,

        @Schema(description = "Request path", example = "/api/v1/payments/7f3c.../capture")
        String instance,

        @Schema(description = """
                Stable machine-readable code. One of: INVALID_REQUEST, UNAUTHORIZED, PAYMENT_NOT_FOUND,
                SAVED_CARD_NOT_FOUND, THREEDS_SESSION_NOT_FOUND, INVALID_PAYMENT_STATE, DUPLICATE_REQUEST,
                CONCURRENT_UPDATE, INVALID_AMOUNT, GATEWAY_REJECTED, THREEDS_REJECTED, INVALID_RETURN_URL,
                SAVED_CARD_EXPIRED, GATEWAY_ERROR, GATEWAY_TIMEOUT, INTERNAL_ERROR""",
                example = "INVALID_PAYMENT_STATE")
        String code,

        @Schema(description = "Correlation id of the request (echo of X-Correlation-Id or generated)",
                example = "9b2f6a1e-4c3d-4f7a-9a1b-2c3d4e5f6a7b")
        String correlationId) {
}
