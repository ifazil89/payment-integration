package com.company.payintegration.api.model.payment;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Schema(name = "BrowserInfo", description = """
        Shopper browser data required by EMV 3DS 2.x. Collected by the frontend (navigator.*, screen.*,
        new Date().getTimezoneOffset()); the IP is the shopper IP seen by our backend.""")
public record BrowserInfoDto(

        @Schema(description = "HTTP Accept header of the shopper's browser", example = "text/html,application/xhtml+xml",
                requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 2048)
        String acceptHeader,

        @Schema(description = "navigator.javaEnabled()", example = "false")
        Boolean javaEnabled,

        @Schema(description = "navigator.language", example = "en", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 8)
        String language,

        @Schema(description = "new Date().getTimezoneOffset() in minutes (UTC+4 = -240)", example = "-240")
        @Pattern(regexp = "-?\\d{1,4}")
        String timeZoneOffset,

        @Schema(description = "navigator.userAgent", example = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
                requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 2048)
        String userAgent,

        @Schema(description = "screen.colorDepth", example = "24")
        @Pattern(regexp = "\\d{1,2}")
        String colorDepth,

        @Schema(description = "screen.height", example = "900")
        @Pattern(regexp = "\\d{1,6}")
        String screenHeight,

        @Schema(description = "screen.width", example = "1440")
        @Pattern(regexp = "\\d{1,6}")
        String screenWidth,

        @Schema(example = "true")
        Boolean javascriptEnabled,

        @Schema(description = "Shopper IP address", example = "203.0.113.10", requiredMode = Schema.RequiredMode.REQUIRED)
        @NotBlank @Size(max = 45)
        String ip,

        @Schema(description = "01=250x400, 02=390x400, 03=500x600, 04=600x400, 05=full screen (default)",
                example = "05", allowableValues = {"01", "02", "03", "04", "05"})
        @Pattern(regexp = "0[1-5]")
        String challengeWindowSize) {
}
