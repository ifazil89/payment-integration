package com.company.payintegration.payment.infrastructure.persistence;

import com.company.payintegration.payment.application.port.ConcurrentPaymentUpdateException;
import com.company.payintegration.payment.application.port.DuplicateIdempotencyKeyException;
import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Component
class PaymentRepositoryAdapter implements PaymentRepositoryPort {

    private final PaymentJpaRepository jpa;

    PaymentRepositoryAdapter(PaymentJpaRepository jpa) {
        this.jpa = jpa;
    }

    @Override
    public Payment save(Payment payment) {
        try {
            return jpa.saveAndFlush(PaymentEntity.from(payment)).toDomain();
        } catch (OptimisticLockingFailureException ex) {
            throw new ConcurrentPaymentUpdateException(payment.getId());
        } catch (DataIntegrityViolationException ex) {
            if (payment.getVersion() == null) {          // insert of a new payment
                throw new DuplicateIdempotencyKeyException(payment.getIdempotencyKey());
            }
            throw ex;
        }
    }

    @Override
    public Optional<Payment> findById(String id) {
        return jpa.findById(id).map(PaymentEntity::toDomain);
    }

    @Override
    public Optional<Payment> findByIdempotencyKey(String idempotencyKey) {
        return jpa.findByIdempotencyKey(idempotencyKey).map(PaymentEntity::toDomain);
    }

    @Override
    public Optional<Payment> findByGatewayOrderReference(String orderReference) {
        return jpa.findByOrderReference(orderReference).map(PaymentEntity::toDomain);
    }

    @Override
    public List<Payment> findByStatusCreatedBetween(Collection<PaymentStatus> statuses, Instant from, Instant to,
                                                    int limit) {
        return jpa.findByStatusInAndCreatedAtBetweenOrderByCreatedAtAsc(statuses, from, to, PageRequest.of(0, limit))
                .stream().map(PaymentEntity::toDomain).toList();
    }
}
