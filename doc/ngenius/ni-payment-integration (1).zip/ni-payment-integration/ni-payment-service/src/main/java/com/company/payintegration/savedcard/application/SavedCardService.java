package com.company.payintegration.savedcard.application;

import com.company.payintegration.savedcard.NewSavedCard;
import com.company.payintegration.savedcard.SavedCardFacade;
import com.company.payintegration.savedcard.SavedCardForPayment;
import com.company.payintegration.savedcard.domain.CardExpiry;
import com.company.payintegration.savedcard.domain.SavedCard;
import com.company.payintegration.savedcard.domain.exception.SavedCardNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.util.HexFormat;
import java.util.List;

/**
 * Implements the public SavedCardFacade (used by payment) and the saved-card endpoints.
 *
 * Saved cards come only from successful payments (N-Genius returns savedCard.cardToken).
 * Deleting here removes our copy of the token; if N-Genius offers token deletion on your
 * account, call it from here too.
 */
@Service
public class SavedCardService implements SavedCardFacade {

    private static final Logger log = LoggerFactory.getLogger(SavedCardService.class);

    private final SavedCardRepositoryPort repository;

    public SavedCardService(SavedCardRepositoryPort repository) {
        this.repository = repository;
    }

    @Override
    public String save(NewSavedCard card) {
        String fingerprint = fingerprint(card.cardToken());
        return repository.findByCustomerAndFingerprint(card.customerId(), fingerprint)
                .map(SavedCard::getId)
                .orElseGet(() -> {
                    SavedCard saved = repository.save(SavedCard.create(card.customerId(), card.cardToken(),
                            fingerprint, card.maskedPan(), CardExpiry.parse(card.expiry()), card.cardholderName(),
                            card.scheme()));
                    log.info("Saved card {} ({}) for customer {}", saved.getId(), saved.getMaskedPan(),
                            saved.getCustomerId());
                    return saved.getId();
                });
    }

    @Override
    public SavedCardForPayment getForPayment(String customerId, String savedCardId) {
        SavedCard card = load(customerId, savedCardId);
        card.requireUsable(currentMonth());
        return new SavedCardForPayment(card.getCardToken(), card.getExpiry().toString(), card.getCardholderName());
    }

    public List<SavedCard> list(String customerId) {
        return repository.findByCustomer(customerId);
    }

    public void delete(String customerId, String savedCardId) {
        load(customerId, savedCardId);
        repository.delete(savedCardId);
    }

    public YearMonth currentMonth() {
        return YearMonth.now(ZoneOffset.UTC);
    }

    private SavedCard load(String customerId, String savedCardId) {
        SavedCard card = repository.findById(savedCardId).orElseThrow(() -> new SavedCardNotFoundException(savedCardId));
        card.requireOwnedBy(customerId);
        return card;
    }

    private static String fingerprint(String token) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(token.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
