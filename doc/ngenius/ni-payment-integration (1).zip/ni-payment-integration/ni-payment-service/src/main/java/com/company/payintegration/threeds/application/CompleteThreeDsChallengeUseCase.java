package com.company.payintegration.threeds.application;

import com.company.payintegration.threeds.ThreeDsCompletedEvent;
import com.company.payintegration.threeds.application.port.ThreeDsGatewayPort;
import com.company.payintegration.threeds.application.port.ThreeDsSessionRepositoryPort;
import com.company.payintegration.threeds.domain.ThreeDsSession;
import com.company.payintegration.threeds.domain.ThreeDsSessionStatus;
import com.company.payintegration.threeds.domain.exception.ThreeDsSessionNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * Steps 3 + 4: the ACS posted "cres" (through the shopper's browser) to our notificationURL.
 * We pass it unchanged to N-Genius, publish ThreeDsCompletedEvent (payment refreshes its
 * status) and return the URL to send the shopper back to.
 */
@Service
public class CompleteThreeDsChallengeUseCase {

    private static final Logger log = LoggerFactory.getLogger(CompleteThreeDsChallengeUseCase.class);

    private final ThreeDsSessionRepositoryPort repository;
    private final ThreeDsGatewayPort gateway;
    private final ApplicationEventPublisher events;
    private final ThreeDsUrls urls;

    CompleteThreeDsChallengeUseCase(ThreeDsSessionRepositoryPort repository, ThreeDsGatewayPort gateway,
                                    ApplicationEventPublisher events, ThreeDsUrls urls) {
        this.repository = repository;
        this.gateway = gateway;
        this.events = events;
        this.urls = urls;
    }

    /** @return URL to redirect the shopper's browser to */
    public String execute(String sessionId, String cres) {
        ThreeDsSession session = repository.findById(sessionId)
                .orElseThrow(() -> new ThreeDsSessionNotFoundException(sessionId));
        String redirect = urls.returnUrlFor(session.getReturnUrl(), session.getPaymentId());

        if (session.getStatus() != ThreeDsSessionStatus.CHALLENGE_REQUIRED) {
            // e.g. the browser posted twice: don't submit again, just send the shopper back
            log.info("3DS session {} already {}, ignoring notification", sessionId, session.getStatus());
            return redirect;
        }

        if (session.isExpired(Instant.now())) {
            session.expire();
            repository.save(session);
            log.warn("3DS session {} expired before the challenge result arrived", sessionId);
        } else {
            try {
                gateway.submitChallengeResult(session.getOrderReference(), session.getPaymentReference(), cres);
                session.complete();
            } catch (RuntimeException ex) {
                log.error("Submitting 3DS result for session {} failed: {}", sessionId, ex.toString());
                session.fail();
            }
            repository.save(session);
        }

        // Always let the payment re-read its status: the gateway decides the outcome.
        events.publishEvent(new ThreeDsCompletedEvent(session.getId(), session.getPaymentId()));
        return redirect;
    }
}
