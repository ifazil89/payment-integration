package com.company.payintegration.payment.application;

import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.threeds.ThreeDsChallenge;

/** A payment plus, if the shopper must complete a 3DS challenge, what the frontend needs for it. */
public record PaymentOutcome(Payment payment, ThreeDsChallenge threeDsChallenge) {

    public static PaymentOutcome of(Payment payment) {
        return new PaymentOutcome(payment, null);
    }
}
