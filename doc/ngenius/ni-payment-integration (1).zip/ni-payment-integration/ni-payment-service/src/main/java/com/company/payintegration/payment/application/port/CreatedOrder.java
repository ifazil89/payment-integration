package com.company.payintegration.payment.application.port;

import com.company.payintegration.payment.domain.GatewayReference;

/**
 * Result of creating the gateway order. The hrefs are opaque: the application layer only
 * hands them back to the gateway port.
 */
public record CreatedOrder(GatewayReference reference, String cardPaymentHref, String savedCardPaymentHref) {
}
