package com.company.payintegration.threeds.application.port;

import com.company.payintegration.shared.domain.BusinessException;

public class ThreeDsRejectedException extends BusinessException {

    public ThreeDsRejectedException(String message) {
        super(Kind.INVALID, "THREEDS_REJECTED", message);
    }
}
