package com.company.payintegration.threeds.application.port;

/** Result of the 3DS2 authentication call. */
public record AuthenticationResult(
        String transStatus,
        String acsUrl,
        String base64EncodedCReq,
        String threeDsServerTransId,
        String acsTransId,
        String messageVersion,
        String gatewayState) {
}
