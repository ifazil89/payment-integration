package com.company.payintegration.savedcard.infrastructure;

import com.company.payintegration.savedcard.application.SavedCardRepositoryPort;
import com.company.payintegration.savedcard.domain.CardExpiry;
import com.company.payintegration.savedcard.domain.SavedCard;
import com.company.payintegration.shared.infrastructure.crypto.AesGcmCipher;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/** Encrypts the token on the way in, decrypts it on the way out. */
@Component
class SavedCardRepositoryAdapter implements SavedCardRepositoryPort {

    private final SavedCardJpaRepository jpa;
    private final AesGcmCipher cipher;

    SavedCardRepositoryAdapter(SavedCardJpaRepository jpa, AesGcmCipher cipher) {
        this.jpa = jpa;
        this.cipher = cipher;
    }

    @Override
    public SavedCard save(SavedCard card) {
        SavedCardEntity e = new SavedCardEntity();
        e.id = card.getId();
        e.customerId = card.getCustomerId();
        e.cardTokenEncrypted = cipher.encrypt(card.getCardToken());
        e.tokenFingerprint = card.getTokenFingerprint();
        e.maskedPan = card.getMaskedPan();
        e.expiry = card.getExpiry().toString();
        e.cardholderName = card.getCardholderName();
        e.scheme = card.getScheme();
        e.createdAt = card.getCreatedAt();
        return toDomain(jpa.save(e));
    }

    @Override
    public Optional<SavedCard> findById(String id) {
        return jpa.findById(id).map(this::toDomain);
    }

    @Override
    public Optional<SavedCard> findByCustomerAndFingerprint(String customerId, String tokenFingerprint) {
        return jpa.findByCustomerIdAndTokenFingerprint(customerId, tokenFingerprint).map(this::toDomain);
    }

    @Override
    public List<SavedCard> findByCustomer(String customerId) {
        return jpa.findByCustomerIdOrderByCreatedAtDesc(customerId).stream().map(this::toDomain).toList();
    }

    @Override
    public void delete(String id) {
        jpa.deleteById(id);
    }

    private SavedCard toDomain(SavedCardEntity e) {
        return SavedCard.restore(e.id, e.customerId, cipher.decrypt(e.cardTokenEncrypted), e.tokenFingerprint,
                e.maskedPan, CardExpiry.parse(e.expiry), e.cardholderName, e.scheme, e.createdAt);
    }
}
