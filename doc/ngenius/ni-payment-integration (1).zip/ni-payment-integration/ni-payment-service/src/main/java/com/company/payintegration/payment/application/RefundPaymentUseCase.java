package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.GatewayResult;
import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.payment.domain.exception.PaymentNotFoundException;
import com.company.payintegration.shared.domain.Money;
import org.springframework.stereotype.Service;

/** Refunds all or part of the captured amount. */
@Service
public class RefundPaymentUseCase {

    private final PaymentRepositoryPort repository;
    private final PaymentGatewayPort gateway;
    private final PaymentStatusUpdater updater;

    public RefundPaymentUseCase(PaymentRepositoryPort repository, PaymentGatewayPort gateway,
                                PaymentStatusUpdater updater) {
        this.repository = repository;
        this.gateway = gateway;
        this.updater = updater;
    }

    public Payment execute(String paymentId, Money amount) {
        Payment payment = repository.findById(paymentId).orElseThrow(() -> new PaymentNotFoundException(paymentId));
        PaymentStatus before = payment.getStatus();

        payment.ensureCanRefund(amount);
        GatewayResult result = gateway.refund(payment.getGatewayReference(), amount);
        payment.recordRefund(amount);

        return updater.apply(payment, before, result);
    }
}
