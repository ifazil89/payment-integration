package com.company.payintegration.payment.domain.exception;

import com.company.payintegration.shared.domain.BusinessException;

public class PaymentNotFoundException extends BusinessException {

    public PaymentNotFoundException(String paymentId) {
        super(Kind.NOT_FOUND, "PAYMENT_NOT_FOUND", "Payment not found: " + paymentId);
    }
}
