package com.company.payintegration.shared.infrastructure.ngenius;

import org.springframework.http.MediaType;

/** Vendor media types required by N-Genius. Plain application/json is rejected. */
public final class NgeniusMediaTypes {

    public static final MediaType PAYMENT_V2 = MediaType.parseMediaType("application/vnd.ni-payment.v2+json");
    public static final MediaType IDENTITY_V1 = MediaType.parseMediaType("application/vnd.ni-identity.v1+json");

    private NgeniusMediaTypes() {
    }
}
