package com.company.payintegration.savedcard;

/** In-process facade of the savedcard feature (used by payment). Not an HTTP API. */
public interface SavedCardFacade {

    /** Stores the card; saving the same token twice for a customer is a no-op. Returns the saved card id. */
    String save(NewSavedCard card);

    /** Token data for a payment. Fails if the card is unknown, not the customer's, or expired. */
    SavedCardForPayment getForPayment(String customerId, String savedCardId);
}
