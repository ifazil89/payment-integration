package com.company.payintegration.webhook;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PostPersist;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.springframework.data.domain.Persistable;

import java.time.Instant;

/**
 * One received webhook. The eventId primary key makes duplicates impossible.
 *
 * Implements Persistable so that saving a NEW event always INSERTs (and fails on a
 * duplicate eventId) instead of silently merging into the existing row.
 */
@Entity
@Table(name = "webhook_event")
class WebhookEventEntity implements Persistable<String> {

    @Id
    @Column(name = "event_id")
    String eventId;
    @Column(name = "event_name")
    String eventName;
    @Column(name = "order_reference")
    String orderReference;
    @Column(name = "received_at", nullable = false)
    Instant receivedAt;
    @Column(name = "processed_at")
    Instant processedAt;
    @Column(name = "result", length = 500)
    String result;

    @Transient
    private boolean isNew = true;

    protected WebhookEventEntity() {
    }

    WebhookEventEntity(String eventId, String eventName, String orderReference) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.orderReference = orderReference;
        this.receivedAt = Instant.now();
    }

    @Override
    public String getId() {
        return eventId;
    }

    @Override
    public boolean isNew() {
        return isNew;
    }

    @PostLoad
    @PostPersist
    void markNotNew() {
        this.isNew = false;
    }
}
