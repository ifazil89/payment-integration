package com.company.payintegration.payment.application;

import com.company.payintegration.payment.PaymentFacade;
import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import org.springframework.stereotype.Service;

/**
 * Implements the public PaymentFacade. Used by the webhook feature.
 *
 * It deliberately does NOT trust the webhook payload's state: N-Genius advises not to rely
 * on eventName/state alone, so we re-read the order (GET) and apply what it says.
 */
@Service
class ApplyGatewayUpdateService implements PaymentFacade {

    private final PaymentRepositoryPort repository;
    private final PaymentStatusUpdater updater;

    ApplyGatewayUpdateService(PaymentRepositoryPort repository, PaymentStatusUpdater updater) {
        this.repository = repository;
        this.updater = updater;
    }

    @Override
    public boolean refreshFromGateway(String gatewayOrderReference) {
        return repository.findByGatewayOrderReference(gatewayOrderReference)
                .map(payment -> {
                    updater.refresh(payment.getId());
                    return true;
                })
                .orElse(false);
    }
}
