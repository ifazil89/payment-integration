package com.company.payintegration.savedcard.domain.exception;

import com.company.payintegration.shared.domain.BusinessException;

public class SavedCardNotFoundException extends BusinessException {

    public SavedCardNotFoundException(String savedCardId) {
        super(Kind.NOT_FOUND, "SAVED_CARD_NOT_FOUND", "Saved card not found: " + savedCardId);
    }
}
