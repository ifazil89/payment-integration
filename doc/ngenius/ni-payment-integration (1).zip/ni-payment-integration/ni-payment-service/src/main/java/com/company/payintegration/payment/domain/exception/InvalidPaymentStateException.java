package com.company.payintegration.payment.domain.exception;

import com.company.payintegration.shared.domain.BusinessException;

public class InvalidPaymentStateException extends BusinessException {

    public InvalidPaymentStateException(String message) {
        super(Kind.CONFLICT, "INVALID_PAYMENT_STATE", message);
    }
}
