package com.company.payintegration.payment.infrastructure.backend;

import com.company.payintegration.payment.application.port.BackendNotifierPort;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.shared.infrastructure.config.AppProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * POSTs payment status changes to our backend (app.backend.callback-url).
 *
 * Best effort: a failed callback is logged, and the backend can always GET the payment.
 * For guaranteed delivery, replace with a transactional outbox + Kafka/SQS.
 */
@Component
class BackendCallbackAdapter implements BackendNotifierPort {

    private static final Logger log = LoggerFactory.getLogger(BackendCallbackAdapter.class);

    private final RestClient restClient;
    private final String callbackUrl;

    BackendCallbackAdapter(RestClient.Builder builder, AppProperties appProperties) {
        this.restClient = builder.clone().build();
        this.callbackUrl = appProperties.backend().callbackUrl();
    }

    @Override
    public void paymentStatusChanged(Payment payment) {
        PaymentStatusCallback body = new PaymentStatusCallback(payment.getId(), payment.getMerchantOrderId(),
                payment.getStatus().name(), payment.getAmount().amount(), payment.getAmount().currency(),
                payment.getCapturedAmount().amount(), payment.getRefundedAmount().amount(), Instant.now());

        if (!StringUtils.hasText(callbackUrl)) {
            log.info("Payment {} status {} (no backend callback configured)", payment.getId(), payment.getStatus());
            return;
        }
        try {
            String correlationId = MDC.get("correlationId");
            restClient.post()
                    .uri(callbackUrl)
                    .contentType(MediaType.APPLICATION_JSON)
                    .headers(h -> {
                        if (correlationId != null) {
                            h.set("X-Correlation-Id", correlationId);
                        }
                    })
                    .body(body)
                    .retrieve()
                    .toBodilessEntity();
        } catch (RuntimeException ex) {
            log.warn("Backend callback for payment {} failed: {}", payment.getId(), ex.toString());
        }
    }

    record PaymentStatusCallback(String paymentId, String merchantOrderId, String status, BigDecimal amount,
                                 String currency, BigDecimal capturedAmount, BigDecimal refundedAmount,
                                 Instant occurredAt) {
    }
}
