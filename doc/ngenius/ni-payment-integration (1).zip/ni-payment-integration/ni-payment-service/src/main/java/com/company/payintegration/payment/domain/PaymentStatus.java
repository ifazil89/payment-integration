package com.company.payintegration.payment.domain;

/**
 * Our own payment status. N-Genius states are mapped to these in the infrastructure layer,
 * so our backend never depends on N-Genius naming.
 *
 * "progress" orders the normal life cycle. A status only moves forward, which protects us
 * from late or out-of-order webhooks (e.g. AUTHORISED arriving after CAPTURED).
 */
public enum PaymentStatus {

    CREATED(0),
    AWAITING_3DS(1),
    AUTHORISED(2),
    PARTIALLY_CAPTURED(3),
    CAPTURED(4),
    PARTIALLY_REFUNDED(5),
    REFUNDED(6),
    REVERSED(-1),
    DECLINED(-1),
    FAILED(-1);

    private final int progress;

    PaymentStatus(int progress) {
        this.progress = progress;
    }

    public int progress() {
        return progress;
    }

    /** No further change is possible. */
    public boolean isTerminal() {
        return this == REFUNDED || this == REVERSED || this == DECLINED || this == FAILED;
    }

    public boolean isFailure() {
        return this == DECLINED || this == FAILED;
    }

    public boolean isBeforeAuthorisation() {
        return this == CREATED || this == AWAITING_3DS;
    }

    /** Money was authorised (and maybe captured or refunded). */
    public boolean isAuthorisedOrLater() {
        return progress >= AUTHORISED.progress;
    }
}
