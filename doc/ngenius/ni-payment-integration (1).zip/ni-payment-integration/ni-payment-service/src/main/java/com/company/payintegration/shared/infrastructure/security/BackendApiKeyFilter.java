package com.company.payintegration.shared.infrastructure.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Protects /api/** (called only by our backend) with a shared API key.
 *
 * Skeleton-level protection. For production prefer mTLS between backend and middleware,
 * or OAuth2 client-credentials (spring-boot-starter-oauth2-resource-server), and keep the
 * service on a private network.
 */
class BackendApiKeyFilter extends OncePerRequestFilter {

    static final String HEADER = "X-Api-Key";

    private final byte[] expectedKey;

    BackendApiKeyFilter(String expectedKey) {
        this.expectedKey = expectedKey.getBytes(StandardCharsets.UTF_8);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        String provided = request.getHeader(HEADER);
        boolean valid = provided != null
                && MessageDigest.isEqual(expectedKey, provided.getBytes(StandardCharsets.UTF_8));   // constant time
        if (!valid) {
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            response.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);
            response.getWriter().write("{\"status\":401,\"code\":\"UNAUTHORIZED\",\"detail\":\"Missing or invalid X-Api-Key\"}");
            return;
        }
        chain.doFilter(request, response);
    }
}
