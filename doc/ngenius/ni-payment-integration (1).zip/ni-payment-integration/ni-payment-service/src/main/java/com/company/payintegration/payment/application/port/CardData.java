package com.company.payintegration.payment.application.port;

import com.company.payintegration.shared.util.SensitiveDataMasker;

/** Raw card details. Lives only in memory for the duration of one request. Never stored. */
public record CardData(String pan, String expiry, String cvv, String cardholderName) {

    @Override
    public String toString() {
        return "CardData[pan=" + SensitiveDataMasker.maskPan(pan) + ", expiry=" + expiry + ", cvv=***]";
    }
}
