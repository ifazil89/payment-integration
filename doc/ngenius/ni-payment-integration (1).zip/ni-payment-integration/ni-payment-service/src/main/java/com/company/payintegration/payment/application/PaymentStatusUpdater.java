package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.BackendNotifierPort;
import com.company.payintegration.payment.application.port.ConcurrentPaymentUpdateException;
import com.company.payintegration.payment.application.port.GatewayResult;
import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.payment.domain.TokenizedCard;
import com.company.payintegration.payment.domain.exception.PaymentNotFoundException;
import com.company.payintegration.savedcard.NewSavedCard;
import com.company.payintegration.savedcard.SavedCardFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * The single place where a payment is saved after talking to the gateway:
 * apply gateway status -> save -> notify backend if the status changed -> save card if asked.
 * API responses, 3DS completion, webhooks and reconciliation all go through here.
 */
@Component
public class PaymentStatusUpdater {

    private static final Logger log = LoggerFactory.getLogger(PaymentStatusUpdater.class);
    private static final int MAX_ATTEMPTS = 2;

    private final PaymentRepositoryPort repository;
    private final PaymentGatewayPort gateway;
    private final BackendNotifierPort notifier;
    private final SavedCardFacade savedCardFacade;

    public PaymentStatusUpdater(PaymentRepositoryPort repository, PaymentGatewayPort gateway,
                                BackendNotifierPort notifier, SavedCardFacade savedCardFacade) {
        this.repository = repository;
        this.gateway = gateway;
        this.notifier = notifier;
        this.savedCardFacade = savedCardFacade;
    }

    /** @param previousStatus status before the current operation started (to detect a change) */
    public Payment apply(Payment payment, PaymentStatus previousStatus, GatewayResult result) {
        if (result != null && payment.applyGatewayStatus(result.status())) {
            log.info("Payment {} {} -> {} (gateway state {})",
                    payment.getId(), previousStatus, payment.getStatus(), result.gatewayState());
        }
        Payment saved = repository.save(payment);
        if (saved.getStatus() != previousStatus) {
            notifier.paymentStatusChanged(saved);
        }
        if (result != null) {
            saveCardIfRequested(saved, result.savedCard());
        }
        return saved;
    }

    public Payment save(Payment payment, PaymentStatus previousStatus) {
        return apply(payment, previousStatus, null);
    }

    /** Re-reads the status from the gateway; retries once if another thread updated the payment meanwhile. */
    public Payment refresh(String paymentId) {
        for (int attempt = 1; ; attempt++) {
            Payment payment = repository.findById(paymentId).orElseThrow(() -> new PaymentNotFoundException(paymentId));
            if (payment.getGatewayReference() == null || payment.getStatus().isTerminal()) {
                return payment;
            }
            GatewayResult result = gateway.fetchStatus(payment.getGatewayReference());
            try {
                return apply(payment, payment.getStatus(), result);
            } catch (ConcurrentPaymentUpdateException ex) {
                if (attempt >= MAX_ATTEMPTS) {
                    throw ex;
                }
                log.debug("Concurrent update of payment {}, retrying refresh", paymentId);
            }
        }
    }

    private void saveCardIfRequested(Payment payment, TokenizedCard card) {
        if (!payment.isSaveCardRequested() || card == null || !payment.getStatus().isAuthorisedOrLater()) {
            return;
        }
        try {
            savedCardFacade.save(new NewSavedCard(payment.getCustomerId(), card.cardToken(), card.maskedPan(),
                    card.expiry(), card.cardholderName(), card.scheme()));
        } catch (RuntimeException ex) {
            // The payment succeeded; failing to save the card must not fail it.
            log.warn("Could not save card for payment {}: {}", payment.getId(), ex.toString());
        }
    }
}
