package com.company.payintegration.threeds;

/**
 * Shopper browser data required by EMV 3DS 2.x (collected by the frontend).
 * Public type of the threeds feature.
 */
public record BrowserInfo(
        String acceptHeader,
        Boolean javaEnabled,
        String language,
        String timeZoneOffset,      // minutes, e.g. "-240" for UTC+4
        String userAgent,
        String colorDepth,
        String screenHeight,
        String screenWidth,
        Boolean javascriptEnabled,
        String ip,
        String challengeWindowSize  // "01".."05"; null = "05" full screen
) {
}
