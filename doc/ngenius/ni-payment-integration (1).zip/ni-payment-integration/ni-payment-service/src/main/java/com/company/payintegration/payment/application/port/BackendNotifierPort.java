package com.company.payintegration.payment.application.port;

import com.company.payintegration.payment.domain.Payment;

/** Tells our backend that a payment status changed (HTTP callback, Kafka, ...). */
public interface BackendNotifierPort {

    void paymentStatusChanged(Payment payment);
}
