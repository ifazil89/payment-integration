package com.company.payintegration.webhook;

import org.springframework.data.jpa.repository.JpaRepository;

interface WebhookEventJpaRepository extends JpaRepository<WebhookEventEntity, String> {
}
