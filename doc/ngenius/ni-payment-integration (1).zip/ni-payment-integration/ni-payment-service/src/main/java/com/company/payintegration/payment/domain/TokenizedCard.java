package com.company.payintegration.payment.domain;

/** Card token returned by the gateway after a successful payment (if tokenisation is on). */
public record TokenizedCard(String cardToken, String maskedPan, String expiry,
                            String cardholderName, String scheme) {

    @Override
    public String toString() {
        return "TokenizedCard[maskedPan=" + maskedPan + ", scheme=" + scheme + "]";
    }
}
