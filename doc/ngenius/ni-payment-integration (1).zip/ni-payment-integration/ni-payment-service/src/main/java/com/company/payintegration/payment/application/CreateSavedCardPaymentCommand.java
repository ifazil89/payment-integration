package com.company.payintegration.payment.application;

public record CreateSavedCardPaymentCommand(NewPaymentData payment, String savedCardId, String cvv) {

    @Override
    public String toString() {
        return "CreateSavedCardPaymentCommand[payment=" + payment + ", savedCardId=" + savedCardId + ", cvv=***]";
    }
}
