package com.company.payintegration.payment.infrastructure.ngenius;

import com.company.payintegration.payment.application.port.CardData;
import com.company.payintegration.payment.application.port.CreatedOrder;
import com.company.payintegration.payment.application.port.CustomerDetails;
import com.company.payintegration.payment.application.port.GatewayRejectedException;
import com.company.payintegration.payment.application.port.GatewayResult;
import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.payment.domain.GatewayReference;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.TokenizedCard;
import com.company.payintegration.payment.infrastructure.ngenius.dto.NgeniusAmountRequest;
import com.company.payintegration.payment.infrastructure.ngenius.dto.NgeniusCardPaymentRequest;
import com.company.payintegration.payment.infrastructure.ngenius.dto.NgeniusCreateOrderRequest;
import com.company.payintegration.payment.infrastructure.ngenius.dto.NgeniusSavedCardPaymentRequest;
import com.company.payintegration.savedcard.SavedCardForPayment;
import com.company.payintegration.shared.domain.Money;
import com.company.payintegration.shared.infrastructure.ngenius.MinorUnitConverter;
import com.company.payintegration.shared.infrastructure.ngenius.NgeniusApiClient;
import com.company.payintegration.shared.infrastructure.ngenius.NgeniusApiException;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusCaptureResource;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusLinkRelations;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusOrderResource;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusPaymentResource;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusSavedCard;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.function.Supplier;

/**
 * PaymentGatewayPort implemented with the N-Genius Direct API (two-stage payments).
 *
 * Links (payment:card, cnp:capture, cnp:cancel, ...) are always taken from N-Genius
 * responses; for later operations the order is re-read with GET so links are current.
 */
@Component
class NgeniusPaymentGatewayAdapter implements PaymentGatewayPort {

    private static final Logger log = LoggerFactory.getLogger(NgeniusPaymentGatewayAdapter.class);

    private final NgeniusApiClient client;

    NgeniusPaymentGatewayAdapter(NgeniusApiClient client) {
        this.client = client;
    }

    @Override
    public CreatedOrder createOrder(Payment payment, CustomerDetails customer) {
        NgeniusCreateOrderRequest body = new NgeniusCreateOrderRequest(
                NgeniusCreateOrderRequest.ACTION_AUTH,
                MinorUnitConverter.toNgenius(payment.getAmount()),
                customer.email(),
                payment.getMerchantOrderId(),
                new NgeniusCreateOrderRequest.BillingAddress(customer.firstName(), customer.lastName()));

        NgeniusOrderResource order = call("create order", () -> client.createOrder(body));
        NgeniusPaymentResource first = order.requireFirstPayment();

        return new CreatedOrder(
                new GatewayReference(client.outletId(), order.reference(), first.reference()),
                first.link(NgeniusLinkRelations.PAYMENT_CARD).orElse(null),
                first.link(NgeniusLinkRelations.PAYMENT_SAVED_CARD).orElse(null));
    }

    @Override
    public GatewayResult payWithCard(CreatedOrder order, CardData card) {
        String href = require(order.cardPaymentHref(), NgeniusLinkRelations.PAYMENT_CARD);
        NgeniusCardPaymentRequest body =
                new NgeniusCardPaymentRequest(card.pan(), card.expiry(), card.cvv(), card.cardholderName());
        return toResult(call("card payment", () -> client.putToLink(href, body)));
    }

    @Override
    public GatewayResult payWithSavedCard(CreatedOrder order, SavedCardForPayment card, String cvv) {
        String href = require(order.savedCardPaymentHref(), NgeniusLinkRelations.PAYMENT_SAVED_CARD);
        NgeniusSavedCardPaymentRequest body =
                new NgeniusSavedCardPaymentRequest(card.cardToken(), card.expiry(), cvv, card.cardholderName());
        return toResult(call("saved card payment", () -> client.putToLink(href, body)));
    }

    @Override
    public GatewayResult fetchStatus(GatewayReference reference) {
        return toResult(currentPayment(reference));
    }

    @Override
    public GatewayResult capture(GatewayReference reference, Money amount) {
        String href = currentPayment(reference).requireLink(NgeniusLinkRelations.CAPTURE);
        NgeniusAmountRequest body = new NgeniusAmountRequest(MinorUnitConverter.toNgenius(amount));
        return toResult(call("capture", () -> client.postToLink(href, body)));
    }

    @Override
    public GatewayResult reverse(GatewayReference reference) {
        String href = currentPayment(reference).requireLink(NgeniusLinkRelations.CANCEL);
        return toResult(call("reverse authorisation", () -> client.putToLink(href, null)));
    }

    /**
     * Captured payments are refunded per capture: POST {capture self href}/refund.
     * PURCHASED (one-stage) payments use the payment's "cnp:refund" link.
     * This skeleton refunds against the latest successful capture; with several partial
     * captures you may need to split a refund across captures.
     */
    @Override
    public GatewayResult refund(GatewayReference reference, Money amount) {
        NgeniusPaymentResource payment = currentPayment(reference);
        List<NgeniusCaptureResource> captures = payment.captures().stream()
                .filter(NgeniusCaptureResource::isSuccessful)
                .toList();

        String href = captures.isEmpty()
                ? payment.requireLink(NgeniusLinkRelations.REFUND)
                : captures.getLast().selfHref()
                        .map(self -> self + "/refund")
                        .orElseThrow(() -> new IllegalStateException("Capture without self link on payment "
                                + reference.paymentReference()));

        NgeniusAmountRequest body = new NgeniusAmountRequest(MinorUnitConverter.toNgenius(amount));
        return toResult(call("refund", () -> client.postToLink(href, body)));
    }

    // ------------------------------------------------------------------ helpers

    private NgeniusPaymentResource currentPayment(GatewayReference reference) {
        NgeniusOrderResource order = call("get order", () -> client.getOrder(reference.orderReference()));
        return order.payment(reference.paymentReference()).orElseGet(order::requireFirstPayment);
    }

    private static GatewayResult toResult(NgeniusPaymentResource payment) {
        NgeniusSavedCard saved = payment.savedCard();
        TokenizedCard card = saved == null || saved.cardToken() == null ? null
                : new TokenizedCard(saved.cardToken(), saved.maskedPan(), saved.expiry(),
                saved.cardholderName(), saved.scheme());
        return new GatewayResult(NgeniusStateMapper.map(payment.state()), payment.state(), card);
    }

    private static String require(String href, String relation) {
        if (href == null) {
            throw new IllegalStateException("N-Genius order has no '" + relation + "' link; "
                    + "check that this payment method is enabled on the outlet");
        }
        return href;
    }

    /** 4xx from N-Genius = rejected (known outcome). 5xx and timeouts pass through unchanged. */
    private static <T> T call(String operation, Supplier<T> call) {
        try {
            return call.get();
        } catch (NgeniusApiException ex) {
            if (ex.isClientError()) {
                log.warn("N-Genius rejected {}: HTTP {} {}", operation, ex.getStatus(), ex.getResponseBody());
                throw new GatewayRejectedException("Gateway rejected " + operation + " (HTTP " + ex.getStatus() + ")");
            }
            throw ex;
        }
    }
}
