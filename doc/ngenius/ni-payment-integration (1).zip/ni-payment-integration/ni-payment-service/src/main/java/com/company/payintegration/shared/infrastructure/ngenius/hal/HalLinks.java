package com.company.payintegration.shared.infrastructure.ngenius.hal;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Reads hrefs from N-Genius "_links" blocks.
 *
 * The block is kept as a raw map because values are not uniform: most are {"href": "..."},
 * but some (for example "curies") are arrays.
 */
public final class HalLinks {

    private HalLinks() {
    }

    public static Optional<String> href(Map<String, Object> links, String relation) {
        if (links == null) {
            return Optional.empty();
        }
        Object value = links.get(relation);
        if (value instanceof Map<?, ?> link && link.get("href") instanceof String href) {
            return Optional.of(href);
        }
        if (value instanceof List<?> list && !list.isEmpty()
                && list.getFirst() instanceof Map<?, ?> first && first.get("href") instanceof String href) {
            return Optional.of(href);
        }
        return Optional.empty();
    }
}
