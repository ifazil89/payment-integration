package com.company.payintegration.threeds.infrastructure.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

interface ThreeDsSessionJpaRepository extends JpaRepository<ThreeDsSessionEntity, String> {
}
