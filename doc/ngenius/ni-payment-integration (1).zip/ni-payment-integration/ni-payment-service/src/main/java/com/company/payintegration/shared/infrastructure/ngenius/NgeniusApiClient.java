package com.company.payintegration.shared.infrastructure.ngenius;

import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusOrderResource;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusPaymentResource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.net.URI;

/**
 * Low-level N-Genius calls shared by all features. It knows HTTP, URLs and media types,
 * nothing about our business. Feature adapters (payment, threeds) build on top of it.
 */
@Component
public class NgeniusApiClient {

    private final RestClient restClient;
    private final NgeniusProperties properties;
    private final String trustedHost;

    public NgeniusApiClient(@Qualifier("ngeniusRestClient") RestClient restClient, NgeniusProperties properties) {
        this.restClient = restClient;
        this.properties = properties;
        this.trustedHost = URI.create(properties.baseUrl()).getHost();
    }

    public String outletId() {
        return properties.outletId();
    }

    /** POST /transactions/outlets/{outletId}/orders */
    public NgeniusOrderResource createOrder(Object body) {
        return restClient.post()
                .uri("/transactions/outlets/{outletId}/orders", properties.outletId())
                .contentType(NgeniusMediaTypes.PAYMENT_V2)
                .body(body)
                .retrieve()
                .body(NgeniusOrderResource.class);
    }

    /** GET /transactions/outlets/{outletId}/orders/{orderRef}: the source of truth for status. */
    public NgeniusOrderResource getOrder(String orderReference) {
        return restClient.get()
                .uri("/transactions/outlets/{outletId}/orders/{orderRef}", properties.outletId(), orderReference)
                .retrieve()
                .body(NgeniusOrderResource.class);
    }

    /** PUT to a link taken from a previous response. body may be null (e.g. cnp:cancel). */
    public NgeniusPaymentResource putToLink(String href, Object body) {
        RestClient.RequestBodySpec request = restClient.put()
                .uri(trusted(href))
                .contentType(NgeniusMediaTypes.PAYMENT_V2);
        if (body != null) {
            request = request.body(body);
        }
        return request.retrieve().body(NgeniusPaymentResource.class);
    }

    /** POST to a link taken from a previous response. */
    public NgeniusPaymentResource postToLink(String href, Object body) {
        RestClient.RequestBodySpec request = restClient.post()
                .uri(trusted(href))
                .contentType(NgeniusMediaTypes.PAYMENT_V2);
        if (body != null) {
            request = request.body(body);
        }
        return request.retrieve().body(NgeniusPaymentResource.class);
    }

    /**
     * Links come from responses or from our database. Only ever send our bearer token
     * (and card data) to the configured N-Genius host.
     */
    private URI trusted(String href) {
        URI uri = URI.create(href);
        if (!"https".equalsIgnoreCase(uri.getScheme()) || !trustedHost.equalsIgnoreCase(uri.getHost())) {
            throw new IllegalStateException("Refusing to call untrusted N-Genius link host: " + uri.getHost());
        }
        return uri;
    }
}
