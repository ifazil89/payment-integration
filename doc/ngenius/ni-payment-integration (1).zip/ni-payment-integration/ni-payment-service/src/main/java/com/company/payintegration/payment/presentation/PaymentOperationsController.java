package com.company.payintegration.payment.presentation;

import com.company.payintegration.api.interfaces.PaymentOperationsApi;
import com.company.payintegration.api.model.payment.CapturePaymentRequest;
import com.company.payintegration.api.model.payment.PaymentResponse;
import com.company.payintegration.api.model.payment.RefundPaymentRequest;
import com.company.payintegration.payment.application.CapturePaymentUseCase;
import com.company.payintegration.payment.application.RefundPaymentUseCase;
import com.company.payintegration.payment.application.ReversePaymentUseCase;
import com.company.payintegration.shared.domain.Money;
import com.company.payintegration.shared.presentation.MoneyMapper;
import org.springframework.web.bind.annotation.RestController;

/** Implements the PaymentOperationsApi contract (capture, reverse, refund). */
@RestController
class PaymentOperationsController implements PaymentOperationsApi {

    private final CapturePaymentUseCase capturePayment;
    private final ReversePaymentUseCase reversePayment;
    private final RefundPaymentUseCase refundPayment;

    PaymentOperationsController(CapturePaymentUseCase capturePayment, ReversePaymentUseCase reversePayment,
                                RefundPaymentUseCase refundPayment) {
        this.capturePayment = capturePayment;
        this.reversePayment = reversePayment;
        this.refundPayment = refundPayment;
    }

    @Override
    public PaymentResponse capturePayment(String paymentId, CapturePaymentRequest request) {
        Money amount = request != null && request.amount() != null ? MoneyMapper.toDomain(request.amount()) : null;
        return PaymentPresentationMapper.toResponse(capturePayment.execute(paymentId, amount));
    }

    @Override
    public PaymentResponse reversePayment(String paymentId) {
        return PaymentPresentationMapper.toResponse(reversePayment.execute(paymentId));
    }

    @Override
    public PaymentResponse refundPayment(String paymentId, RefundPaymentRequest request) {
        return PaymentPresentationMapper.toResponse(
                refundPayment.execute(paymentId, MoneyMapper.toDomain(request.amount())));
    }
}
