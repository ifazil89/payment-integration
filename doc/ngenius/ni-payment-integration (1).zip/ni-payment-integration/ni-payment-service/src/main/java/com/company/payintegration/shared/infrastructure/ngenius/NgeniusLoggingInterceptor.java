package com.company.payintegration.shared.infrastructure.ngenius;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;

/**
 * Logs method, path, status and duration of every N-Genius call.
 * Bodies are NEVER logged: requests contain card numbers and CVVs.
 */
class NgeniusLoggingInterceptor implements ClientHttpRequestInterceptor {

    private static final Logger log = LoggerFactory.getLogger(NgeniusLoggingInterceptor.class);

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                                        ClientHttpRequestExecution execution) throws IOException {
        long start = System.nanoTime();
        try {
            ClientHttpResponse response = execution.execute(request, body);
            log.info("N-Genius {} {} -> {} in {} ms", request.getMethod(), request.getURI().getPath(),
                    response.getStatusCode().value(), (System.nanoTime() - start) / 1_000_000);
            return response;
        } catch (IOException ex) {
            log.warn("N-Genius {} {} failed after {} ms: {}", request.getMethod(), request.getURI().getPath(),
                    (System.nanoTime() - start) / 1_000_000, ex.toString());
            throw ex;
        }
    }
}
