package com.company.payintegration.shared.infrastructure.ngenius.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;
import java.util.Optional;

/** One entry of payment._embedded["cnp:capture"]. state is e.g. SUCCESS. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record NgeniusCaptureResource(
        String state,
        NgeniusAmount amount,
        String createdTime,
        @JsonProperty("_links") Map<String, Object> links) {

    public Optional<String> selfHref() {
        return HalLinks.href(links, NgeniusLinkRelations.SELF);
    }

    public boolean isSuccessful() {
        return "SUCCESS".equalsIgnoreCase(state);
    }
}
