package com.company.payintegration.threeds;

import java.util.Optional;

/**
 * In-process facade of the threeds feature (not HTTP). Other features use only the types in this package,
 * never threeds.application / domain / infrastructure.
 */
public interface ThreeDsFacade {

    /** Call before creating a payment, so a bad returnUrl fails before any money moves. */
    void requireAllowedReturnUrl(String returnUrl);

    ThreeDsStartResult start(ThreeDsStartCommand command);

    /** The challenge of a session that is still waiting for the shopper, if any. */
    Optional<ThreeDsChallenge> pendingChallenge(String sessionId);
}
