package com.company.payintegration.payment.infrastructure.ngenius.dto;

import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusAmount;

/** Body of capture and refund calls: {"amount": {"currencyCode": "AED", "value": 1000}} */
public record NgeniusAmountRequest(NgeniusAmount amount) {
}
