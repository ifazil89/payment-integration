package com.company.payintegration.shared.infrastructure.ngenius;

import com.company.payintegration.shared.domain.Money;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusAmount;

import java.math.BigDecimal;
import java.util.Currency;

/**
 * Money (major units) <-> N-Genius amount (minor units).
 * AED 12.50 -> 1250, KWD 1.250 -> 1250 (3 decimals).
 */
public final class MinorUnitConverter {

    private MinorUnitConverter() {
    }

    public static NgeniusAmount toNgenius(Money money) {
        int digits = Currency.getInstance(money.currency()).getDefaultFractionDigits();
        long minor = money.amount().movePointRight(digits).longValueExact();
        return new NgeniusAmount(money.currency(), minor);
    }

    public static Money fromNgenius(NgeniusAmount amount) {
        int digits = Currency.getInstance(amount.currencyCode()).getDefaultFractionDigits();
        return new Money(BigDecimal.valueOf(amount.value()).movePointLeft(digits), amount.currencyCode());
    }
}
