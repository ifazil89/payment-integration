package com.company.payintegration.savedcard.domain.exception;

import com.company.payintegration.shared.domain.BusinessException;

public class SavedCardExpiredException extends BusinessException {

    public SavedCardExpiredException(String savedCardId) {
        super(Kind.INVALID, "SAVED_CARD_EXPIRED", "Saved card has expired: " + savedCardId);
    }
}
