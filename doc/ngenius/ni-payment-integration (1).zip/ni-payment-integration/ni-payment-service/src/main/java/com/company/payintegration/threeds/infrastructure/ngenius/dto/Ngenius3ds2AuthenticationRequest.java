package com.company.payintegration.threeds.infrastructure.ngenius.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * POST cnp:3ds2-authentication
 *   deviceChannel  = "BRW" (browser; "APP" not yet available)
 *   threeDSCompInd = "Y"
 */
public record Ngenius3ds2AuthenticationRequest(
        @JsonProperty("deviceChannel") String deviceChannel,
        @JsonProperty("threeDSCompInd") String threeDsCompInd,
        @JsonProperty("notificationURL") String notificationUrl,
        @JsonProperty("browserInfo") NgeniusBrowserInfo browserInfo) {

    public static Ngenius3ds2AuthenticationRequest browser(String notificationUrl, NgeniusBrowserInfo browserInfo) {
        return new Ngenius3ds2AuthenticationRequest("BRW", "Y", notificationUrl, browserInfo);
    }
}
