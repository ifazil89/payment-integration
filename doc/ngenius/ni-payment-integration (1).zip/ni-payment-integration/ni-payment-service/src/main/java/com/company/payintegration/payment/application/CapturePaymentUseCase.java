package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.GatewayResult;
import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.payment.domain.exception.PaymentNotFoundException;
import com.company.payintegration.shared.domain.Money;
import org.springframework.stereotype.Service;

/** Captures all or part of an authorised payment (two-stage flow, step 3). */
@Service
public class CapturePaymentUseCase {

    private final PaymentRepositoryPort repository;
    private final PaymentGatewayPort gateway;
    private final PaymentStatusUpdater updater;

    public CapturePaymentUseCase(PaymentRepositoryPort repository, PaymentGatewayPort gateway,
                                 PaymentStatusUpdater updater) {
        this.repository = repository;
        this.gateway = gateway;
        this.updater = updater;
    }

    /** @param amount null = capture the remaining authorised amount */
    public Payment execute(String paymentId, Money amount) {
        Payment payment = repository.findById(paymentId).orElseThrow(() -> new PaymentNotFoundException(paymentId));
        PaymentStatus before = payment.getStatus();

        Money toCapture = payment.ensureCanCapture(amount);           // domain rules first
        GatewayResult result = gateway.capture(payment.getGatewayReference(), toCapture);
        payment.recordCapture(toCapture);

        return updater.apply(payment, before, result);
    }
}
