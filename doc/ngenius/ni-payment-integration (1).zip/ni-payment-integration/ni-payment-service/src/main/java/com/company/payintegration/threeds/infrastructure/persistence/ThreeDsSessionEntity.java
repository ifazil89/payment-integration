package com.company.payintegration.threeds.infrastructure.persistence;

import com.company.payintegration.threeds.domain.ThreeDsSession;
import com.company.payintegration.threeds.domain.ThreeDsSessionStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "threeds_session")
class ThreeDsSessionEntity {

    @Id
    private String id;
    @Column(name = "payment_id", nullable = false)
    private String paymentId;
    @Column(name = "outlet_id", nullable = false)
    private String outletId;
    @Column(name = "order_reference", nullable = false)
    private String orderReference;
    @Column(name = "payment_reference", nullable = false)
    private String paymentReference;
    @Column(name = "return_url", nullable = false, length = 2048)
    private String returnUrl;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ThreeDsSessionStatus status;
    @Column(name = "acs_url", length = 2048)
    private String acsUrl;
    @Column(name = "creq", length = 4000)
    private String creq;
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;
    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;
    @Column(name = "completed_at")
    private Instant completedAt;

    protected ThreeDsSessionEntity() {
    }

    static ThreeDsSessionEntity from(ThreeDsSession s) {
        ThreeDsSessionEntity e = new ThreeDsSessionEntity();
        e.id = s.getId();
        e.paymentId = s.getPaymentId();
        e.outletId = s.getOutletId();
        e.orderReference = s.getOrderReference();
        e.paymentReference = s.getPaymentReference();
        e.returnUrl = s.getReturnUrl();
        e.status = s.getStatus();
        e.acsUrl = s.getAcsUrl();
        e.creq = s.getCreq();
        e.createdAt = s.getCreatedAt();
        e.expiresAt = s.getExpiresAt();
        e.completedAt = s.getCompletedAt();
        return e;
    }

    ThreeDsSession toDomain() {
        return ThreeDsSession.restore(id, paymentId, outletId, orderReference, paymentReference, returnUrl, status,
                acsUrl, creq, createdAt, expiresAt, completedAt);
    }
}
