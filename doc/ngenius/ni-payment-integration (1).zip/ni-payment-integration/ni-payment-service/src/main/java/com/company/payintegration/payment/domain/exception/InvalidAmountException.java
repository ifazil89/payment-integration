package com.company.payintegration.payment.domain.exception;

import com.company.payintegration.shared.domain.BusinessException;

public class InvalidAmountException extends BusinessException {

    public InvalidAmountException(String message) {
        super(Kind.INVALID, "INVALID_AMOUNT", message);
    }
}
