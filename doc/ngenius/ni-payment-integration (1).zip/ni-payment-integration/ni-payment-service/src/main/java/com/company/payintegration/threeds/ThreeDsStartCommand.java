package com.company.payintegration.threeds;

/** Input for starting 3DS authentication of a payment that is in AWAIT_3DS at N-Genius. */
public record ThreeDsStartCommand(
        String paymentId,
        String outletId,
        String orderReference,
        String paymentReference,
        BrowserInfo browserInfo,
        String returnUrl) {        // where the shopper's browser goes after the challenge
}
