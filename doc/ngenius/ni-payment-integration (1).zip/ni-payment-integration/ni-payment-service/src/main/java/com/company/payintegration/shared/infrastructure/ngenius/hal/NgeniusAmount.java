package com.company.payintegration.shared.infrastructure.ngenius.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** N-Genius amount: value is in MINOR units (AED 1.00 = 100). */
@JsonIgnoreProperties(ignoreUnknown = true)
public record NgeniusAmount(String currencyCode, Long value) {
}
