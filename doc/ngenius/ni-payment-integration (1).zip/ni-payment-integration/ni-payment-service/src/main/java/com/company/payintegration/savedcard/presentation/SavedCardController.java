package com.company.payintegration.savedcard.presentation;

import com.company.payintegration.api.interfaces.SavedCardsApi;
import com.company.payintegration.api.model.savedcard.SavedCardResponse;
import com.company.payintegration.savedcard.application.SavedCardService;
import com.company.payintegration.savedcard.domain.SavedCard;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.time.YearMonth;
import java.util.List;

/** Implements the SavedCardsApi contract. */
@RestController
class SavedCardController implements SavedCardsApi {

    private final SavedCardService savedCards;

    SavedCardController(SavedCardService savedCards) {
        this.savedCards = savedCards;
    }

    @Override
    public List<SavedCardResponse> listSavedCards(String customerId) {
        YearMonth now = savedCards.currentMonth();
        return savedCards.list(customerId).stream().map(card -> toResponse(card, now)).toList();
    }

    @Override
    public ResponseEntity<Void> deleteSavedCard(String customerId, String savedCardId) {
        savedCards.delete(customerId, savedCardId);
        return ResponseEntity.noContent().build();
    }

    private static SavedCardResponse toResponse(SavedCard card, YearMonth now) {
        return new SavedCardResponse(card.getId(), card.getMaskedPan(), card.getScheme(), card.getExpiry().toString(),
                card.getCardholderName(), card.isExpired(now), card.getCreatedAt());
    }
}
