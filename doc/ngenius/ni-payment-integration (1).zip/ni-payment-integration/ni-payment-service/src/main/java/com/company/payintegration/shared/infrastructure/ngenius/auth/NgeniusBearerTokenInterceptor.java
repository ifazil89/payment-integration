package com.company.payintegration.shared.infrastructure.ngenius.auth;

import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;

/**
 * Adds "Authorization: Bearer <token>" to every N-Genius API call.
 * If N-Genius still answers 401 (token revoked or clock skew), it fetches a new token
 * and retries the call exactly once.
 */
public class NgeniusBearerTokenInterceptor implements ClientHttpRequestInterceptor {

    private final NgeniusAccessTokenProvider tokenProvider;

    public NgeniusBearerTokenInterceptor(NgeniusAccessTokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                                        ClientHttpRequestExecution execution) throws IOException {
        request.getHeaders().setBearerAuth(tokenProvider.getToken());
        ClientHttpResponse response = execution.execute(request, body);

        if (response.getStatusCode().value() == HttpStatus.UNAUTHORIZED.value()) {
            response.close();
            tokenProvider.invalidate();
            request.getHeaders().setBearerAuth(tokenProvider.getToken());
            return execution.execute(request, body);
        }
        return response;
    }
}
