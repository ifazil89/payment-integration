package com.company.payintegration.payment.application.port;

public record CustomerDetails(String email, String firstName, String lastName) {
}
