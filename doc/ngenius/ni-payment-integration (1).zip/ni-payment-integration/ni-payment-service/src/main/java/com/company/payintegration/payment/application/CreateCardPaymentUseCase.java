package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import org.springframework.stereotype.Service;

/** New card: create AUTH order, then PUT the card details to "payment:card". */
@Service
public class CreateCardPaymentUseCase {

    private final AuthorisationFlow flow;
    private final PaymentGatewayPort gateway;

    public CreateCardPaymentUseCase(AuthorisationFlow flow, PaymentGatewayPort gateway) {
        this.flow = flow;
        this.gateway = gateway;
    }

    public PaymentOutcome execute(CreateCardPaymentCommand command) {
        return flow.run(command.payment(), order -> gateway.payWithCard(order, command.card()));
    }
}
