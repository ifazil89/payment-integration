package com.company.payintegration.payment.infrastructure.persistence;

import com.company.payintegration.payment.domain.GatewayReference;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentMethodType;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.shared.domain.Money;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

import java.math.BigDecimal;
import java.time.Instant;

/** Database row for a payment. Never leaves the persistence package. */
@Entity
@Table(name = "payment")
class PaymentEntity {

    @Id
    private String id;
    @Column(name = "merchant_order_id", nullable = false)
    private String merchantOrderId;
    @Column(name = "customer_id", nullable = false)
    private String customerId;
    @Column(name = "idempotency_key", nullable = false, unique = true)
    private String idempotencyKey;
    @Column(nullable = false, precision = 19, scale = 3)
    private BigDecimal amount;
    @Column(nullable = false, length = 3)
    private String currency;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PaymentMethodType method;
    @Column(name = "save_card_requested", nullable = false)
    private boolean saveCardRequested;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PaymentStatus status;
    @Column(name = "outlet_id")
    private String outletId;
    @Column(name = "order_reference")
    private String orderReference;
    @Column(name = "payment_reference")
    private String paymentReference;
    @Column(name = "captured_amount", nullable = false, precision = 19, scale = 3)
    private BigDecimal capturedAmount;
    @Column(name = "refunded_amount", nullable = false, precision = 19, scale = 3)
    private BigDecimal refundedAmount;
    @Column(name = "threeds_session_id")
    private String threeDsSessionId;
    @Column(name = "failure_reason")
    private String failureReason;
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Version
    private Long version;

    protected PaymentEntity() {
        // for JPA
    }

    static PaymentEntity from(Payment p) {
        PaymentEntity e = new PaymentEntity();
        e.id = p.getId();
        e.merchantOrderId = p.getMerchantOrderId();
        e.customerId = p.getCustomerId();
        e.idempotencyKey = p.getIdempotencyKey();
        e.amount = p.getAmount().amount();
        e.currency = p.getAmount().currency();
        e.method = p.getMethod();
        e.saveCardRequested = p.isSaveCardRequested();
        e.status = p.getStatus();
        if (p.getGatewayReference() != null) {
            e.outletId = p.getGatewayReference().outletId();
            e.orderReference = p.getGatewayReference().orderReference();
            e.paymentReference = p.getGatewayReference().paymentReference();
        }
        e.capturedAmount = p.getCapturedAmount().amount();
        e.refundedAmount = p.getRefundedAmount().amount();
        e.threeDsSessionId = p.getThreeDsSessionId();
        e.failureReason = truncate(p.getFailureReason(), 500);
        e.createdAt = p.getCreatedAt();
        e.updatedAt = p.getUpdatedAt();
        e.version = p.getVersion();
        return e;
    }

    Payment toDomain() {
        GatewayReference reference = orderReference == null ? null
                : new GatewayReference(outletId, orderReference, paymentReference);
        return Payment.restore(id, merchantOrderId, customerId, idempotencyKey, new Money(amount, currency), method,
                saveCardRequested, status, reference, new Money(capturedAmount, currency),
                new Money(refundedAmount, currency), threeDsSessionId, failureReason, createdAt, updatedAt, version);
    }

    private static String truncate(String value, int max) {
        return value == null || value.length() <= max ? value : value.substring(0, max);
    }
}
