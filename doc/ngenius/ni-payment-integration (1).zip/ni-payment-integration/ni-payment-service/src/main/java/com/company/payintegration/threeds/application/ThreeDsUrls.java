package com.company.payintegration.threeds.application;

import com.company.payintegration.shared.infrastructure.config.AppProperties;
import com.company.payintegration.shared.infrastructure.ngenius.NgeniusProperties;
import com.company.payintegration.threeds.domain.exception.InvalidReturnUrlException;
import org.springframework.stereotype.Component;

import java.util.List;

/** Builds our public 3DS URLs and checks the shopper return URL. */
@Component
class ThreeDsUrls {

    static final String NOTIFICATION_PATH = "/ngenius/3ds/notification/";
    static final String CHALLENGE_PAGE_PATH = "/ngenius/3ds/challenge/";

    private final String publicBaseUrl;
    private final List<String> allowedReturnUrlPrefixes;

    ThreeDsUrls(NgeniusProperties ngeniusProperties, AppProperties appProperties) {
        this.publicBaseUrl = stripTrailingSlash(ngeniusProperties.publicBaseUrl());
        this.allowedReturnUrlPrefixes = appProperties.threeds().allowedReturnUrlPrefixes();
    }

    /** Where the ACS (via the shopper's browser) posts the challenge result. */
    String notificationUrl(String sessionId) {
        return publicBaseUrl + NOTIFICATION_PATH + sessionId;
    }

    /** Our page that auto-posts the creq to the ACS. */
    String challengePageUrl(String sessionId) {
        return publicBaseUrl + CHALLENGE_PAGE_PATH + sessionId;
    }

    void requireAllowedReturnUrl(String returnUrl) {
        boolean allowed = returnUrl != null && allowedReturnUrlPrefixes.stream().anyMatch(returnUrl::startsWith);
        if (!allowed) {
            throw new InvalidReturnUrlException(returnUrl);
        }
    }

    String returnUrlFor(String returnUrl, String paymentId) {
        return returnUrl + (returnUrl.contains("?") ? "&" : "?") + "paymentId=" + paymentId;
    }

    private static String stripTrailingSlash(String url) {
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }
}
