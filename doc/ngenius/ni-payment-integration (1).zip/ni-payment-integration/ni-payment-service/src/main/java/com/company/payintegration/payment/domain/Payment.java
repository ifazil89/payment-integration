package com.company.payintegration.payment.domain;

import com.company.payintegration.payment.domain.exception.InvalidAmountException;
import com.company.payintegration.payment.domain.exception.InvalidPaymentStateException;
import com.company.payintegration.shared.domain.Money;

import java.time.Instant;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * A payment and its rules. Plain Java: no Spring, no JPA, no N-Genius.
 *
 * Every state change goes through a method that checks the rules. There are no setters.
 */
public class Payment {

    private static final Set<PaymentStatus> CAPTURABLE =
            EnumSet.of(PaymentStatus.AUTHORISED, PaymentStatus.PARTIALLY_CAPTURED, PaymentStatus.CAPTURED);
    private static final Set<PaymentStatus> REFUNDABLE =
            EnumSet.of(PaymentStatus.PARTIALLY_CAPTURED, PaymentStatus.CAPTURED, PaymentStatus.PARTIALLY_REFUNDED);

    private final String id;
    private final String merchantOrderId;
    private final String customerId;
    private final String idempotencyKey;
    private final Money amount;
    private final PaymentMethodType method;
    private final boolean saveCardRequested;
    private final Instant createdAt;
    private final Long version;

    private PaymentStatus status;
    private GatewayReference gatewayReference;
    private Money capturedAmount;
    private Money refundedAmount;
    private String threeDsSessionId;
    private String failureReason;
    private Instant updatedAt;

    private Payment(String id, String merchantOrderId, String customerId, String idempotencyKey, Money amount,
                    PaymentMethodType method, boolean saveCardRequested, PaymentStatus status,
                    GatewayReference gatewayReference, Money capturedAmount, Money refundedAmount,
                    String threeDsSessionId, String failureReason, Instant createdAt, Instant updatedAt,
                    Long version) {
        this.id = Objects.requireNonNull(id);
        this.merchantOrderId = Objects.requireNonNull(merchantOrderId);
        this.customerId = Objects.requireNonNull(customerId);
        this.idempotencyKey = Objects.requireNonNull(idempotencyKey);
        this.amount = Objects.requireNonNull(amount);
        this.method = Objects.requireNonNull(method);
        this.saveCardRequested = saveCardRequested;
        this.status = Objects.requireNonNull(status);
        this.gatewayReference = gatewayReference;
        this.capturedAmount = Objects.requireNonNull(capturedAmount);
        this.refundedAmount = Objects.requireNonNull(refundedAmount);
        this.threeDsSessionId = threeDsSessionId;
        this.failureReason = failureReason;
        this.createdAt = Objects.requireNonNull(createdAt);
        this.updatedAt = Objects.requireNonNull(updatedAt);
        this.version = version;
    }

    // ------------------------------------------------------------------ creation

    public static Payment create(String merchantOrderId, String customerId, String idempotencyKey,
                                 Money amount, PaymentMethodType method, boolean saveCardRequested) {
        if (!amount.isPositive()) {
            throw new InvalidAmountException("Amount must be greater than zero");
        }
        boolean saveCard = saveCardRequested && method == PaymentMethodType.CARD;   // a saved card is already saved
        Instant now = Instant.now();
        Money zero = Money.zero(amount.currency());
        return new Payment(UUID.randomUUID().toString(), merchantOrderId, customerId, idempotencyKey, amount,
                method, saveCard, PaymentStatus.CREATED, null, zero, zero, null, null, now, now, null);
    }

    /** Rebuilds a payment from storage. Only the persistence adapter calls this. */
    public static Payment restore(String id, String merchantOrderId, String customerId, String idempotencyKey,
                                  Money amount, PaymentMethodType method, boolean saveCardRequested,
                                  PaymentStatus status, GatewayReference gatewayReference, Money capturedAmount,
                                  Money refundedAmount, String threeDsSessionId, String failureReason,
                                  Instant createdAt, Instant updatedAt, Long version) {
        return new Payment(id, merchantOrderId, customerId, idempotencyKey, amount, method, saveCardRequested,
                status, gatewayReference, capturedAmount, refundedAmount, threeDsSessionId, failureReason,
                createdAt, updatedAt, version);
    }

    // ------------------------------------------------------------------ life cycle

    public void attachGatewayOrder(GatewayReference reference) {
        requireStatus(Set.of(PaymentStatus.CREATED), "attach a gateway order");
        if (gatewayReference != null) {
            throw new InvalidPaymentStateException("Payment " + id + " already has a gateway order");
        }
        this.gatewayReference = Objects.requireNonNull(reference);
        touch();
    }

    public void awaitThreeDs(String sessionId) {
        if (status != PaymentStatus.AWAITING_3DS) {
            throw new InvalidPaymentStateException("Payment " + id + " is " + status + ", not AWAITING_3DS");
        }
        this.threeDsSessionId = Objects.requireNonNull(sessionId);
        touch();
    }

    /**
     * Applies the status reported by the gateway (API response, webhook or reconciliation).
     * Returns true if the status changed.
     *
     * Rules:
     *  - terminal statuses never change
     *  - DECLINED / FAILED only apply before authorisation (a failed capture attempt does
     *    not cancel an authorisation)
     *  - REVERSED only applies to an authorised, uncaptured payment
     *  - otherwise the status only moves forward
     */
    public boolean applyGatewayStatus(PaymentStatus reported) {
        if (reported == null || reported == status || status.isTerminal()) {
            return false;
        }
        boolean allowed;
        if (reported.isFailure()) {
            allowed = status.isBeforeAuthorisation();
        } else if (reported == PaymentStatus.REVERSED) {
            allowed = status == PaymentStatus.AUTHORISED;
        } else {
            allowed = reported.progress() > status.progress();
        }
        if (allowed) {
            status = reported;
            touch();
        }
        return allowed;
    }

    public void fail(String reason) {
        if (!status.isBeforeAuthorisation()) {
            throw new InvalidPaymentStateException("Payment " + id + " is " + status + " and cannot fail");
        }
        this.status = PaymentStatus.FAILED;
        this.failureReason = reason;
        touch();
    }

    // ------------------------------------------------------------------ capture / reverse / refund

    /** null = capture everything that is left. Returns the amount that will be captured. */
    public Money ensureCanCapture(Money requested) {
        requireStatus(CAPTURABLE, "capture");
        Money remaining = amount.minus(capturedAmount);
        Money toCapture = requested != null ? requested : remaining;
        requirePositiveSameCurrency(toCapture);
        if (toCapture.isGreaterThan(remaining)) {
            throw new InvalidAmountException("Capture " + toCapture + " exceeds remaining authorised " + remaining);
        }
        return toCapture;
    }

    public void recordCapture(Money captured) {
        capturedAmount = capturedAmount.plus(captured);
        moveForwardTo(capturedAmount.equals(amount) ? PaymentStatus.CAPTURED : PaymentStatus.PARTIALLY_CAPTURED);
    }

    public void ensureCanReverse() {
        requireStatus(Set.of(PaymentStatus.AUTHORISED), "reverse");
        if (capturedAmount.isPositive()) {
            throw new InvalidPaymentStateException("Payment " + id + " has captures and cannot be reversed; refund it");
        }
    }

    public void recordReversal() {
        status = PaymentStatus.REVERSED;
        touch();
    }

    public void ensureCanRefund(Money requested) {
        requireStatus(REFUNDABLE, "refund");
        requirePositiveSameCurrency(requested);
        Money refundable = capturedAmount.minus(refundedAmount);
        if (requested.isGreaterThan(refundable)) {
            throw new InvalidAmountException("Refund " + requested + " exceeds refundable " + refundable);
        }
    }

    public void recordRefund(Money refunded) {
        refundedAmount = refundedAmount.plus(refunded);
        moveForwardTo(refundedAmount.equals(capturedAmount) ? PaymentStatus.REFUNDED : PaymentStatus.PARTIALLY_REFUNDED);
    }

    // ------------------------------------------------------------------ helpers

    private void moveForwardTo(PaymentStatus target) {
        if (target.progress() > status.progress()) {
            status = target;
        }
        touch();
    }

    private void requireStatus(Set<PaymentStatus> allowed, String action) {
        if (!allowed.contains(status)) {
            throw new InvalidPaymentStateException(
                    "Cannot " + action + " payment " + id + " in status " + status + " (allowed: " + allowed + ")");
        }
    }

    private void requirePositiveSameCurrency(Money value) {
        if (!value.sameCurrencyAs(amount)) {
            throw new InvalidAmountException("Currency must be " + amount.currency());
        }
        if (!value.isPositive()) {
            throw new InvalidAmountException("Amount must be greater than zero");
        }
    }

    private void touch() {
        updatedAt = Instant.now();
    }

    // ------------------------------------------------------------------ getters

    public String getId() { return id; }
    public String getMerchantOrderId() { return merchantOrderId; }
    public String getCustomerId() { return customerId; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public Money getAmount() { return amount; }
    public PaymentMethodType getMethod() { return method; }
    public boolean isSaveCardRequested() { return saveCardRequested; }
    public PaymentStatus getStatus() { return status; }
    public GatewayReference getGatewayReference() { return gatewayReference; }
    public Money getCapturedAmount() { return capturedAmount; }
    public Money getRefundedAmount() { return refundedAmount; }
    public String getThreeDsSessionId() { return threeDsSessionId; }
    public String getFailureReason() { return failureReason; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public Long getVersion() { return version; }
}
