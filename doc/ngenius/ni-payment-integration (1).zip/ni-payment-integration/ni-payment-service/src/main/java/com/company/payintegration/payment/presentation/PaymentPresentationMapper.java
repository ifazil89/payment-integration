package com.company.payintegration.payment.presentation;

import com.company.payintegration.api.model.payment.BrowserInfoDto;
import com.company.payintegration.api.model.payment.CardDetailsDto;
import com.company.payintegration.api.model.payment.CreateCardPaymentRequest;
import com.company.payintegration.api.model.payment.CreateSavedCardPaymentRequest;
import com.company.payintegration.api.model.payment.CustomerDto;
import com.company.payintegration.api.model.payment.NextActionDto;
import com.company.payintegration.api.model.payment.NextActionType;
import com.company.payintegration.api.model.payment.PaymentResponse;
import com.company.payintegration.api.model.payment.PaymentStatusDto;
import com.company.payintegration.payment.application.CreateCardPaymentCommand;
import com.company.payintegration.payment.application.CreateSavedCardPaymentCommand;
import com.company.payintegration.payment.application.NewPaymentData;
import com.company.payintegration.payment.application.PaymentOutcome;
import com.company.payintegration.payment.application.port.CardData;
import com.company.payintegration.payment.application.port.CustomerDetails;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentMethodType;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.shared.presentation.MoneyMapper;
import com.company.payintegration.threeds.BrowserInfo;
import com.company.payintegration.threeds.ThreeDsChallenge;

/**
 * API schema models (ni-payment-api-schema) <-> application types.
 * The only class in the payment feature that knows both sides.
 */
final class PaymentPresentationMapper {

    private PaymentPresentationMapper() {
    }

    static CreateCardPaymentCommand toCommand(String idempotencyKey, CreateCardPaymentRequest r) {
        NewPaymentData data = new NewPaymentData(idempotencyKey, r.merchantOrderId(), r.customerId(),
                MoneyMapper.toDomain(r.amount()), PaymentMethodType.CARD, Boolean.TRUE.equals(r.saveCard()),
                toCustomer(r.customer()), toBrowserInfo(r.browserInfo()), r.returnUrl());
        return new CreateCardPaymentCommand(data, toCard(r.card()));
    }

    static CreateSavedCardPaymentCommand toCommand(String idempotencyKey, CreateSavedCardPaymentRequest r) {
        NewPaymentData data = new NewPaymentData(idempotencyKey, r.merchantOrderId(), r.customerId(),
                MoneyMapper.toDomain(r.amount()), PaymentMethodType.SAVED_CARD, false,
                toCustomer(r.customer()), toBrowserInfo(r.browserInfo()), r.returnUrl());
        return new CreateSavedCardPaymentCommand(data, r.savedCardId(), r.cvv());
    }

    static PaymentResponse toResponse(PaymentOutcome outcome) {
        Payment p = outcome.payment();
        ThreeDsChallenge challenge = outcome.threeDsChallenge();
        NextActionDto nextAction = challenge == null ? null : new NextActionDto(NextActionType.THREEDS_CHALLENGE,
                challenge.challengePageUrl(), challenge.acsUrl(), challenge.creq());
        return new PaymentResponse(
                p.getId(),
                p.getMerchantOrderId(),
                toStatus(p.getStatus()),
                MoneyMapper.toDto(p.getAmount()),
                MoneyMapper.toDto(p.getCapturedAmount()),
                MoneyMapper.toDto(p.getRefundedAmount()),
                p.getGatewayReference() != null ? p.getGatewayReference().orderReference() : null,
                p.getFailureReason(),
                nextAction,
                p.getCreatedAt(),
                p.getUpdatedAt());
    }

    static PaymentResponse toResponse(Payment payment) {
        return toResponse(PaymentOutcome.of(payment));
    }

    /** Same names on both sides; ApiContractTest fails the build if they ever drift apart. */
    static PaymentStatusDto toStatus(PaymentStatus status) {
        return PaymentStatusDto.valueOf(status.name());
    }

    private static CustomerDetails toCustomer(CustomerDto c) {
        return new CustomerDetails(c.email(), c.firstName(), c.lastName());
    }

    private static CardData toCard(CardDetailsDto c) {
        return new CardData(c.pan(), c.expiry(), c.cvv(), c.cardholderName());
    }

    private static BrowserInfo toBrowserInfo(BrowserInfoDto b) {
        return new BrowserInfo(b.acceptHeader(), b.javaEnabled(), b.language(), b.timeZoneOffset(), b.userAgent(),
                b.colorDepth(), b.screenHeight(), b.screenWidth(), b.javascriptEnabled(), b.ip(),
                b.challengeWindowSize());
    }
}
