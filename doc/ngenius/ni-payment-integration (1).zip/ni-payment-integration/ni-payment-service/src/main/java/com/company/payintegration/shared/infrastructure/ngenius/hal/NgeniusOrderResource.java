package com.company.payintegration.shared.infrastructure.ngenius.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/** N-Genius order (response of create order and GET order). */
@JsonIgnoreProperties(ignoreUnknown = true)
public record NgeniusOrderResource(
        String reference,
        String outletId,
        String action,
        NgeniusAmount amount,
        @JsonProperty("_links") Map<String, Object> links,
        @JsonProperty("_embedded") Embedded embedded) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Embedded(List<NgeniusPaymentResource> payment) {
    }

    public List<NgeniusPaymentResource> payments() {
        return embedded != null && embedded.payment() != null ? embedded.payment() : List.of();
    }

    /** For one-time payments there is exactly one payment, index 0. */
    public NgeniusPaymentResource requireFirstPayment() {
        return payments().stream().findFirst().orElseThrow(() ->
                new IllegalStateException("N-Genius order " + reference + " contains no payment"));
    }

    public Optional<NgeniusPaymentResource> payment(String paymentReference) {
        return payments().stream().filter(p -> paymentReference.equals(p.reference())).findFirst();
    }
}
