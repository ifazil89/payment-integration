package com.company.payintegration.savedcard.domain;

import java.time.YearMonth;
import java.time.format.DateTimeParseException;

/** Card expiry "YYYY-MM" (N-Genius format). A card is valid until the end of that month. */
public record CardExpiry(YearMonth value) {

    public static CardExpiry parse(String yyyyMm) {
        try {
            return new CardExpiry(YearMonth.parse(yyyyMm));
        } catch (DateTimeParseException | NullPointerException ex) {
            throw new IllegalArgumentException("Card expiry must be YYYY-MM, got " + yyyyMm);
        }
    }

    public boolean isExpired(YearMonth current) {
        return current.isAfter(value);
    }

    @Override
    public String toString() {
        return value.toString();   // YYYY-MM
    }
}
