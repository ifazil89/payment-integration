package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.CustomerDetails;
import com.company.payintegration.payment.domain.PaymentMethodType;
import com.company.payintegration.shared.domain.Money;
import com.company.payintegration.threeds.BrowserInfo;

/** Data common to every new payment, whatever the payment method. */
public record NewPaymentData(
        String idempotencyKey,
        String merchantOrderId,
        String customerId,
        Money amount,
        PaymentMethodType method,
        boolean saveCard,
        CustomerDetails customer,
        BrowserInfo browserInfo,
        String returnUrl) {
}
