package com.company.payintegration.shared.infrastructure.ngenius;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;

/**
 * All N-Genius settings, bound from "ngenius.*" in application.yml.
 * The application fails to start if a required value is missing.
 */
@Validated
@ConfigurationProperties("ngenius")
public record NgeniusProperties(
        @NotBlank String baseUrl,
        @NotBlank String apiKey,
        @NotBlank String outletId,
        String realmName,
        @NotBlank String publicBaseUrl,
        @NotNull Duration connectTimeout,
        @NotNull Duration responseTimeout,
        int maxConnections,
        @NotNull @Valid Webhook webhook) {

    public record Webhook(@NotBlank String headerName, @NotBlank String headerValue) {
    }

    @Override
    public String toString() {   // never print the API key
        return "NgeniusProperties[baseUrl=" + baseUrl + ", outletId=" + outletId + "]";
    }
}
