package com.company.payintegration.shared.infrastructure.ngenius.hal;

/**
 * Link relation names used in N-Genius responses.
 *
 * N-Genius asks integrators to follow these links instead of building URLs. If a call
 * fails with "link not found", compare these names with a real sandbox response.
 */
public final class NgeniusLinkRelations {

    /** order._embedded.payment[0]._links: PUT card details (pan, expiry, cvv, cardholderName). */
    public static final String PAYMENT_CARD = "payment:card";
    /** order._embedded.payment[0]._links: PUT saved card (cardToken, expiry, cvv, cardholderName). */
    public static final String PAYMENT_SAVED_CARD = "payment:saved-card";
    /** payment._links: POST to start EMV 3DS 2.x authentication. */
    public static final String THREEDS2_AUTHENTICATION = "cnp:3ds2-authentication";
    /** payment._links: POST the challenge result (base64EncodedCRes). */
    public static final String THREEDS2_CHALLENGE_RESPONSE = "cnp:3ds2-challenge-response";
    /** payment._links: POST to capture an authorised payment (full or partial). */
    public static final String CAPTURE = "cnp:capture";
    /** payment._links: PUT (no body) to reverse an authorisation that has no captures. */
    public static final String CANCEL = "cnp:cancel";
    /** payment._links: POST to refund a PURCHASED payment. Captured payments are refunded via the capture. */
    public static final String REFUND = "cnp:refund";
    /** Every resource: its own URL. A capture's self href + "/refund" refunds that capture. */
    public static final String SELF = "self";

    private NgeniusLinkRelations() {
    }
}
