package com.company.payintegration.shared.infrastructure.ngenius.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/** "3ds2" block of a payment (EMV 3DS 2.x). transStatus "C" = challenge required. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record NgeniusThreeDs2(
        @JsonProperty("eci") String eci,
        @JsonProperty("transStatus") String transStatus,
        @JsonProperty("messageVersion") String messageVersion,
        @JsonProperty("threeDSServerTransID") String threeDsServerTransId,
        @JsonProperty("acsURL") String acsUrl,
        @JsonProperty("acsTransID") String acsTransId,
        @JsonProperty("directoryServerID") String directoryServerId,
        @JsonProperty("base64EncodedCReq") String base64EncodedCReq) {
}
