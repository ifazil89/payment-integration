package com.company.payintegration.threeds.domain.exception;

import com.company.payintegration.shared.domain.BusinessException;

public class ThreeDsSessionNotFoundException extends BusinessException {

    public ThreeDsSessionNotFoundException(String sessionId) {
        super(Kind.NOT_FOUND, "THREEDS_SESSION_NOT_FOUND", "3DS session not found: " + sessionId);
    }
}
