package com.company.payintegration.payment.application.port;

import com.company.payintegration.shared.domain.BusinessException;

/** Someone else (webhook, 3DS callback, reconciliation) updated the payment at the same time. */
public class ConcurrentPaymentUpdateException extends BusinessException {

    public ConcurrentPaymentUpdateException(String paymentId) {
        super(Kind.CONFLICT, "CONCURRENT_UPDATE", "Payment " + paymentId + " was updated concurrently; retry");
    }
}
