package com.company.payintegration.threeds.infrastructure.persistence;

import com.company.payintegration.threeds.application.port.ThreeDsSessionRepositoryPort;
import com.company.payintegration.threeds.domain.ThreeDsSession;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
class ThreeDsSessionRepositoryAdapter implements ThreeDsSessionRepositoryPort {

    private final ThreeDsSessionJpaRepository jpa;

    ThreeDsSessionRepositoryAdapter(ThreeDsSessionJpaRepository jpa) {
        this.jpa = jpa;
    }

    @Override
    public ThreeDsSession save(ThreeDsSession session) {
        return jpa.save(ThreeDsSessionEntity.from(session)).toDomain();
    }

    @Override
    public Optional<ThreeDsSession> findById(String id) {
        return jpa.findById(id).map(ThreeDsSessionEntity::toDomain);
    }
}
