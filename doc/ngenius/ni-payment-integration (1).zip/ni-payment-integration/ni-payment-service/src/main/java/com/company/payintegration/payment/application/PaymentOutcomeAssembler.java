package com.company.payintegration.payment.application;

import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.threeds.ThreeDsFacade;
import org.springframework.stereotype.Component;

/** Adds the pending 3DS challenge (if any) to a payment, e.g. for GET or an idempotent replay. */
@Component
class PaymentOutcomeAssembler {

    private final ThreeDsFacade threeDsFacade;

    PaymentOutcomeAssembler(ThreeDsFacade threeDsFacade) {
        this.threeDsFacade = threeDsFacade;
    }

    PaymentOutcome assemble(Payment payment) {
        if (payment.getStatus() == PaymentStatus.AWAITING_3DS && payment.getThreeDsSessionId() != null) {
            return new PaymentOutcome(payment, threeDsFacade.pendingChallenge(payment.getThreeDsSessionId()).orElse(null));
        }
        return PaymentOutcome.of(payment);
    }
}
