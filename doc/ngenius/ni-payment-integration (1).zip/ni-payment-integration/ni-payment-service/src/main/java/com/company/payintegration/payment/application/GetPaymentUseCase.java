package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.exception.PaymentNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class GetPaymentUseCase {

    private final PaymentRepositoryPort repository;
    private final PaymentStatusUpdater updater;
    private final PaymentOutcomeAssembler outcomeAssembler;

    public GetPaymentUseCase(PaymentRepositoryPort repository, PaymentStatusUpdater updater,
                             PaymentOutcomeAssembler outcomeAssembler) {
        this.repository = repository;
        this.updater = updater;
        this.outcomeAssembler = outcomeAssembler;
    }

    /** @param refreshFromGateway true = ask N-Genius first (GET order), false = our stored status */
    public PaymentOutcome execute(String paymentId, boolean refreshFromGateway) {
        Payment payment = refreshFromGateway
                ? updater.refresh(paymentId)
                : repository.findById(paymentId).orElseThrow(() -> new PaymentNotFoundException(paymentId));
        return outcomeAssembler.assemble(payment);
    }
}
