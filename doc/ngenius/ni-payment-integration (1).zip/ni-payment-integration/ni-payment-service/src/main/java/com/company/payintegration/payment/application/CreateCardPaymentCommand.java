package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.CardData;

public record CreateCardPaymentCommand(NewPaymentData payment, CardData card) {
}
