package com.company.payintegration.savedcard;

/** What the payment feature needs to pay with a saved card (plus the CVV from the shopper). */
public record SavedCardForPayment(String cardToken, String expiry, String cardholderName) {

    @Override
    public String toString() {
        return "SavedCardForPayment[***]";
    }
}
