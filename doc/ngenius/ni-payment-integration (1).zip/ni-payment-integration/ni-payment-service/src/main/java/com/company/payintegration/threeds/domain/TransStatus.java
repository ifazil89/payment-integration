package com.company.payintegration.threeds.domain;

/** EMV 3DS transStatus values returned by the authentication call. */
public enum TransStatus {
    Y,   // authenticated
    N,   // not authenticated
    U,   // could not be performed
    A,   // attempted
    C,   // challenge required
    R,   // rejected
    I,   // information only
    UNKNOWN;

    public static TransStatus from(String code) {
        if (code == null || code.isBlank()) {
            return UNKNOWN;
        }
        try {
            return valueOf(code.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return UNKNOWN;
        }
    }

    public boolean challengeRequired() {
        return this == C;
    }
}
