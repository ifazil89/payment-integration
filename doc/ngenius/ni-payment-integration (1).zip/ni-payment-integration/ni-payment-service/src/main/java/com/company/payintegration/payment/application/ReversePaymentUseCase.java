package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.GatewayResult;
import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.payment.domain.exception.PaymentNotFoundException;
import org.springframework.stereotype.Service;

/** Cancels an authorisation (releases the held funds). Irreversible; only without captures. */
@Service
public class ReversePaymentUseCase {

    private final PaymentRepositoryPort repository;
    private final PaymentGatewayPort gateway;
    private final PaymentStatusUpdater updater;

    public ReversePaymentUseCase(PaymentRepositoryPort repository, PaymentGatewayPort gateway,
                                 PaymentStatusUpdater updater) {
        this.repository = repository;
        this.gateway = gateway;
        this.updater = updater;
    }

    public Payment execute(String paymentId) {
        Payment payment = repository.findById(paymentId).orElseThrow(() -> new PaymentNotFoundException(paymentId));
        PaymentStatus before = payment.getStatus();

        payment.ensureCanReverse();
        GatewayResult result = gateway.reverse(payment.getGatewayReference());
        payment.recordReversal();

        return updater.apply(payment, before, result);
    }
}
