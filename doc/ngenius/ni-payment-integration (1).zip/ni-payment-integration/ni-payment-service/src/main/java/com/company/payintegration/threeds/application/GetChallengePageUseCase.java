package com.company.payintegration.threeds.application;

import com.company.payintegration.threeds.ThreeDsFacade;
import com.company.payintegration.threeds.ThreeDsChallenge;
import org.springframework.stereotype.Service;

import java.util.Optional;

/** Data for the auto-submitting challenge page. Empty if the session is not waiting for a challenge. */
@Service
public class GetChallengePageUseCase {

    private final ThreeDsFacade threeDsFacade;

    GetChallengePageUseCase(ThreeDsFacade threeDsFacade) {
        this.threeDsFacade = threeDsFacade;
    }

    public Optional<ThreeDsChallenge> execute(String sessionId) {
        return threeDsFacade.pendingChallenge(sessionId);
    }
}
