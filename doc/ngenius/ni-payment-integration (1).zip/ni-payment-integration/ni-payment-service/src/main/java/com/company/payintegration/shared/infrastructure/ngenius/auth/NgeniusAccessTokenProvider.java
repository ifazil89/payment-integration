package com.company.payintegration.shared.infrastructure.ngenius.auth;

import com.company.payintegration.shared.infrastructure.ngenius.NgeniusMediaTypes;
import com.company.payintegration.shared.infrastructure.ngenius.NgeniusProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;

/**
 * Gets and caches the N-Genius access token.
 *
 * POST {baseUrl}/identity/auth/access-token
 *   Authorization: Basic {service account API key}
 *   Content-Type:  application/vnd.ni-identity.v1+json
 *
 * The token is valid for 5 minutes (expires_in = 300). We refresh 30 seconds early and make
 * sure only one thread refreshes at a time, so a burst of payments triggers one token call.
 */
@Component
public class NgeniusAccessTokenProvider {

    private static final Logger log = LoggerFactory.getLogger(NgeniusAccessTokenProvider.class);
    private static final Duration REFRESH_BEFORE_EXPIRY = Duration.ofSeconds(30);
    private static final long DEFAULT_EXPIRES_IN_SECONDS = 300;

    private final RestClient identityClient;
    private final NgeniusProperties properties;
    private volatile CachedToken cached;

    public NgeniusAccessTokenProvider(@Qualifier("ngeniusIdentityRestClient") RestClient identityClient,
                                      NgeniusProperties properties) {
        this.identityClient = identityClient;
        this.properties = properties;
    }

    public String getToken() {
        CachedToken current = cached;
        if (current != null && current.isValid()) {
            return current.value();
        }
        synchronized (this) {
            if (cached == null || !cached.isValid()) {
                cached = requestNewToken();
            }
            return cached.value();
        }
    }

    /** Called when N-Genius answers 401, so the next call fetches a fresh token. */
    public void invalidate() {
        cached = null;
    }

    private CachedToken requestNewToken() {
        RestClient.RequestBodySpec request = identityClient.post()
                .uri("/identity/auth/access-token")
                .header(HttpHeaders.AUTHORIZATION, "Basic " + properties.apiKey())
                .contentType(NgeniusMediaTypes.IDENTITY_V1)
                .accept(NgeniusMediaTypes.IDENTITY_V1);

        if (StringUtils.hasText(properties.realmName())) {
            request = request.body(Map.of("realmName", properties.realmName()));
        }

        NgeniusAccessTokenResponse response = request.retrieve().body(NgeniusAccessTokenResponse.class);
        if (response == null || !StringUtils.hasText(response.accessToken())) {
            throw new IllegalStateException("N-Genius returned no access token");
        }

        long expiresIn = response.expiresIn() != null ? response.expiresIn() : DEFAULT_EXPIRES_IN_SECONDS;
        log.debug("Obtained new N-Genius access token, expires in {} s", expiresIn);
        return new CachedToken(response.accessToken(),
                Instant.now().plusSeconds(expiresIn).minus(REFRESH_BEFORE_EXPIRY));
    }

    private record CachedToken(String value, Instant refreshAt) {
        boolean isValid() {
            return Instant.now().isBefore(refreshAt);
        }
    }
}
