package com.company.payintegration.shared.infrastructure.ngenius.auth;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record NgeniusAccessTokenResponse(
        @JsonProperty("access_token") String accessToken,
        @JsonProperty("expires_in") Long expiresIn,
        @JsonProperty("token_type") String tokenType) {

    @Override
    public String toString() {
        return "NgeniusAccessTokenResponse[expiresIn=" + expiresIn + "]";
    }
}
