package com.company.payintegration.payment.presentation;

import com.company.payintegration.api.ApiDocs;
import com.company.payintegration.api.interfaces.PaymentsApi;
import com.company.payintegration.api.model.payment.CreateCardPaymentRequest;
import com.company.payintegration.api.model.payment.CreateSavedCardPaymentRequest;
import com.company.payintegration.api.model.payment.PaymentResponse;
import com.company.payintegration.payment.application.CreateCardPaymentUseCase;
import com.company.payintegration.payment.application.CreateSavedCardPaymentUseCase;
import com.company.payintegration.payment.application.GetPaymentUseCase;
import org.springframework.web.bind.annotation.RestController;

/**
 * Implements the PaymentsApi contract. Paths, headers, validation and OpenAPI docs all
 * come from the interface (ni-payment-api-schema); this class only delegates to use cases.
 */
@RestController
class PaymentController implements PaymentsApi {

    private final CreateCardPaymentUseCase createCardPayment;
    private final CreateSavedCardPaymentUseCase createSavedCardPayment;
    private final GetPaymentUseCase getPayment;

    PaymentController(CreateCardPaymentUseCase createCardPayment,
                      CreateSavedCardPaymentUseCase createSavedCardPayment,
                      GetPaymentUseCase getPayment) {
        this.createCardPayment = createCardPayment;
        this.createSavedCardPayment = createSavedCardPayment;
        this.getPayment = getPayment;
    }

    @Override
    public PaymentResponse payWithCard(String idempotencyKey, CreateCardPaymentRequest request) {
        return PaymentPresentationMapper.toResponse(
                createCardPayment.execute(PaymentPresentationMapper.toCommand(validKey(idempotencyKey), request)));
    }

    @Override
    public PaymentResponse payWithSavedCard(String idempotencyKey, CreateSavedCardPaymentRequest request) {
        return PaymentPresentationMapper.toResponse(
                createSavedCardPayment.execute(PaymentPresentationMapper.toCommand(validKey(idempotencyKey), request)));
    }

    @Override
    public PaymentResponse getPayment(String paymentId, boolean refresh) {
        return PaymentPresentationMapper.toResponse(getPayment.execute(paymentId, refresh));
    }

    private static String validKey(String key) {
        if (key.isBlank() || key.length() > 100) {
            throw new IllegalArgumentException(ApiDocs.HEADER_IDEMPOTENCY_KEY + " must be 1-100 characters");
        }
        return key;
    }
}
