package com.company.payintegration.payment.application.port;

import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.payment.domain.TokenizedCard;

/**
 * What the gateway said about a payment.
 *
 * @param status       mapped status, or null if the gateway state is unknown to us
 * @param gatewayState the raw gateway state, for logs and support
 * @param savedCard    card token, present after a successful payment if tokenisation is on
 */
public record GatewayResult(PaymentStatus status, String gatewayState, TokenizedCard savedCard) {
}
