package com.company.payintegration.threeds.infrastructure.ngenius;

import com.company.payintegration.shared.infrastructure.ngenius.NgeniusApiClient;
import com.company.payintegration.shared.infrastructure.ngenius.NgeniusApiException;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusLinkRelations;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusOrderResource;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusPaymentResource;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusThreeDs2;
import com.company.payintegration.threeds.BrowserInfo;
import com.company.payintegration.threeds.application.port.AuthenticationResult;
import com.company.payintegration.threeds.application.port.ThreeDsGatewayPort;
import com.company.payintegration.threeds.application.port.ThreeDsRejectedException;
import com.company.payintegration.threeds.domain.ChallengeRequestFactory;
import com.company.payintegration.threeds.infrastructure.ngenius.dto.Ngenius3ds2AuthenticationRequest;
import com.company.payintegration.threeds.infrastructure.ngenius.dto.NgeniusBrowserInfo;
import com.company.payintegration.threeds.infrastructure.ngenius.dto.NgeniusChallengeResponseRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.function.Supplier;

/** ThreeDsGatewayPort implemented with the N-Genius EMV 3DS 2.x Direct API. */
@Component
class NgeniusThreeDsGatewayAdapter implements ThreeDsGatewayPort {

    private static final Logger log = LoggerFactory.getLogger(NgeniusThreeDsGatewayAdapter.class);

    private final NgeniusApiClient client;

    NgeniusThreeDsGatewayAdapter(NgeniusApiClient client) {
        this.client = client;
    }

    @Override
    public AuthenticationResult authenticate(String orderReference, String paymentReference, String notificationUrl,
                                             BrowserInfo browserInfo) {
        String href = payment(orderReference, paymentReference).requireLink(NgeniusLinkRelations.THREEDS2_AUTHENTICATION);
        Ngenius3ds2AuthenticationRequest body =
                Ngenius3ds2AuthenticationRequest.browser(notificationUrl, toNgenius(browserInfo));

        NgeniusPaymentResource response = call("3DS authentication", () -> client.postToLink(href, body));
        NgeniusThreeDs2 threeDs = response.threeDs2();
        if (threeDs == null) {
            return new AuthenticationResult(null, null, null, null, null, null, response.state());
        }
        return new AuthenticationResult(threeDs.transStatus(), threeDs.acsUrl(), threeDs.base64EncodedCReq(),
                threeDs.threeDsServerTransId(), threeDs.acsTransId(), threeDs.messageVersion(), response.state());
    }

    @Override
    public void submitChallengeResult(String orderReference, String paymentReference, String cres) {
        String href = payment(orderReference, paymentReference)
                .requireLink(NgeniusLinkRelations.THREEDS2_CHALLENGE_RESPONSE);
        call("3DS challenge response", () -> client.postToLink(href, new NgeniusChallengeResponseRequest(cres)));
    }

    private NgeniusPaymentResource payment(String orderReference, String paymentReference) {
        NgeniusOrderResource order = call("get order", () -> client.getOrder(orderReference));
        return order.payment(paymentReference).orElseGet(order::requireFirstPayment);
    }

    private static NgeniusBrowserInfo toNgenius(BrowserInfo b) {
        return new NgeniusBrowserInfo(b.acceptHeader(), b.javaEnabled(), b.language(), b.timeZoneOffset(),
                b.userAgent(), b.colorDepth(), b.screenHeight(), b.screenWidth(), b.javascriptEnabled(), b.ip(),
                ChallengeRequestFactory.windowSizeOrDefault(b.challengeWindowSize()));
    }

    private static <T> T call(String operation, Supplier<T> call) {
        try {
            return call.get();
        } catch (NgeniusApiException ex) {
            if (ex.isClientError()) {
                log.warn("N-Genius rejected {}: HTTP {} {}", operation, ex.getStatus(), ex.getResponseBody());
                throw new ThreeDsRejectedException("Gateway rejected " + operation + " (HTTP " + ex.getStatus() + ")");
            }
            throw ex;
        }
    }
}
