package com.company.payintegration.savedcard.domain;

import com.company.payintegration.savedcard.domain.exception.SavedCardExpiredException;
import com.company.payintegration.savedcard.domain.exception.SavedCardNotFoundException;

import java.time.Instant;
import java.time.YearMonth;
import java.util.Objects;
import java.util.UUID;

/**
 * A card token stored for a customer. The token is the gateway's reference to the card;
 * we never have the full card number. The CVV is never stored and must be entered for
 * each payment.
 */
public class SavedCard {

    private final String id;
    private final String customerId;
    private final String cardToken;
    private final String tokenFingerprint;   // SHA-256 of the token, to detect duplicates
    private final String maskedPan;
    private final CardExpiry expiry;
    private final String cardholderName;
    private final String scheme;
    private final Instant createdAt;

    private SavedCard(String id, String customerId, String cardToken, String tokenFingerprint, String maskedPan,
                      CardExpiry expiry, String cardholderName, String scheme, Instant createdAt) {
        this.id = Objects.requireNonNull(id);
        this.customerId = Objects.requireNonNull(customerId);
        this.cardToken = Objects.requireNonNull(cardToken);
        this.tokenFingerprint = Objects.requireNonNull(tokenFingerprint);
        this.maskedPan = maskedPan;
        this.expiry = Objects.requireNonNull(expiry);
        this.cardholderName = cardholderName;
        this.scheme = scheme;
        this.createdAt = Objects.requireNonNull(createdAt);
    }

    public static SavedCard create(String customerId, String cardToken, String tokenFingerprint, String maskedPan,
                                   CardExpiry expiry, String cardholderName, String scheme) {
        return new SavedCard(UUID.randomUUID().toString(), customerId, cardToken, tokenFingerprint, maskedPan,
                expiry, cardholderName, scheme, Instant.now());
    }

    public static SavedCard restore(String id, String customerId, String cardToken, String tokenFingerprint,
                                    String maskedPan, CardExpiry expiry, String cardholderName, String scheme,
                                    Instant createdAt) {
        return new SavedCard(id, customerId, cardToken, tokenFingerprint, maskedPan, expiry, cardholderName, scheme,
                createdAt);
    }

    /** A customer may only use their own cards. Reported as "not found" so ids can't be probed. */
    public void requireOwnedBy(String customer) {
        if (!customerId.equals(customer)) {
            throw new SavedCardNotFoundException(id);
        }
    }

    public void requireUsable(YearMonth current) {
        if (expiry.isExpired(current)) {
            throw new SavedCardExpiredException(id);
        }
    }

    public boolean isExpired(YearMonth current) {
        return expiry.isExpired(current);
    }

    public String getId() { return id; }
    public String getCustomerId() { return customerId; }
    public String getCardToken() { return cardToken; }
    public String getTokenFingerprint() { return tokenFingerprint; }
    public String getMaskedPan() { return maskedPan; }
    public CardExpiry getExpiry() { return expiry; }
    public String getCardholderName() { return cardholderName; }
    public String getScheme() { return scheme; }
    public Instant getCreatedAt() { return createdAt; }

    @Override
    public String toString() {
        return "SavedCard[id=" + id + ", maskedPan=" + maskedPan + "]";
    }
}
