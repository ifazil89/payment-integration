package com.company.payintegration.threeds;

/**
 * What the frontend needs for a 3DS challenge. Two options:
 *  1. redirect the browser to challengePageUrl (our auto-submitting page), or
 *  2. POST a form field "creq" to acsUrl itself (e.g. inside an iframe).
 */
public record ThreeDsChallenge(String challengePageUrl, String acsUrl, String creq) {
}
