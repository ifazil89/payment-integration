package com.company.payintegration.savedcard.infrastructure;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

interface SavedCardJpaRepository extends JpaRepository<SavedCardEntity, String> {

    Optional<SavedCardEntity> findByCustomerIdAndTokenFingerprint(String customerId, String tokenFingerprint);

    List<SavedCardEntity> findByCustomerIdOrderByCreatedAtDesc(String customerId);
}
