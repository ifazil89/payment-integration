package com.company.payintegration.shared.util;

/**
 * Masks card data before it can reach a log line or toString().
 * PCI DSS: the full PAN must never be stored or logged; the CVV never at all.
 */
public final class SensitiveDataMasker {

    private SensitiveDataMasker() {
    }

    /** 4111111111111111 -> 411111******1111 */
    public static String maskPan(String pan) {
        if (pan == null || pan.length() < 10) {
            return "****";
        }
        return pan.substring(0, 6) + "*".repeat(pan.length() - 10) + pan.substring(pan.length() - 4);
    }

    public static String last4(String pan) {
        return pan == null || pan.length() < 4 ? "****" : pan.substring(pan.length() - 4);
    }
}
