package com.company.payintegration.payment.application.port;

import com.company.payintegration.shared.domain.BusinessException;

/** Two requests with the same Idempotency-Key arrived at the same moment. */
public class DuplicateIdempotencyKeyException extends BusinessException {

    public DuplicateIdempotencyKeyException(String idempotencyKey) {
        super(Kind.CONFLICT, "DUPLICATE_REQUEST",
                "A payment with Idempotency-Key " + idempotencyKey + " is already being processed");
    }
}
