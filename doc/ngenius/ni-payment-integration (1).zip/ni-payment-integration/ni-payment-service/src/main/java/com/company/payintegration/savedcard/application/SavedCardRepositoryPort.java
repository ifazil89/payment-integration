package com.company.payintegration.savedcard.application;

import com.company.payintegration.savedcard.domain.SavedCard;

import java.util.List;
import java.util.Optional;

public interface SavedCardRepositoryPort {

    SavedCard save(SavedCard card);

    Optional<SavedCard> findById(String id);

    Optional<SavedCard> findByCustomerAndFingerprint(String customerId, String tokenFingerprint);

    List<SavedCard> findByCustomer(String customerId);

    void delete(String id);
}
