package com.company.payintegration.payment.application.port;

import com.company.payintegration.shared.domain.BusinessException;

/**
 * The gateway answered and refused the operation (4xx). The outcome is KNOWN.
 * Not used for timeouts: those mean the outcome is unknown.
 */
public class GatewayRejectedException extends BusinessException {

    public GatewayRejectedException(String message) {
        super(Kind.INVALID, "GATEWAY_REJECTED", message);
    }
}
