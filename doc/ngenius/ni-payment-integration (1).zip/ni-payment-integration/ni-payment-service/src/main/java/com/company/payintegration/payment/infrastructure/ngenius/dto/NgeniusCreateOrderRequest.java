package com.company.payintegration.payment.infrastructure.ngenius.dto;

import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusAmount;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * POST /transactions/outlets/{outletId}/orders
 * action = "AUTH" for the two-stage flow (authorise now, capture later).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record NgeniusCreateOrderRequest(
        String action,
        NgeniusAmount amount,
        String emailAddress,
        String merchantOrderReference,
        BillingAddress billingAddress) {

    public static final String ACTION_AUTH = "AUTH";

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record BillingAddress(String firstName, String lastName) {
    }
}
