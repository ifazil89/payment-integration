package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.CreatedOrder;
import com.company.payintegration.payment.application.port.GatewayRejectedException;
import com.company.payintegration.payment.application.port.GatewayResult;
import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import com.company.payintegration.payment.domain.GatewayReference;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.threeds.ThreeDsFacade;
import com.company.payintegration.threeds.ThreeDsStartCommand;
import com.company.payintegration.threeds.ThreeDsStartResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.function.Function;

/**
 * The two-stage authorisation flow shared by card and saved-card payments:
 *
 *   0. Idempotency: same Idempotency-Key again -> return the existing payment, no new charge
 *   1. Save payment (CREATED)                 -> we have a record even if we crash next
 *   2. Create AUTH order at the gateway        -> save the gateway references immediately
 *   3. Send card / saved card                  -> AUTHORISED | AWAITING_3DS | DECLINED/FAILED
 *   4. If AWAITING_3DS: start 3DS              -> challenge for the frontend, or frictionless
 *
 * There is deliberately no database transaction around the gateway calls: each step is
 * saved on its own, so a crash or timeout leaves a record the reconciliation job can settle.
 */
@Component
class AuthorisationFlow {

    private static final Logger log = LoggerFactory.getLogger(AuthorisationFlow.class);

    private final PaymentRepositoryPort repository;
    private final PaymentGatewayPort gateway;
    private final PaymentStatusUpdater updater;
    private final PaymentOutcomeAssembler outcomeAssembler;
    private final ThreeDsFacade threeDsFacade;

    AuthorisationFlow(PaymentRepositoryPort repository, PaymentGatewayPort gateway, PaymentStatusUpdater updater,
                      PaymentOutcomeAssembler outcomeAssembler, ThreeDsFacade threeDsFacade) {
        this.repository = repository;
        this.gateway = gateway;
        this.updater = updater;
        this.outcomeAssembler = outcomeAssembler;
        this.threeDsFacade = threeDsFacade;
    }

    PaymentOutcome run(NewPaymentData data, Function<CreatedOrder, GatewayResult> paymentStep) {
        threeDsFacade.requireAllowedReturnUrl(data.returnUrl());   // fail fast, before any gateway call

        Optional<Payment> existing = repository.findByIdempotencyKey(data.idempotencyKey());
        if (existing.isPresent()) {
            log.info("Idempotent replay for key {}, returning payment {}", data.idempotencyKey(), existing.get().getId());
            return outcomeAssembler.assemble(existing.get());
        }

        // 1
        Payment payment = repository.save(Payment.create(data.merchantOrderId(), data.customerId(),
                data.idempotencyKey(), data.amount(), data.method(), data.saveCard()));

        // 2
        CreatedOrder order;
        try {
            order = gateway.createOrder(payment, data.customer());
        } catch (GatewayRejectedException ex) {
            PaymentStatus created = payment.getStatus();
            payment.fail(ex.getMessage());
            return PaymentOutcome.of(updater.save(payment, created));
        }
        payment.attachGatewayOrder(order.reference());
        payment = repository.save(payment);
        log.info("Payment {} created gateway order {}", payment.getId(), order.reference().orderReference());

        // 3
        PaymentStatus before = payment.getStatus();
        GatewayResult result;
        try {
            result = paymentStep.apply(order);
        } catch (GatewayRejectedException ex) {
            payment.fail(ex.getMessage());
            return PaymentOutcome.of(updater.save(payment, before));
        }
        payment = updater.apply(payment, before, result);

        // 4
        if (payment.getStatus() == PaymentStatus.AWAITING_3DS) {
            return startThreeDs(payment, data);
        }
        return PaymentOutcome.of(payment);
    }

    private PaymentOutcome startThreeDs(Payment payment, NewPaymentData data) {
        GatewayReference ref = payment.getGatewayReference();
        ThreeDsStartResult started = threeDsFacade.start(new ThreeDsStartCommand(payment.getId(), ref.outletId(),
                ref.orderReference(), ref.paymentReference(), data.browserInfo(), data.returnUrl()));

        payment.awaitThreeDs(started.sessionId());
        payment = updater.save(payment, payment.getStatus());

        if (started.challengeRequired()) {
            return new PaymentOutcome(payment, started.challenge());
        }
        // Frictionless: the gateway already continued with authorisation.
        return PaymentOutcome.of(updater.refresh(payment.getId()));
    }
}
