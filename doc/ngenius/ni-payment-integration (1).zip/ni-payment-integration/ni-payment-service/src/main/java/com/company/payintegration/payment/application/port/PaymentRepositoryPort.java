package com.company.payintegration.payment.application.port;

import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface PaymentRepositoryPort {

    /**
     * Inserts or updates (optimistic locking). Returns the stored payment with its new version;
     * always continue with the returned instance.
     *
     * @throws ConcurrentPaymentUpdateException  if the payment changed since it was loaded
     * @throws DuplicateIdempotencyKeyException  if a new payment reuses an idempotency key
     */
    Payment save(Payment payment);

    Optional<Payment> findById(String id);

    Optional<Payment> findByIdempotencyKey(String idempotencyKey);

    Optional<Payment> findByGatewayOrderReference(String orderReference);

    List<Payment> findByStatusCreatedBetween(Collection<PaymentStatus> statuses, Instant from, Instant to, int limit);
}
