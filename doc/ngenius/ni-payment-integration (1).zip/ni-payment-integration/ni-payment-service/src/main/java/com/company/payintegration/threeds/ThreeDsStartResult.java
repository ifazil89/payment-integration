package com.company.payintegration.threeds;

/**
 * challengeRequired = false means frictionless: the gateway already continued the payment,
 * so the caller should refresh the payment status.
 */
public record ThreeDsStartResult(String sessionId, boolean challengeRequired, ThreeDsChallenge challenge) {
}
