package com.company.payintegration.payment.infrastructure.persistence;

import com.company.payintegration.payment.domain.PaymentStatus;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

interface PaymentJpaRepository extends JpaRepository<PaymentEntity, String> {

    Optional<PaymentEntity> findByIdempotencyKey(String idempotencyKey);

    Optional<PaymentEntity> findByOrderReference(String orderReference);

    List<PaymentEntity> findByStatusInAndCreatedAtBetweenOrderByCreatedAtAsc(
            Collection<PaymentStatus> statuses, Instant from, Instant to, Pageable pageable);
}
