package com.company.payintegration.threeds.infrastructure.ngenius.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/** POST cnp:3ds2-challenge-response with the ACS "cres" value, unchanged (do not decode it). */
public record NgeniusChallengeResponseRequest(@JsonProperty("base64EncodedCRes") String base64EncodedCRes) {
}
