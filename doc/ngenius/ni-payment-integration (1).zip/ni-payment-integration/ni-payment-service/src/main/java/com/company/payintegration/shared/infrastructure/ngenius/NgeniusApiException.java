package com.company.payintegration.shared.infrastructure.ngenius;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * N-Genius answered with a 4xx/5xx status.
 *
 * Different from a timeout (ResourceAccessException): here we KNOW the call was rejected.
 * After a timeout the outcome is unknown and the reconciliation job must find out.
 */
public class NgeniusApiException extends RuntimeException {

    private static final int MAX_BODY_LENGTH = 1000;

    private final int status;
    private final String responseBody;

    public NgeniusApiException(int status, String path, String responseBody) {
        super("N-Genius returned HTTP " + status + " for " + path);
        this.status = status;
        this.responseBody = responseBody;
    }

    public static NgeniusApiException from(HttpRequest request, ClientHttpResponse response) throws IOException {
        String body = new String(response.getBody().readAllBytes(), StandardCharsets.UTF_8);
        if (body.length() > MAX_BODY_LENGTH) {
            body = body.substring(0, MAX_BODY_LENGTH) + "...";
        }
        return new NgeniusApiException(response.getStatusCode().value(), request.getURI().getPath(), body);
    }

    public int getStatus() {
        return status;
    }

    public String getResponseBody() {
        return responseBody;
    }

    public boolean isClientError() {
        return status >= 400 && status < 500;
    }
}
