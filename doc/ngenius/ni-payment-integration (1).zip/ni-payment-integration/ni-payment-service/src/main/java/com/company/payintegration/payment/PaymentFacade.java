package com.company.payintegration.payment;

/**
 * In-process facade of the payment feature (used by the webhook feature).
 * Not an HTTP API: the HTTP contract lives in ni-payment-api-schema (api.interfaces).
 */
public interface PaymentFacade {

    /**
     * Re-reads the order from N-Genius and applies its status.
     * Returns false if no payment exists for this N-Genius order reference.
     */
    boolean refreshFromGateway(String gatewayOrderReference);
}
