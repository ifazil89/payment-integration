package com.company.payintegration.threeds.application.port;

import com.company.payintegration.threeds.BrowserInfo;

public interface ThreeDsGatewayPort {

    /** Step 1: start EMV 3DS 2.x authentication (POST cnp:3ds2-authentication). */
    AuthenticationResult authenticate(String orderReference, String paymentReference, String notificationUrl,
                                      BrowserInfo browserInfo);

    /** Step 4: pass the ACS result through unchanged (POST cnp:3ds2-challenge-response). */
    void submitChallengeResult(String orderReference, String paymentReference, String cres);
}
