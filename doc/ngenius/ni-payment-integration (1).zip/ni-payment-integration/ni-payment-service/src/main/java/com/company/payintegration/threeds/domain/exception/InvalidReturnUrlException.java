package com.company.payintegration.threeds.domain.exception;

import com.company.payintegration.shared.domain.BusinessException;

/** returnUrl is not in app.threeds.allowed-return-url-prefixes (prevents open redirects). */
public class InvalidReturnUrlException extends BusinessException {

    public InvalidReturnUrlException(String returnUrl) {
        super(Kind.INVALID, "INVALID_RETURN_URL", "returnUrl is not allowed: " + returnUrl);
    }
}
