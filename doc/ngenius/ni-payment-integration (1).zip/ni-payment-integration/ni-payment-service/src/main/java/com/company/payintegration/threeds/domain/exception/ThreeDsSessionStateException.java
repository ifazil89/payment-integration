package com.company.payintegration.threeds.domain.exception;

import com.company.payintegration.shared.domain.BusinessException;
import com.company.payintegration.threeds.domain.ThreeDsSessionStatus;

public class ThreeDsSessionStateException extends BusinessException {

    public ThreeDsSessionStateException(String sessionId, ThreeDsSessionStatus actual, ThreeDsSessionStatus expected) {
        super(Kind.CONFLICT, "THREEDS_SESSION_STATE",
                "3DS session " + sessionId + " is " + actual + ", expected " + expected);
    }
}
