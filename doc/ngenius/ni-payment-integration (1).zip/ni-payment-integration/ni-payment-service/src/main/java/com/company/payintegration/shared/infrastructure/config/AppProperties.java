package com.company.payintegration.shared.infrastructure.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;
import java.util.List;

/** Settings of this middleware itself, bound from "app.*". */
@Validated
@ConfigurationProperties("app")
public record AppProperties(
        @NotNull @Valid Security security,
        @NotNull Backend backend,
        @NotNull @Valid Crypto crypto,
        @NotNull @Valid Threeds threeds,
        @NotNull @Valid Reconciliation reconciliation) {

    public record Security(@NotBlank String backendApiKey) {
        @Override
        public String toString() {
            return "Security[***]";
        }
    }

    /** callbackUrl may be empty: status changes are then only logged. */
    public record Backend(String callbackUrl) {
    }

    public record Crypto(@NotBlank String cardTokenKey) {
        @Override
        public String toString() {
            return "Crypto[***]";
        }
    }

    public record Threeds(@NotNull Duration sessionTtl, @NotEmpty List<String> allowedReturnUrlPrefixes) {
    }

    public record Reconciliation(@NotNull Duration fixedDelay,
                                 @NotNull Duration minAge,
                                 @NotNull Duration maxAge) {
    }
}
