package com.company.payintegration.payment.infrastructure.ngenius;

import com.company.payintegration.payment.domain.PaymentStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;

/**
 * N-Genius payment state -> our PaymentStatus. Unknown states return null (ignored and
 * logged) rather than guessing. Add new states here when N-Genius introduces them.
 */
final class NgeniusStateMapper {

    private static final Logger log = LoggerFactory.getLogger(NgeniusStateMapper.class);

    private NgeniusStateMapper() {
    }

    static PaymentStatus map(String state) {
        if (state == null) {
            return null;
        }
        return switch (state.toUpperCase(Locale.ROOT)) {
            case "STARTED" -> PaymentStatus.CREATED;
            case "AWAIT_3DS" -> PaymentStatus.AWAITING_3DS;
            case "AUTHORISED" -> PaymentStatus.AUTHORISED;
            case "PARTIALLY_CAPTURED" -> PaymentStatus.PARTIALLY_CAPTURED;
            case "CAPTURED", "PURCHASED" -> PaymentStatus.CAPTURED;
            case "PARTIALLY_REFUNDED" -> PaymentStatus.PARTIALLY_REFUNDED;
            case "REFUNDED" -> PaymentStatus.REFUNDED;
            case "REVERSED" -> PaymentStatus.REVERSED;
            case "DECLINED" -> PaymentStatus.DECLINED;
            case "FAILED" -> PaymentStatus.FAILED;
            default -> {
                log.warn("Unknown N-Genius payment state '{}', status left unchanged", state);
                yield null;
            }
        };
    }
}
