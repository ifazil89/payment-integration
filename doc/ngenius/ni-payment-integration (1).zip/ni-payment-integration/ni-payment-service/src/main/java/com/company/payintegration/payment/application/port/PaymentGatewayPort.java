package com.company.payintegration.payment.application.port;

import com.company.payintegration.payment.domain.GatewayReference;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.savedcard.SavedCardForPayment;
import com.company.payintegration.shared.domain.Money;

/**
 * Everything the payment feature needs from a payment gateway.
 * Implemented by NgeniusPaymentGatewayAdapter. A second gateway = a second adapter.
 *
 * Throws GatewayRejectedException when the gateway refuses (outcome known).
 * Timeouts are NOT translated: the caller must treat them as "outcome unknown".
 */
public interface PaymentGatewayPort {

    /** Two-stage flow, step 1: create an AUTH order (no money moves yet). */
    CreatedOrder createOrder(Payment payment, CustomerDetails customer);

    /** Step 2 with raw card details. */
    GatewayResult payWithCard(CreatedOrder order, CardData card);

    /** Step 2 with a saved card token (CVV still required). */
    GatewayResult payWithSavedCard(CreatedOrder order, SavedCardForPayment card, String cvv);

    /** Current status from the gateway (the source of truth). */
    GatewayResult fetchStatus(GatewayReference reference);

    GatewayResult capture(GatewayReference reference, Money amount);

    /** Cancels an authorisation that has no captures. */
    GatewayResult reverse(GatewayReference reference);

    GatewayResult refund(GatewayReference reference, Money amount);
}
