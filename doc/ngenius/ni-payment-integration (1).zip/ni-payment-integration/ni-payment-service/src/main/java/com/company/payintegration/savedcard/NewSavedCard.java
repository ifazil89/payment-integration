package com.company.payintegration.savedcard;

/** Card token data to store after a successful payment. */
public record NewSavedCard(String customerId, String cardToken, String maskedPan, String expiry,
                           String cardholderName, String scheme) {

    @Override
    public String toString() {
        return "NewSavedCard[customerId=" + customerId + ", maskedPan=" + maskedPan + "]";
    }
}
