package com.company.payintegration.shared.infrastructure.security;

import com.company.payintegration.shared.infrastructure.config.AppProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Two kinds of endpoints:
 *
 *   /api/**      private: only our backend (API key here; mTLS/OAuth2 in production)
 *   /ngenius/**  public: called by the shopper's browser (3DS) and by N-Genius (webhooks).
 *                These are protected by their own checks (session id, webhook header).
 */
@Configuration
class SecurityConfig {

    @Bean
    FilterRegistrationBean<BackendApiKeyFilter> backendApiKeyFilter(AppProperties appProperties) {
        FilterRegistrationBean<BackendApiKeyFilter> registration =
                new FilterRegistrationBean<>(new BackendApiKeyFilter(appProperties.security().backendApiKey()));
        registration.addUrlPatterns("/api/*");
        registration.setOrder(10);   // after CorrelationIdFilter
        return registration;
    }
}
