package com.company.payintegration.shared.domain;

/**
 * Base class for business-rule violations in every feature.
 * The GlobalExceptionHandler turns the kind into an HTTP status, so feature code never
 * deals with HTTP.
 */
public abstract class BusinessException extends RuntimeException {

    public enum Kind {
        NOT_FOUND,      // 404
        CONFLICT,       // 409: operation not allowed in the current state
        INVALID         // 422: request is well-formed but breaks a rule
    }

    private final Kind kind;
    private final String code;

    protected BusinessException(Kind kind, String code, String message) {
        super(message);
        this.kind = kind;
        this.code = code;
    }

    public Kind getKind() {
        return kind;
    }

    /** Stable machine-readable code for our backend, e.g. PAYMENT_NOT_FOUND. */
    public String getCode() {
        return code;
    }
}
