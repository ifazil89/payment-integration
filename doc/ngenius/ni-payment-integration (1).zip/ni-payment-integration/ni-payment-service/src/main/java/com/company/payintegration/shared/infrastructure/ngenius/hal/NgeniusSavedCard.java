package com.company.payintegration.shared.infrastructure.ngenius.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * "savedCard" block returned inside a successful payment when tokenisation is enabled
 * on the N-Genius account. Not returned for failed payments.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record NgeniusSavedCard(
        String cardToken,
        String maskedPan,
        String expiry,          // YYYY-MM
        String cardholderName,
        String scheme) {

    @Override
    public String toString() {
        return "NgeniusSavedCard[maskedPan=" + maskedPan + ", scheme=" + scheme + "]";
    }
}
