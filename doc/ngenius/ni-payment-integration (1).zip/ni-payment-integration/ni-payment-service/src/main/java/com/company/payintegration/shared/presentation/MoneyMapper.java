package com.company.payintegration.shared.presentation;

import com.company.payintegration.api.model.common.MoneyDto;
import com.company.payintegration.shared.domain.Money;

/** API model Money <-> domain Money. Shared by all features' presentation mappers. */
public final class MoneyMapper {

    private MoneyMapper() {
    }

    public static Money toDomain(MoneyDto dto) {
        return new Money(dto.value(), dto.currency());
    }

    public static MoneyDto toDto(Money money) {
        return new MoneyDto(money.amount(), money.currency());
    }
}
