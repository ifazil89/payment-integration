package com.company.payintegration.threeds.domain;

import com.company.payintegration.threeds.domain.exception.ThreeDsSessionStateException;

import java.time.Duration;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/**
 * One 3DS authentication attempt for a payment. Its id goes into the notificationURL, so
 * when the shopper's browser posts the challenge result we know which payment it belongs to.
 */
public class ThreeDsSession {

    private final String id;
    private final String paymentId;
    private final String outletId;
    private final String orderReference;
    private final String paymentReference;
    private final String returnUrl;
    private final Instant createdAt;
    private final Instant expiresAt;

    private ThreeDsSessionStatus status;
    private String acsUrl;
    private String creq;
    private Instant completedAt;

    private ThreeDsSession(String id, String paymentId, String outletId, String orderReference,
                           String paymentReference, String returnUrl, ThreeDsSessionStatus status, String acsUrl,
                           String creq, Instant createdAt, Instant expiresAt, Instant completedAt) {
        this.id = Objects.requireNonNull(id);
        this.paymentId = Objects.requireNonNull(paymentId);
        this.outletId = Objects.requireNonNull(outletId);
        this.orderReference = Objects.requireNonNull(orderReference);
        this.paymentReference = Objects.requireNonNull(paymentReference);
        this.returnUrl = Objects.requireNonNull(returnUrl);
        this.status = Objects.requireNonNull(status);
        this.acsUrl = acsUrl;
        this.creq = creq;
        this.createdAt = Objects.requireNonNull(createdAt);
        this.expiresAt = Objects.requireNonNull(expiresAt);
        this.completedAt = completedAt;
    }

    public static ThreeDsSession start(String paymentId, String outletId, String orderReference,
                                       String paymentReference, String returnUrl, Duration ttl) {
        Instant now = Instant.now();
        return new ThreeDsSession(UUID.randomUUID().toString(), paymentId, outletId, orderReference,
                paymentReference, returnUrl, ThreeDsSessionStatus.STARTED, null, null, now, now.plus(ttl), null);
    }

    public static ThreeDsSession restore(String id, String paymentId, String outletId, String orderReference,
                                         String paymentReference, String returnUrl, ThreeDsSessionStatus status,
                                         String acsUrl, String creq, Instant createdAt, Instant expiresAt,
                                         Instant completedAt) {
        return new ThreeDsSession(id, paymentId, outletId, orderReference, paymentReference, returnUrl, status,
                acsUrl, creq, createdAt, expiresAt, completedAt);
    }

    public void requireChallenge(String acsUrl, String creq) {
        requireStatus(ThreeDsSessionStatus.STARTED);
        this.acsUrl = Objects.requireNonNull(acsUrl, "acsUrl");
        this.creq = Objects.requireNonNull(creq, "creq");
        this.status = ThreeDsSessionStatus.CHALLENGE_REQUIRED;
    }

    public void markFrictionless() {
        requireStatus(ThreeDsSessionStatus.STARTED);
        this.status = ThreeDsSessionStatus.FRICTIONLESS;
        this.completedAt = Instant.now();
    }

    public void complete() {
        requireStatus(ThreeDsSessionStatus.CHALLENGE_REQUIRED);
        this.status = ThreeDsSessionStatus.COMPLETED;
        this.completedAt = Instant.now();
        this.creq = null;    // no longer needed
    }

    public void fail() {
        this.status = ThreeDsSessionStatus.FAILED;
        this.completedAt = Instant.now();
    }

    public void expire() {
        this.status = ThreeDsSessionStatus.EXPIRED;
        this.completedAt = Instant.now();
    }

    public boolean isExpired(Instant now) {
        return now.isAfter(expiresAt);
    }

    public boolean isAwaitingChallenge(Instant now) {
        return status == ThreeDsSessionStatus.CHALLENGE_REQUIRED && !isExpired(now);
    }

    private void requireStatus(ThreeDsSessionStatus expected) {
        if (status != expected) {
            throw new ThreeDsSessionStateException(id, status, expected);
        }
    }

    public String getId() { return id; }
    public String getPaymentId() { return paymentId; }
    public String getOutletId() { return outletId; }
    public String getOrderReference() { return orderReference; }
    public String getPaymentReference() { return paymentReference; }
    public String getReturnUrl() { return returnUrl; }
    public ThreeDsSessionStatus getStatus() { return status; }
    public String getAcsUrl() { return acsUrl; }
    public String getCreq() { return creq; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getExpiresAt() { return expiresAt; }
    public Instant getCompletedAt() { return completedAt; }
}
