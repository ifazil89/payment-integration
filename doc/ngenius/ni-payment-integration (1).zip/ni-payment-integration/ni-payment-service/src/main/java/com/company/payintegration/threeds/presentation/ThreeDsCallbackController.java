package com.company.payintegration.threeds.presentation;

import com.company.payintegration.api.interfaces.ThreeDsCallbackApi;
import com.company.payintegration.threeds.ThreeDsChallenge;
import com.company.payintegration.threeds.application.CompleteThreeDsChallengeUseCase;
import com.company.payintegration.threeds.application.GetChallengePageUseCase;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.HtmlUtils;

import java.net.URI;

/**
 * Implements the PUBLIC ThreeDsCallbackApi contract:
 *  - challenge page: auto-submits {creq} to the bank's ACS (nextAction.redirectUrl)
 *  - notification:   the ACS posts {cres} back via the shopper's browser; 303 to the shop
 */
@RestController
class ThreeDsCallbackController implements ThreeDsCallbackApi {

    private final GetChallengePageUseCase getChallengePage;
    private final CompleteThreeDsChallengeUseCase completeChallenge;

    ThreeDsCallbackController(GetChallengePageUseCase getChallengePage,
                              CompleteThreeDsChallengeUseCase completeChallenge) {
        this.getChallengePage = getChallengePage;
        this.completeChallenge = completeChallenge;
    }

    @Override
    public ResponseEntity<String> challengePage(String sessionId) {
        return getChallengePage.execute(sessionId)
                .map(challenge -> ResponseEntity.ok()
                        .cacheControl(CacheControl.noStore())
                        .body(autoSubmitForm(challenge)))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.GONE)
                        .cacheControl(CacheControl.noStore())
                        .body("<!doctype html><html><body><p>This payment verification is no longer available.</p>"
                                + "</body></html>"));
    }

    @Override
    public ResponseEntity<Void> challengeNotification(String sessionId, String cres) {
        String redirect = completeChallenge.execute(sessionId, cres);
        return ResponseEntity.status(HttpStatus.SEE_OTHER).location(URI.create(redirect)).build();
    }

    private static String autoSubmitForm(ThreeDsChallenge challenge) {
        String acsUrl = HtmlUtils.htmlEscape(challenge.acsUrl());
        String creq = HtmlUtils.htmlEscape(challenge.creq());
        return """
                <!doctype html>
                <html lang="en">
                <head><meta charset="utf-8"><title>Verifying your card</title></head>
                <body onload="document.forms[0].submit()">
                  <p>Redirecting to your bank to verify the payment&hellip;</p>
                  <form method="POST" action="%s">
                    <input type="hidden" name="creq" value="%s">
                    <noscript><button type="submit">Continue</button></noscript>
                  </form>
                </body>
                </html>
                """.formatted(acsUrl, creq);
    }
}
