package com.company.payintegration.webhook;

import com.company.payintegration.api.interfaces.NgeniusWebhookApi;
import com.company.payintegration.api.model.callback.NgeniusWebhookEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/** Implements the PUBLIC NgeniusWebhookApi contract. Must answer within 15 seconds. */
@RestController
class NgeniusWebhookController implements NgeniusWebhookApi {

    private static final Logger log = LoggerFactory.getLogger(NgeniusWebhookController.class);

    private final WebhookSecretVerifier verifier;
    private final ProcessWebhookService processor;

    NgeniusWebhookController(WebhookSecretVerifier verifier, ProcessWebhookService processor) {
        this.verifier = verifier;
        this.processor = processor;
    }

    @Override
    public ResponseEntity<Void> receiveWebhook(HttpHeaders headers, NgeniusWebhookEvent event) {
        if (!verifier.isValid(headers)) {
            log.warn("Rejected webhook {} with missing/invalid secret header", event.eventId());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        processor.process(event);
        return ResponseEntity.ok().build();
    }
}
