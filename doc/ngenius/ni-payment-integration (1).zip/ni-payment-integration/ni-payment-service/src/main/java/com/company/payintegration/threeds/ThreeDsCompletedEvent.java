package com.company.payintegration.threeds;

/**
 * Published when the challenge result has been sent to N-Genius.
 * The payment feature listens and refreshes the payment status from the gateway.
 * (An event instead of a call keeps threeds independent of payment: no cycle.)
 */
public record ThreeDsCompletedEvent(String sessionId, String paymentId) {
}
