package com.company.payintegration.payment.infrastructure.ngenius.dto;

/** PUT to "payment:saved-card": token, expiry, CVV and cardholder name are required. */
public record NgeniusSavedCardPaymentRequest(String cardToken, String expiry, String cvv, String cardholderName) {

    @Override
    public String toString() {
        return "NgeniusSavedCardPaymentRequest[***]";
    }
}
