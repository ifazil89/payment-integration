package com.company.payintegration.threeds.application.port;

import com.company.payintegration.threeds.domain.ThreeDsSession;

import java.util.Optional;

public interface ThreeDsSessionRepositoryPort {

    ThreeDsSession save(ThreeDsSession session);

    Optional<ThreeDsSession> findById(String id);
}
