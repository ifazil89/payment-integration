package com.company.payintegration.threeds.domain;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Builds the Base64 "creq" posted to the ACS:
 *   {"threeDSServerTransID":..., "acsTransID":..., "challengeWindowSize":..., "messageType":"CReq",
 *    "messageVersion":...}
 *
 * Only a fallback: N-Genius normally returns a ready-made base64EncodedCReq.
 */
public final class ChallengeRequestFactory {

    public static final String DEFAULT_WINDOW_SIZE = "05";   // full screen

    private ChallengeRequestFactory() {
    }

    public static String build(String threeDsServerTransId, String acsTransId, String challengeWindowSize,
                               String messageVersion) {
        String json = "{"
                + "\"threeDSServerTransID\":\"" + escape(threeDsServerTransId) + "\","
                + "\"acsTransID\":\"" + escape(acsTransId) + "\","
                + "\"challengeWindowSize\":\"" + escape(windowSizeOrDefault(challengeWindowSize)) + "\","
                + "\"messageType\":\"CReq\","
                + "\"messageVersion\":\"" + escape(messageVersion) + "\""
                + "}";
        return Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }

    public static String windowSizeOrDefault(String size) {
        return size == null || size.isBlank() ? DEFAULT_WINDOW_SIZE : size;
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
