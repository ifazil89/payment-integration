package com.company.payintegration.shared.presentation;

import com.company.payintegration.shared.domain.BusinessException;
import com.company.payintegration.shared.infrastructure.ngenius.NgeniusApiException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * One error format (RFC 9457 ProblemDetail) for the whole API, always with a "code" and
 * the "correlationId" so a failed call can be found in the logs.
 *
 * Spring MVC's own errors (validation, bad JSON, 404, 405) are handled by the parent class.
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(BusinessException.class)
    ProblemDetail business(BusinessException ex) {
        HttpStatus status = switch (ex.getKind()) {
            case NOT_FOUND -> HttpStatus.NOT_FOUND;
            case CONFLICT -> HttpStatus.CONFLICT;
            case INVALID -> HttpStatus.valueOf(422);   // Unprocessable Content
        };
        log.warn("Business rule: {} - {}", ex.getCode(), ex.getMessage());
        return problem(status, ex.getCode(), ex.getMessage());
    }

    /** e.g. unknown currency, too many decimals, bad Idempotency-Key. */
    @ExceptionHandler(IllegalArgumentException.class)
    ProblemDetail invalidArgument(IllegalArgumentException ex) {
        return problem(HttpStatus.BAD_REQUEST, "INVALID_REQUEST", ex.getMessage());
    }

    /** N-Genius rejected the call: the outcome is known (not charged by this call). */
    @ExceptionHandler(NgeniusApiException.class)
    ProblemDetail gatewayRejected(NgeniusApiException ex) {
        log.error("{} body={}", ex.getMessage(), ex.getResponseBody());
        return problem(HttpStatus.BAD_GATEWAY, "GATEWAY_ERROR", "Payment gateway rejected the request");
    }

    /**
     * Timeout or connection failure: the outcome is UNKNOWN. The payment may have gone
     * through. The backend must not retry blindly with a new idempotency key; the
     * reconciliation job will settle the status.
     */
    @ExceptionHandler(ResourceAccessException.class)
    ProblemDetail gatewayUnreachable(ResourceAccessException ex) {
        log.error("N-Genius unreachable: {}", ex.getMessage());
        return problem(HttpStatus.GATEWAY_TIMEOUT, "GATEWAY_TIMEOUT",
                "Payment gateway did not respond; status will be reconciled");
    }

    @ExceptionHandler(Exception.class)
    ProblemDetail unexpected(Exception ex) {
        log.error("Unexpected error", ex);
        return problem(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "Unexpected error");
    }

    private static ProblemDetail problem(HttpStatus status, String code, String detail) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setProperty("code", code);
        problem.setProperty("correlationId", MDC.get(CorrelationIdFilter.MDC_KEY));
        return problem;
    }
}
