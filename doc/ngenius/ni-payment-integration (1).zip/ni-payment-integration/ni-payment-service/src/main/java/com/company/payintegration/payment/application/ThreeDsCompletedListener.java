package com.company.payintegration.payment.application;

import com.company.payintegration.threeds.ThreeDsCompletedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/** After the shopper finished the 3DS challenge, read the final status from N-Genius. */
@Component
class ThreeDsCompletedListener {

    private static final Logger log = LoggerFactory.getLogger(ThreeDsCompletedListener.class);

    private final PaymentStatusUpdater updater;

    ThreeDsCompletedListener(PaymentStatusUpdater updater) {
        this.updater = updater;
    }

    @EventListener
    void on(ThreeDsCompletedEvent event) {
        try {
            var payment = updater.refresh(event.paymentId());
            log.info("3DS session {} completed, payment {} is {}", event.sessionId(), payment.getId(), payment.getStatus());
        } catch (RuntimeException ex) {
            // Don't break the shopper's redirect; webhook or reconciliation will catch up.
            log.warn("Could not refresh payment {} after 3DS: {}", event.paymentId(), ex.toString());
        }
    }
}
