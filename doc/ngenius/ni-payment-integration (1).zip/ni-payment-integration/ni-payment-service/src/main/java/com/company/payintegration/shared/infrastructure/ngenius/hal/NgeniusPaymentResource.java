package com.company.payintegration.shared.infrastructure.ngenius.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * A payment inside an N-Genius order (order._embedded.payment[i]).
 * Also the response body of card, saved-card, 3DS, capture and cancel calls.
 *
 * state values seen in the docs: STARTED, AWAIT_3DS, AUTHORISED, CAPTURED, PURCHASED,
 * FAILED, REVERSED (plus refund / partial states).
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record NgeniusPaymentResource(
        String reference,
        String orderReference,
        String state,
        NgeniusAmount amount,
        NgeniusSavedCard savedCard,
        @JsonProperty("3ds2") NgeniusThreeDs2 threeDs2,
        @JsonProperty("_links") Map<String, Object> links,
        @JsonProperty("_embedded") Embedded embedded) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Embedded(@JsonProperty("cnp:capture") List<NgeniusCaptureResource> captures) {
    }

    public Optional<String> link(String relation) {
        return HalLinks.href(links, relation);
    }

    public String requireLink(String relation) {
        return link(relation).orElseThrow(() -> new IllegalStateException(
                "N-Genius payment " + reference + " (state " + state + ") has no link '" + relation + "'"));
    }

    public List<NgeniusCaptureResource> captures() {
        return embedded != null && embedded.captures() != null ? embedded.captures() : List.of();
    }
}
