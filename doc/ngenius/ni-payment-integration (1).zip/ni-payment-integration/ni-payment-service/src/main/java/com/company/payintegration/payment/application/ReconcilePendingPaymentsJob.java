package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.PaymentRepositoryPort;
import com.company.payintegration.payment.domain.Payment;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.shared.infrastructure.config.AppProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.EnumSet;
import java.util.List;

/**
 * N-Genius webhooks are sent ONCE and never retried. If we miss one, or a call timed out,
 * the payment would stay pending forever. This job polls those payments.
 *
 *  - pending + has a gateway order    -> GET order and apply its status
 *  - pending + no gateway order        -> order creation failed or timed out before any card
 *                                         data was sent, so no money can have moved: FAILED
 *
 * In a multi-instance deployment, guard this with a distributed lock (e.g. ShedLock).
 */
@Component
class ReconcilePendingPaymentsJob {

    private static final Logger log = LoggerFactory.getLogger(ReconcilePendingPaymentsJob.class);
    private static final int BATCH_SIZE = 100;

    private final PaymentRepositoryPort repository;
    private final PaymentStatusUpdater updater;
    private final AppProperties.Reconciliation settings;

    ReconcilePendingPaymentsJob(PaymentRepositoryPort repository, PaymentStatusUpdater updater,
                                AppProperties appProperties) {
        this.repository = repository;
        this.updater = updater;
        this.settings = appProperties.reconciliation();
    }

    @Scheduled(fixedDelayString = "${app.reconciliation.fixed-delay}", initialDelayString = "PT30S")
    void reconcile() {
        Instant now = Instant.now();
        List<Payment> pending = repository.findByStatusCreatedBetween(
                EnumSet.of(PaymentStatus.CREATED, PaymentStatus.AWAITING_3DS),
                now.minus(settings.maxAge()), now.minus(settings.minAge()), BATCH_SIZE);

        if (!pending.isEmpty()) {
            log.info("Reconciling {} pending payments", pending.size());
        }
        for (Payment payment : pending) {
            try {
                if (payment.getGatewayReference() == null) {
                    PaymentStatus before = payment.getStatus();
                    payment.fail("Gateway order was not created; no card details were sent");
                    updater.save(payment, before);
                } else {
                    updater.refresh(payment.getId());
                }
            } catch (RuntimeException ex) {
                log.warn("Reconciliation of payment {} failed: {}", payment.getId(), ex.toString());
            }
        }
    }
}
