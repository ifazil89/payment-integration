package com.company.payintegration.threeds.domain;

public enum ThreeDsSessionStatus {
    STARTED,             // authentication request being sent
    CHALLENGE_REQUIRED,  // waiting for the shopper at the ACS
    FRICTIONLESS,        // no challenge needed; gateway continued by itself
    COMPLETED,           // challenge result (cres) sent to the gateway
    FAILED,
    EXPIRED
}
