package com.company.payintegration.shared.infrastructure.ngenius;

import com.company.payintegration.shared.infrastructure.ngenius.auth.NgeniusAccessTokenProvider;
import com.company.payintegration.shared.infrastructure.ngenius.auth.NgeniusBearerTokenInterceptor;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.ObjectProvider;
import io.micrometer.core.instrument.binder.httpcomponents.hc5.PoolingHttpClientConnectionManagerMetricsBinder;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.core5.util.TimeValue;
import org.apache.hc.core5.util.Timeout;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

/**
 * HTTP clients for N-Genius.
 *
 *  - One pooled Apache HttpClient with timeouts, stale-connection checks and idle eviction
 *    (the settings that prevent "works after restart, times out after a few days").
 *  - Pool metrics: httpcomponents.httpclient.pool.* tagged httpclient=ngenius.
 *  - ngeniusIdentityRestClient: only for the access-token call (no bearer header).
 *  - ngeniusRestClient: every other call; adds the bearer token, Accept header, logging,
 *    and turns 4xx/5xx into NgeniusApiException.
 *
 * Both clients are built from the auto-configured RestClient.Builder, so calls are also
 * measured (http.client.requests) and traced.
 */
@Configuration
class NgeniusHttpClientConfig {

    @Bean(destroyMethod = "close")
    CloseableHttpClient ngeniusHttpClient(NgeniusProperties properties, ObjectProvider<MeterRegistry> meterRegistry) {
        ConnectionConfig connectionConfig = ConnectionConfig.custom()
                .setConnectTimeout(Timeout.of(properties.connectTimeout()))
                .setSocketTimeout(Timeout.of(properties.responseTimeout()))
                .setTimeToLive(TimeValue.ofMinutes(5))
                .setValidateAfterInactivity(TimeValue.ofSeconds(10))
                .build();

        PoolingHttpClientConnectionManager connectionManager = PoolingHttpClientConnectionManagerBuilder.create()
                .setDefaultConnectionConfig(connectionConfig)
                .setMaxConnTotal(properties.maxConnections())
                .setMaxConnPerRoute(properties.maxConnections())
                .build();

        meterRegistry.ifAvailable(registry ->
                new PoolingHttpClientConnectionManagerMetricsBinder(connectionManager, "ngenius").bindTo(registry));

        return HttpClients.custom()
                .setConnectionManager(connectionManager)
                .evictIdleConnections(TimeValue.ofSeconds(30))
                .evictExpiredConnections()
                .setDefaultRequestConfig(RequestConfig.custom()
                        .setConnectionRequestTimeout(Timeout.ofSeconds(5))
                        .setResponseTimeout(Timeout.of(properties.responseTimeout()))
                        .build())
                .build();
    }

    @Bean
    RestClient ngeniusIdentityRestClient(RestClient.Builder builder,
                                         CloseableHttpClient ngeniusHttpClient,
                                         NgeniusProperties properties) {
        return builder.clone()
                .baseUrl(properties.baseUrl())
                .requestFactory(new HttpComponentsClientHttpRequestFactory(ngeniusHttpClient))
                .requestInterceptor(new NgeniusLoggingInterceptor())
                .defaultStatusHandler(HttpStatusCode::isError, (request, response) -> {
                    throw NgeniusApiException.from(request, response);
                })
                .build();
    }

    @Bean
    RestClient ngeniusRestClient(RestClient.Builder builder,
                                 CloseableHttpClient ngeniusHttpClient,
                                 NgeniusProperties properties,
                                 NgeniusAccessTokenProvider tokenProvider) {
        return builder.clone()
                .baseUrl(properties.baseUrl())
                .requestFactory(new HttpComponentsClientHttpRequestFactory(ngeniusHttpClient))
                .defaultHeader(HttpHeaders.ACCEPT, NgeniusMediaTypes.PAYMENT_V2.toString())
                .requestInterceptor(new NgeniusLoggingInterceptor())
                .requestInterceptor(new NgeniusBearerTokenInterceptor(tokenProvider))   // last: may retry on 401
                .defaultStatusHandler(HttpStatusCode::isError, (request, response) -> {
                    throw NgeniusApiException.from(request, response);
                })
                .build();
    }
}
