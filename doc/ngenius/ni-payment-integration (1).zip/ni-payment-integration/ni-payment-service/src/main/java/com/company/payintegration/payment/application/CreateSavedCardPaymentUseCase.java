package com.company.payintegration.payment.application;

import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.savedcard.SavedCardFacade;
import com.company.payintegration.savedcard.SavedCardForPayment;
import org.springframework.stereotype.Service;

/** Saved card: create AUTH order, then PUT token + expiry + CVV to "payment:saved-card". */
@Service
public class CreateSavedCardPaymentUseCase {

    private final AuthorisationFlow flow;
    private final PaymentGatewayPort gateway;
    private final SavedCardFacade savedCardFacade;

    public CreateSavedCardPaymentUseCase(AuthorisationFlow flow, PaymentGatewayPort gateway, SavedCardFacade savedCardFacade) {
        this.flow = flow;
        this.gateway = gateway;
        this.savedCardFacade = savedCardFacade;
    }

    public PaymentOutcome execute(CreateSavedCardPaymentCommand command) {
        // Checked before creating any order: card exists, belongs to the customer, not expired.
        SavedCardForPayment card = savedCardFacade.getForPayment(command.payment().customerId(), command.savedCardId());
        return flow.run(command.payment(), order -> gateway.payWithSavedCard(order, card, command.cvv()));
    }
}
