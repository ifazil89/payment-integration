package com.company.payintegration.shared.infrastructure.openapi;

import com.company.payintegration.api.ApiDocs;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;
import java.util.TreeMap;

/**
 * Builds the OpenAPI document from the annotated interfaces in ni-payment-api-schema.
 *
 * Two groups (selectable in Swagger UI):
 *   backend-api        /api/**      what our backend calls (API key)
 *   ngenius-callbacks  /ngenius/**  public endpoints for the shopper's browser and N-Genius
 *
 *   /v3/api-docs/backend-api, /v3/api-docs/ngenius-callbacks   (JSON)
 *   /swagger-ui.html                                            (UI; disabled in prod)
 */
@Configuration
@OpenAPIDefinition(info = @Info(title = ApiDocs.TITLE, version = ApiDocs.VERSION, description = ApiDocs.DESCRIPTION))
@SecurityScheme(name = ApiDocs.BACKEND_API_KEY, type = SecuritySchemeType.APIKEY, in = SecuritySchemeIn.HEADER,
        paramName = ApiDocs.HEADER_API_KEY, description = "Shared key of our backend (mTLS/OAuth2 in production)")
class OpenApiConfig {

    private static final String PROBLEM_REF = "#/components/schemas/ApiProblem";

    /** Errors any /api operation can return; added once here instead of on every interface method. */
    private static final Map<String, String> STANDARD_ERRORS = new TreeMap<>(Map.of(
            "400", "INVALID_REQUEST or validation error (bad JSON, missing field or header)",
            "401", "UNAUTHORIZED: missing or invalid X-Api-Key",
            "500", "INTERNAL_ERROR",
            "502", "GATEWAY_ERROR: N-Genius returned a server error",
            "504", "GATEWAY_TIMEOUT: N-Genius did not respond. Outcome UNKNOWN; retry with the SAME "
                    + "Idempotency-Key or GET the payment later"));

    @Bean
    GroupedOpenApi backendApi() {
        return GroupedOpenApi.builder()
                .group("backend-api")
                .displayName("Backend API")
                .pathsToMatch("/api/**")
                .addOpenApiCustomizer(standardErrors())
                .build();
    }

    @Bean
    GroupedOpenApi ngeniusCallbacks() {
        return GroupedOpenApi.builder()
                .group("ngenius-callbacks")
                .displayName("Public callbacks (3DS, webhooks)")
                .pathsToMatch("/ngenius/**")
                .build();
    }

    private static OpenApiCustomizer standardErrors() {
        return openApi -> {
            if (openApi.getPaths() == null) {
                return;
            }
            openApi.getPaths().values().forEach(path -> path.readOperations().forEach(operation -> {
                if (operation.getResponses() == null) {
                    operation.setResponses(new ApiResponses());
                }
                STANDARD_ERRORS.forEach((code, description) ->
                        operation.getResponses().computeIfAbsent(code, c -> problemResponse(description)));
            }));
        };
    }

    private static ApiResponse problemResponse(String description) {
        Content content = new Content().addMediaType(ApiDocs.PROBLEM_JSON,
                new io.swagger.v3.oas.models.media.MediaType().schema(new Schema<>().$ref(PROBLEM_REF)));
        return new ApiResponse().description(description).content(content);
    }
}
