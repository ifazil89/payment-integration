package com.company.payintegration.payment.domain;

import java.util.Objects;

/** Identifies the payment at N-Genius: outlet + order reference + payment reference. */
public record GatewayReference(String outletId, String orderReference, String paymentReference) {

    public GatewayReference {
        Objects.requireNonNull(outletId, "outletId");
        Objects.requireNonNull(orderReference, "orderReference");
        Objects.requireNonNull(paymentReference, "paymentReference");
    }
}
