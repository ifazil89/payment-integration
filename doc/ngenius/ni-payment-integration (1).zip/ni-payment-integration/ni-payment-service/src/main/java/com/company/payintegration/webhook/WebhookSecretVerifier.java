package com.company.payintegration.webhook;

import com.company.payintegration.shared.infrastructure.ngenius.NgeniusProperties;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * N-Genius webhooks are NOT signed. The only proof of origin is the custom header you
 * configure in the N-Genius portal (plus N-Genius IP allow-listing on your side).
 */
@Component
class WebhookSecretVerifier {

    private final String headerName;
    private final byte[] expectedValue;

    WebhookSecretVerifier(NgeniusProperties properties) {
        this.headerName = properties.webhook().headerName();
        this.expectedValue = properties.webhook().headerValue().getBytes(StandardCharsets.UTF_8);
    }

    boolean isValid(HttpHeaders headers) {
        String provided = headers.getFirst(headerName);    // header names are case-insensitive
        return provided != null && MessageDigest.isEqual(expectedValue, provided.getBytes(StandardCharsets.UTF_8));
    }
}
