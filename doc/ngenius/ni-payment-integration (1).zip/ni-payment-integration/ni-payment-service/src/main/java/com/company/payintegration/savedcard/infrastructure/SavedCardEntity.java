package com.company.payintegration.savedcard.infrastructure;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;

/** The token is stored ENCRYPTED (AES-GCM); see SavedCardRepositoryAdapter. */
@Entity
@Table(name = "saved_card")
class SavedCardEntity {

    @Id
    String id;
    @Column(name = "customer_id", nullable = false)
    String customerId;
    @Column(name = "card_token_encrypted", nullable = false, length = 1024)
    String cardTokenEncrypted;
    @Column(name = "token_fingerprint", nullable = false, length = 64)
    String tokenFingerprint;
    @Column(name = "masked_pan")
    String maskedPan;
    @Column(nullable = false, length = 7)
    String expiry;
    @Column(name = "cardholder_name")
    String cardholderName;
    String scheme;
    @Column(name = "created_at", nullable = false)
    Instant createdAt;

    protected SavedCardEntity() {
    }
}
