package com.company.payintegration.payment.domain;

public enum PaymentMethodType {
    CARD,
    SAVED_CARD
}
