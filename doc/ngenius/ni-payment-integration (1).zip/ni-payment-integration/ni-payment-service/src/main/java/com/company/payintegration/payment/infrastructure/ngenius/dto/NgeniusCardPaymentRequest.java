package com.company.payintegration.payment.infrastructure.ngenius.dto;

import com.company.payintegration.shared.util.SensitiveDataMasker;

/** PUT to "payment:card". */
public record NgeniusCardPaymentRequest(String pan, String expiry, String cvv, String cardholderName) {

    @Override
    public String toString() {
        return "NgeniusCardPaymentRequest[pan=" + SensitiveDataMasker.maskPan(pan) + ", cvv=***]";
    }
}
