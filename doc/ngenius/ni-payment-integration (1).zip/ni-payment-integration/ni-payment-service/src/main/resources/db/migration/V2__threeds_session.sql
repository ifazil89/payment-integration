CREATE TABLE threeds_session (
    id                VARCHAR(36)              NOT NULL PRIMARY KEY,
    payment_id        VARCHAR(36)              NOT NULL,
    outlet_id         VARCHAR(64)              NOT NULL,
    order_reference   VARCHAR(64)              NOT NULL,
    payment_reference VARCHAR(64)              NOT NULL,
    return_url        VARCHAR(2048)            NOT NULL,
    status            VARCHAR(30)              NOT NULL,
    acs_url           VARCHAR(2048),
    creq              VARCHAR(4000),
    created_at        TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at        TIMESTAMP WITH TIME ZONE NOT NULL,
    completed_at      TIMESTAMP WITH TIME ZONE
);

CREATE INDEX ix_threeds_session_payment ON threeds_session (payment_id);
