CREATE TABLE payment (
    id                  VARCHAR(36)              NOT NULL PRIMARY KEY,
    merchant_order_id   VARCHAR(64)              NOT NULL,
    customer_id         VARCHAR(64)              NOT NULL,
    idempotency_key     VARCHAR(100)             NOT NULL,
    amount              NUMERIC(19, 3)           NOT NULL,
    currency            VARCHAR(3)               NOT NULL,
    method              VARCHAR(20)              NOT NULL,
    save_card_requested BOOLEAN                  NOT NULL,
    status              VARCHAR(30)              NOT NULL,
    outlet_id           VARCHAR(64),
    order_reference     VARCHAR(64),
    payment_reference   VARCHAR(64),
    captured_amount     NUMERIC(19, 3)           NOT NULL,
    refunded_amount     NUMERIC(19, 3)           NOT NULL,
    threeds_session_id  VARCHAR(36),
    failure_reason      VARCHAR(500),
    created_at          TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at          TIMESTAMP WITH TIME ZONE NOT NULL,
    version             BIGINT                   NOT NULL,
    CONSTRAINT uk_payment_idempotency_key UNIQUE (idempotency_key)
);

CREATE INDEX ix_payment_order_reference ON payment (order_reference);
CREATE INDEX ix_payment_status_created ON payment (status, created_at);
CREATE INDEX ix_payment_merchant_order ON payment (merchant_order_id);
