-- card_token_encrypted: AES-256-GCM, Base64. The full card number is never stored.
CREATE TABLE saved_card (
    id                   VARCHAR(36)              NOT NULL PRIMARY KEY,
    customer_id          VARCHAR(64)              NOT NULL,
    card_token_encrypted VARCHAR(1024)            NOT NULL,
    token_fingerprint    VARCHAR(64)              NOT NULL,
    masked_pan           VARCHAR(32),
    expiry               VARCHAR(7)               NOT NULL,
    cardholder_name      VARCHAR(100),
    scheme               VARCHAR(30),
    created_at           TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT uk_saved_card_customer_token UNIQUE (customer_id, token_fingerprint)
);

CREATE INDEX ix_saved_card_customer ON saved_card (customer_id);
