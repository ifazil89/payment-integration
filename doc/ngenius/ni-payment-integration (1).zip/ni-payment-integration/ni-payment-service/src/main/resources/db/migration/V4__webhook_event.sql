CREATE TABLE webhook_event (
    event_id        VARCHAR(100)             NOT NULL PRIMARY KEY,
    event_name      VARCHAR(60),
    order_reference VARCHAR(64),
    received_at     TIMESTAMP WITH TIME ZONE NOT NULL,
    processed_at    TIMESTAMP WITH TIME ZONE,
    result          VARCHAR(500)
);

CREATE INDEX ix_webhook_event_order ON webhook_event (order_reference);
