package com.company.payintegration.payment.domain;

import com.company.payintegration.payment.domain.exception.InvalidAmountException;
import com.company.payintegration.payment.domain.exception.InvalidPaymentStateException;
import com.company.payintegration.shared.domain.Money;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** Plain unit tests: no Spring, no database, no gateway. */
class PaymentTest {

    private static Payment authorised(String amount) {
        Payment payment = Payment.create("order-1", "cust-1", "key-1", Money.of(amount, "AED"),
                PaymentMethodType.CARD, false);
        payment.attachGatewayOrder(new GatewayReference("outlet", "ni-order", "ni-payment"));
        payment.applyGatewayStatus(PaymentStatus.AUTHORISED);
        return payment;
    }

    @Test
    void rejectsZeroAmount() {
        assertThatThrownBy(() -> Payment.create("o", "c", "k", Money.of("0", "AED"), PaymentMethodType.CARD, false))
                .isInstanceOf(InvalidAmountException.class);
    }

    @Test
    void statusOnlyMovesForward() {
        Payment payment = authorised("100.00");
        payment.applyGatewayStatus(PaymentStatus.CAPTURED);

        boolean changed = payment.applyGatewayStatus(PaymentStatus.AUTHORISED);   // late webhook

        assertThat(changed).isFalse();
        assertThat(payment.getStatus()).isEqualTo(PaymentStatus.CAPTURED);
    }

    @Test
    void failureAfterAuthorisationIsIgnored() {
        Payment payment = authorised("100.00");

        assertThat(payment.applyGatewayStatus(PaymentStatus.FAILED)).isFalse();
        assertThat(payment.getStatus()).isEqualTo(PaymentStatus.AUTHORISED);
    }

    @Test
    void partialThenFullCapture() {
        Payment payment = authorised("100.00");

        payment.recordCapture(payment.ensureCanCapture(Money.of("40.00", "AED")));
        assertThat(payment.getStatus()).isEqualTo(PaymentStatus.PARTIALLY_CAPTURED);

        Money rest = payment.ensureCanCapture(null);
        assertThat(rest).isEqualTo(Money.of("60.00", "AED"));
        payment.recordCapture(rest);
        assertThat(payment.getStatus()).isEqualTo(PaymentStatus.CAPTURED);
    }

    @Test
    void cannotCaptureMoreThanAuthorised() {
        Payment payment = authorised("100.00");

        assertThatThrownBy(() -> payment.ensureCanCapture(Money.of("100.01", "AED")))
                .isInstanceOf(InvalidAmountException.class);
    }

    @Test
    void cannotCaptureInAnotherCurrency() {
        Payment payment = authorised("100.00");

        assertThatThrownBy(() -> payment.ensureCanCapture(Money.of("10.00", "USD")))
                .isInstanceOf(InvalidAmountException.class);
    }

    @Test
    void cannotReverseAfterCapture() {
        Payment payment = authorised("100.00");
        payment.recordCapture(payment.ensureCanCapture(Money.of("10.00", "AED")));

        assertThatThrownBy(payment::ensureCanReverse).isInstanceOf(InvalidPaymentStateException.class);
    }

    @Test
    void refundLimitedToCapturedAmount() {
        Payment payment = authorised("100.00");
        payment.recordCapture(payment.ensureCanCapture(Money.of("30.00", "AED")));

        assertThatThrownBy(() -> payment.ensureCanRefund(Money.of("30.01", "AED")))
                .isInstanceOf(InvalidAmountException.class);

        payment.ensureCanRefund(Money.of("30.00", "AED"));
        payment.recordRefund(Money.of("30.00", "AED"));
        assertThat(payment.getStatus()).isEqualTo(PaymentStatus.REFUNDED);
    }

    @Test
    void cannotRefundBeforeCapture() {
        Payment payment = authorised("100.00");

        assertThatThrownBy(() -> payment.ensureCanRefund(Money.of("10.00", "AED")))
                .isInstanceOf(InvalidPaymentStateException.class);
    }

    @Test
    void savedCardPaymentNeverRequestsSavingAgain() {
        Payment payment = Payment.create("o", "c", "k", Money.of("5.00", "AED"), PaymentMethodType.SAVED_CARD, true);

        assertThat(payment.isSaveCardRequested()).isFalse();
    }
}
