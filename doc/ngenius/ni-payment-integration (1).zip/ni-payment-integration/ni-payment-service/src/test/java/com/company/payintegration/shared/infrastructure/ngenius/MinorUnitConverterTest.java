package com.company.payintegration.shared.infrastructure.ngenius;

import com.company.payintegration.shared.domain.Money;
import com.company.payintegration.shared.infrastructure.ngenius.hal.NgeniusAmount;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MinorUnitConverterTest {

    @Test
    void aedHasTwoDecimals() {
        assertThat(MinorUnitConverter.toNgenius(Money.of("12.50", "AED")).value()).isEqualTo(1250L);
        assertThat(MinorUnitConverter.fromNgenius(new NgeniusAmount("AED", 1250L))).isEqualTo(Money.of("12.5", "AED"));
    }

    @Test
    void kwdHasThreeDecimals() {
        assertThat(MinorUnitConverter.toNgenius(Money.of("1.250", "KWD")).value()).isEqualTo(1250L);
    }

    @Test
    void moneyRejectsTooManyDecimals() {
        assertThatThrownBy(() -> Money.of("1.001", "AED")).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void moneyRejectsUnknownCurrency() {
        assertThatThrownBy(() -> Money.of("1.00", "XXQ")).isInstanceOf(IllegalArgumentException.class);
    }
}
