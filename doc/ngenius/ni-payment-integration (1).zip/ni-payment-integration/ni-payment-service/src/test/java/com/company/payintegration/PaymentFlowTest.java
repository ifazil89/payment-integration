package com.company.payintegration;

import com.company.payintegration.payment.application.port.CreatedOrder;
import com.company.payintegration.payment.application.port.GatewayResult;
import com.company.payintegration.payment.application.port.PaymentGatewayPort;
import com.company.payintegration.payment.domain.GatewayReference;
import com.company.payintegration.payment.domain.PaymentStatus;
import com.company.payintegration.threeds.application.port.AuthenticationResult;
import com.company.payintegration.threeds.application.port.ThreeDsGatewayPort;
import com.jayway.jsonpath.JsonPath;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.startsWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Full application (controllers, use cases, H2 database, Flyway) with only the two
 * N-Genius adapters replaced by mocks. Runs without N-Genius credentials.
 */
@SpringBootTest(properties = {"ngenius.api-key=test-key", "ngenius.outlet-id=test-outlet"})
@AutoConfigureMockMvc
class PaymentFlowTest {

    private static final String API_KEY = "sandbox-backend-key";   // default in application-sandbox.yml

    @Autowired
    MockMvc mvc;

    @MockitoBean
    PaymentGatewayPort gateway;

    @MockitoBean
    ThreeDsGatewayPort threeDsGateway;

    @Test
    void authorisedCardPaymentIsIdempotent() throws Exception {
        givenOrder("order-1", "pay-1");
        when(gateway.payWithCard(any(), any()))
                .thenReturn(new GatewayResult(PaymentStatus.AUTHORISED, "AUTHORISED", null));

        String first = mvc.perform(cardPayment("idem-1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("AUTHORISED"))
                .andExpect(jsonPath("$.gatewayOrderReference").value("order-1"))
                .andReturn().getResponse().getContentAsString();

        String second = mvc.perform(cardPayment("idem-1"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();

        String id1 = JsonPath.read(first, "$.paymentId");
        String id2 = JsonPath.read(second, "$.paymentId");
        org.assertj.core.api.Assertions.assertThat(id2).isEqualTo(id1);
        verify(gateway, times(1)).createOrder(any(), any());     // charged once
    }

    @Test
    void threeDsChallengeFlow() throws Exception {
        givenOrder("order-2", "pay-2");
        when(gateway.payWithCard(any(), any()))
                .thenReturn(new GatewayResult(PaymentStatus.AWAITING_3DS, "AWAIT_3DS", null));
        when(threeDsGateway.authenticate(eq("order-2"), eq("pay-2"), anyString(), any()))
                .thenReturn(new AuthenticationResult("C", "https://acs.example.com/challenge", "Y3JlcQ==",
                        "server-trans", "acs-trans", "2.2.0", "AWAIT_3DS"));

        // 1. payment needs a challenge
        String body = mvc.perform(cardPayment("idem-2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("AWAITING_3DS"))
                .andExpect(jsonPath("$.nextAction.type").value("THREEDS_CHALLENGE"))
                .andExpect(jsonPath("$.nextAction.acsUrl").value("https://acs.example.com/challenge"))
                .andExpect(jsonPath("$.nextAction.creq").value("Y3JlcQ=="))
                .andReturn().getResponse().getContentAsString();
        String paymentId = JsonPath.read(body, "$.paymentId");
        String redirectUrl = JsonPath.read(body, "$.nextAction.redirectUrl");
        String sessionId = redirectUrl.substring(redirectUrl.lastIndexOf('/') + 1);

        // 2. the challenge page auto-posts creq to the ACS
        mvc.perform(get("/ngenius/3ds/challenge/" + sessionId))
                .andExpect(status().isOk());

        // 3. the ACS posts cres back; N-Genius now reports AUTHORISED
        when(gateway.fetchStatus(any())).thenReturn(new GatewayResult(PaymentStatus.AUTHORISED, "AUTHORISED", null));
        mvc.perform(post("/ngenius/3ds/notification/" + sessionId)
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("cres", "result-from-acs"))
                .andExpect(status().isSeeOther())
                .andExpect(header().string("Location", startsWith("http://localhost:3000/checkout/result?paymentId=")));

        verify(threeDsGateway).submitChallengeResult("order-2", "pay-2", "result-from-acs");

        // 4. our backend sees the final status
        mvc.perform(get("/api/v1/payments/" + paymentId).header("X-Api-Key", API_KEY))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("AUTHORISED"));
    }

    @Test
    void apiRequiresBackendKey() throws Exception {
        mvc.perform(get("/api/v1/payments/anything"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void returnUrlMustBeAllowed() throws Exception {
        mvc.perform(post("/api/v1/payments/card")
                        .header("X-Api-Key", API_KEY)
                        .header("Idempotency-Key", "idem-3")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(cardPaymentJson("https://evil.example.com/steal")))
                .andExpect(status().is(422))
                .andExpect(jsonPath("$.code").value("INVALID_RETURN_URL"));

        verify(gateway, times(0)).createOrder(any(), any());   // rejected before any gateway call
    }

    // ------------------------------------------------------------------ helpers

    private void givenOrder(String orderRef, String paymentRef) {
        when(gateway.createOrder(any(), any())).thenReturn(new CreatedOrder(
                new GatewayReference("test-outlet", orderRef, paymentRef),
                "https://api-gateway.sandbox.ngenius-payments.com/card", null));
    }

    private org.springframework.test.web.servlet.RequestBuilder cardPayment(String idempotencyKey) {
        return post("/api/v1/payments/card")
                .header("X-Api-Key", API_KEY)
                .header("Idempotency-Key", idempotencyKey)
                .contentType(MediaType.APPLICATION_JSON)
                .content(cardPaymentJson("http://localhost:3000/checkout/result"));
    }

    private static String cardPaymentJson(String returnUrl) {
        return """
                {
                  "merchantOrderId": "SO-1001",
                  "customerId": "cust-42",
                  "amount": {"value": 250.00, "currency": "AED"},
                  "customer": {"email": "jane@example.com", "firstName": "Jane", "lastName": "Doe"},
                  "card": {"pan": "4111111111111111", "expiry": "2030-12", "cvv": "123", "cardholderName": "Jane Doe"},
                  "browserInfo": {
                    "acceptHeader": "text/html", "javaEnabled": false, "language": "en", "timeZoneOffset": "-240",
                    "userAgent": "Mozilla/5.0", "colorDepth": "24", "screenHeight": "900", "screenWidth": "1440",
                    "javascriptEnabled": true, "ip": "203.0.113.10", "challengeWindowSize": "05"
                  },
                  "returnUrl": "%s",
                  "saveCard": false
                }
                """.formatted(returnUrl);
    }
}
