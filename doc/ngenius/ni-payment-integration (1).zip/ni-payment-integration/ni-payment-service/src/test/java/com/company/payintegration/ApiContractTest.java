package com.company.payintegration;

import com.company.payintegration.api.model.payment.PaymentStatusDto;
import com.company.payintegration.payment.domain.PaymentStatus;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

/** The API schema and the domain are separate on purpose; this keeps them in sync. */
class ApiContractTest {

    @Test
    void everyDomainStatusExistsInTheApiSchema() {
        Set<String> api = Arrays.stream(PaymentStatusDto.values()).map(Enum::name).collect(Collectors.toSet());
        Set<String> domain = Arrays.stream(PaymentStatus.values()).map(Enum::name).collect(Collectors.toSet());

        assertThat(api).containsExactlyInAnyOrderElementsOf(domain);
    }
}
