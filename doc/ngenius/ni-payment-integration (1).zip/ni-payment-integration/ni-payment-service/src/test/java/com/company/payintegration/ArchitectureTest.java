package com.company.payintegration;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

/**
 * Enforces the folder rules, so the structure does not erode over time:
 *  - domain is plain Java
 *  - application/presentation never use their feature's infrastructure directly
 *  - features use each other ONLY through the other feature's root package (its public API)
 *  - shared never depends on a feature
 *  - the API schema (ni-payment-api-schema) is used only at the edges: presentation, webhook,
 *    shared presentation/openapi. Use cases and the domain never see HTTP models.
 */
@AnalyzeClasses(packages = "com.company.payintegration", importOptions = ImportOption.DoNotIncludeTests.class)
class ArchitectureTest {

    private static final String BASE = "com.company.payintegration.";

    @ArchTest
    static final ArchRule domainIsPlainJava = noClasses()
            .that().resideInAPackage("..domain..")
            .should().dependOnClassesThat().resideInAnyPackage(
                    "org.springframework..", "jakarta.persistence..", "com.fasterxml..", "tools.jackson..",
                    "..application..", "..presentation..", "..infrastructure..");

    @ArchTest
    static final ArchRule applicationDoesNotUseOwnInfrastructure = noClasses()
            .that().resideInAnyPackage(BASE + "payment.application..", BASE + "threeds.application..",
                    BASE + "savedcard.application..")
            .should().dependOnClassesThat().resideInAnyPackage(BASE + "payment.infrastructure..",
                    BASE + "threeds.infrastructure..", BASE + "savedcard.infrastructure..");

    @ArchTest
    static final ArchRule presentationDoesNotUseInfrastructure = noClasses()
            .that().resideInAPackage("..presentation..")
            .should().dependOnClassesThat().resideInAnyPackage(BASE + "payment.infrastructure..",
                    BASE + "threeds.infrastructure..", BASE + "savedcard.infrastructure..");

    @ArchTest
    static final ArchRule paymentUsesOnlyPublicApiOfOtherFeatures = noClasses()
            .that().resideInAPackage(BASE + "payment..")
            .should().dependOnClassesThat().resideInAnyPackage(
                    BASE + "threeds.application..", BASE + "threeds.domain..", BASE + "threeds.infrastructure..",
                    BASE + "threeds.presentation..", BASE + "savedcard.application..", BASE + "savedcard.domain..",
                    BASE + "savedcard.infrastructure..", BASE + "savedcard.presentation..", BASE + "webhook..");

    @ArchTest
    static final ArchRule threedsDoesNotDependOnOtherFeatures = noClasses()
            .that().resideInAPackage(BASE + "threeds..")
            .should().dependOnClassesThat().resideInAnyPackage(BASE + "payment..", BASE + "savedcard..",
                    BASE + "webhook..");

    @ArchTest
    static final ArchRule savedcardDoesNotDependOnOtherFeatures = noClasses()
            .that().resideInAPackage(BASE + "savedcard..")
            .should().dependOnClassesThat().resideInAnyPackage(BASE + "payment..", BASE + "threeds..",
                    BASE + "webhook..");

    @ArchTest
    static final ArchRule webhookUsesOnlyPaymentApi = noClasses()
            .that().resideInAPackage(BASE + "webhook..")
            .should().dependOnClassesThat().resideInAnyPackage(BASE + "payment.application..",
                    BASE + "payment.domain..", BASE + "payment.infrastructure..", BASE + "payment.presentation..",
                    BASE + "threeds..", BASE + "savedcard..");

    @ArchTest
    static final ArchRule apiSchemaOnlyAtTheEdges = noClasses()
            .that().resideInAnyPackage("..domain..", "..application..",
                    BASE + "payment.infrastructure..", BASE + "threeds.infrastructure..",
                    BASE + "savedcard.infrastructure..")
            .should().dependOnClassesThat().resideInAPackage(BASE + "api..");

    @ArchTest
    static final ArchRule sharedDoesNotDependOnFeatures = noClasses()
            .that().resideInAPackage(BASE + "shared..")
            .should().dependOnClassesThat().resideInAnyPackage(BASE + "payment..", BASE + "threeds..",
                    BASE + "savedcard..", BASE + "webhook..");
}
