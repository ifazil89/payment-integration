package com.company.payintegration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Checks that the OpenAPI document is generated from the interfaces, and exports it to
 * target/openapi/*.json on every build (share it, or feed it to a client generator).
 */
@SpringBootTest(properties = {"ngenius.api-key=test-key", "ngenius.outlet-id=test-outlet"})
@AutoConfigureMockMvc
class OpenApiSpecTest {

    private static final Path EXPORT_DIR = Path.of("target", "openapi");

    @Autowired
    MockMvc mvc;

    @Test
    void backendApiIsDocumentedFromTheInterfaces() throws Exception {
        String json = mvc.perform(get("/v3/api-docs/backend-api"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.title").value("N-Genius Payment Integration API"))
                .andExpect(jsonPath("$.paths['/api/v1/payments/card'].post.operationId").value("payWithCard"))
                .andExpect(jsonPath("$.paths['/api/v1/payments/{paymentId}/capture'].post.operationId")
                        .value("capturePayment"))
                .andExpect(jsonPath("$.paths['/api/v1/customers/{customerId}/saved-cards'].get").exists())
                // standard errors added by the customizer
                .andExpect(jsonPath("$.paths['/api/v1/payments/card'].post.responses['504']").exists())
                .andExpect(jsonPath("$.components.schemas.CreateCardPaymentRequest").exists())
                .andExpect(jsonPath("$.components.schemas.ApiProblem").exists())
                .andExpect(jsonPath("$.components.securitySchemes.backendApiKey.name").value("X-Api-Key"))
                // public endpoints are NOT in the backend group
                .andExpect(jsonPath("$.paths['/ngenius/webhooks']").doesNotExist())
                .andReturn().getResponse().getContentAsString();

        export("backend-api.json", json);
    }

    @Test
    void callbacksAreDocumentedSeparately() throws Exception {
        String json = mvc.perform(get("/v3/api-docs/ngenius-callbacks"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.paths['/ngenius/webhooks'].post.operationId").value("receiveNgeniusWebhook"))
                .andExpect(jsonPath("$.paths['/ngenius/3ds/notification/{sessionId}'].post").exists())
                .andExpect(jsonPath("$.paths['/api/v1/payments/card']").doesNotExist())
                .andReturn().getResponse().getContentAsString();

        export("ngenius-callbacks.json", json);
    }

    private static void export(String fileName, String json) throws Exception {
        Files.createDirectories(EXPORT_DIR);
        Files.writeString(EXPORT_DIR.resolve(fileName), json, StandardCharsets.UTF_8);
    }
}
