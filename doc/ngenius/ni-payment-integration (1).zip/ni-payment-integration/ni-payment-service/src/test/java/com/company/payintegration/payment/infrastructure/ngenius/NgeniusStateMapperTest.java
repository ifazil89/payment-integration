package com.company.payintegration.payment.infrastructure.ngenius;

import com.company.payintegration.payment.domain.PaymentStatus;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;

class NgeniusStateMapperTest {

    @ParameterizedTest
    @CsvSource({
            "STARTED, CREATED",
            "AWAIT_3DS, AWAITING_3DS",
            "AUTHORISED, AUTHORISED",
            "CAPTURED, CAPTURED",
            "PURCHASED, CAPTURED",
            "REVERSED, REVERSED",
            "FAILED, FAILED"
    })
    void mapsKnownStates(String ngeniusState, PaymentStatus expected) {
        assertThat(NgeniusStateMapper.map(ngeniusState)).isEqualTo(expected);
    }

    @ParameterizedTest
    @CsvSource({"SOMETHING_NEW", "''"})
    void unknownStatesAreIgnored(String ngeniusState) {
        assertThat(NgeniusStateMapper.map(ngeniusState)).isNull();
    }
}
