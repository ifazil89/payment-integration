package com.company.payment.payment;

import com.company.payment.common.dto.Amount;
import com.company.payment.payment.dto.BillingInfo;
import com.company.payment.payment.dto.CardInfo;
import com.company.payment.payment.dto.CardType;
import com.company.payment.payment.dto.DeviceInfo;
import com.company.payment.payment.dto.PaymentRequest;
import com.company.payment.payment.dto.PaymentStatus;
import com.company.payment.ni.dto.NiBrowserInfo;
import com.company.payment.ni.dto.NiOrderRequest;
import com.company.payment.payment.entity.Payment;
import com.company.payment.payment.entity.PaymentCardType;
import com.company.payment.payment.entity.PaymentState;
import com.company.payment.payment.mapper.PaymentMapper;
import com.company.payment.payment.mapper.PaymentNiMapper;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/** The MapStruct mappers against the API DTOs, without Spring. */
class PaymentMappersTest {

    private final PaymentMapper paymentMapper = Mappers.getMapper(PaymentMapper.class);
    private final PaymentNiMapper niMapper = Mappers.getMapper(PaymentNiMapper.class);

    private static PaymentRequest request(String amount, String currency) {
        return new PaymentRequest("SO-1", CardType.CARD,
                new CardInfo("4111111111111111", null, "2030-12", "123", "Jane Doe"),
                new Amount(new BigDecimal(amount), currency),
                new BillingInfo("Jane", "Doe", "jane@example.com", "Street 1", "Dubai", "AE"),
                new DeviceInfo("203.0.113.10", "UA", "text/html", "en", "-240", "1440", "900", "24", true, false, null));
    }

    @Test
    void orderRequestUsesMinorUnitsAndAuthAction() {
        NiOrderRequest order = niMapper.toOrderRequest(request("250.00", "AED"));

        assertThat(order.action()).isEqualTo("AUTH");
        assertThat(order.amount().value()).isEqualTo(25000L);
        assertThat(order.merchantOrderReference()).isEqualTo("SO-1");
        assertThat(order.billingAddress().address1()).isEqualTo("Street 1");

        assertThat(niMapper.toOrderRequest(request("1.25", "KWD")).amount().value()).isEqualTo(1250L);   // 3 decimals
    }

    @Test
    void browserInfoUsesFullScreenChallengeByDefault() {
        NiBrowserInfo browser = niMapper.toBrowserInfo(request("1", "AED").deviceInfo());

        assertThat(browser.challengeWindowSize()).isEqualTo("05");
        assertThat(browser.browserTz()).isEqualTo("-240");
        assertThat(browser.browserIp()).isEqualTo("203.0.113.10");
    }

    @Test
    void entityKeepsOnlyTheMaskedPan() {
        Payment payment = paymentMapper.toEntity(request("250.00", "AED"));

        assertThat(payment.getMaskedPan()).isEqualTo("411111******1111");
        assertThat(payment.getCardType()).isEqualTo(PaymentCardType.CARD);
        assertThat(payment.getEmail()).isEqualTo("jane@example.com");
    }

    @Test
    void responseHasCurrencyScaleAndUtcTime() {
        Payment payment = paymentMapper.toEntity(request("250", "AED"));
        payment.setAmount(new BigDecimal("250.000"));          // as read back from NUMERIC(19,3)
        payment.start("client", "key", "hash");

        var response = paymentMapper.toResponse(payment);

        assertThat(response.amount().value()).isEqualByComparingTo("250.00");
        assertThat(response.amount().value().scale()).isEqualTo(2);
        assertThat(response.status()).isEqualTo(PaymentStatus.PENDING);
        assertThat(response.createdAt().getOffset().getTotalSeconds()).isZero();
    }

    @Test
    void internalStatesShownAsPending() {
        assertThat(paymentMapper.toStatus(PaymentState.CREATED)).isEqualTo(PaymentStatus.PENDING);
        assertThat(paymentMapper.toStatus(PaymentState.AWAITING_3DS)).isEqualTo(PaymentStatus.PENDING);
        assertThat(paymentMapper.toStatus(PaymentState.CHALLENGE_REQUIRED)).isEqualTo(PaymentStatus.CHALLENGE_REQUIRED);
    }

    @Test
    void niStatesAreMapped() {
        assertThat(PaymentState.fromNi("AWAIT_3DS")).isEqualTo(PaymentState.AWAITING_3DS);
        assertThat(PaymentState.fromNi("SOMETHING_NEW")).isNull();
    }
}
