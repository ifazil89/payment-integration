package com.company.payment.common.logging;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;

import java.nio.charset.StandardCharsets;

import static org.assertj.core.api.Assertions.assertThat;

/** PCI DSS: no full card number, CVV, token or credential may ever reach a log line. */
class SensitiveDataMaskerTest {

    private final SensitiveDataMasker masker = new SensitiveDataMasker(new LoggingProperties(true, 10_000));

    @Test
    void masksCardDataAndTokensButKeepsTheRest() {
        String json = """
                {"card":{"pan":"4111111111111111","expiry":"2030-12","cvv":"123","cardholderName":"Jane"},\
                "cardToken" : "tok-abc","access_token":"eyJx","email":"jane@example.com"}""";

        String masked = masker.maskJson(json);

        assertThat(masked)
                .contains("\"pan\":\"411111******1111\"", "\"cvv\":\"***\"", "\"cardToken\" : \"***\"",
                        "\"access_token\":\"***\"", "\"expiry\":\"2030-12\"", "jane@example.com")
                .doesNotContain("4111111111111111", "tok-abc", "eyJx");
    }

    @Test
    void masksNumericCutOffAndEscapedValues() {
        assertThat(masker.maskJson("{\"pan\": 4111111111111111}")).isEqualTo("{\"pan\": \"411111******1111\"}");
        assertThat(masker.maskJson("{\"pan\":\"41111111111")).doesNotContain("41111111111");     // body cut mid-value
        assertThat(masker.maskJson("{\"token\":\"a\\\"b\",\"x\":1}")).isEqualTo("{\"token\":\"***\",\"x\":1}");
    }

    @Test
    void masksSecretHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer secret");
        headers.add("X-Api-Key", "sandbox-key");
        headers.add("traceparent", "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01");

        assertThat(masker.headers(headers))
                .contains("Authorization=***", "X-Api-Key=***", "traceparent=00-4bf92f")
                .doesNotContain("secret", "sandbox-key");
    }

    @Test
    void bodyIsTruncatedAndBinaryIsNotLogged() {
        byte[] json = "{\"pan\":\"4111111111111111\",\"long\":\"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\"}".getBytes(StandardCharsets.UTF_8);

        assertThat(new SensitiveDataMasker(new LoggingProperties(true, 30)).body(json, "application/json"))
                .contains("411111******1111").contains("[truncated");
        assertThat(masker.body(new byte[]{1, 2}, "image/png")).isEqualTo("[2 bytes image/png]");
        assertThat(new SensitiveDataMasker(new LoggingProperties(false, 30)).body(json, "application/json"))
                .isEqualTo("[not logged]");
    }
}
