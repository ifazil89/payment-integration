package com.company.payment.contract;

import com.company.payment.common.dto.Amount;
import com.company.payment.common.exception.ErrorDetail;
import com.company.payment.common.exception.ErrorResponse;
import com.company.payment.payment.dto.BillingInfo;
import com.company.payment.payment.dto.CardInfo;
import com.company.payment.payment.dto.CardType;
import com.company.payment.payment.dto.DeviceInfo;
import com.company.payment.payment.dto.PaymentRequest;
import com.company.payment.payment.dto.PaymentResponse;
import com.company.payment.payment.dto.PaymentStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.RecordComponent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * The DTOs are hand-written, the YAML documents them: this test keeps the two the same.
 *
 *   - every schema in payment-api.yaml has a DTO (same list as schemaMappings in pom.xml)
 *   - same field names (records) / same values (enums)
 *   - request DTOs: a field is @NotNull/@NotBlank exactly when the YAML lists it as required
 *
 * Adding a field to a DTO without adding it to the YAML (or the other way round) fails the build.
 */
class ContractTest {

    private static final String SPEC = "/static/openapi/payment-api.yaml";

    /** Schema name -> DTO. Keep in sync with <schemaMappings> in pom.xml. */
    private static final Map<String, Class<?>> DTOS = new LinkedHashMap<>();

    static {
        DTOS.put("PaymentRequest", PaymentRequest.class);
        DTOS.put("CardType", CardType.class);
        DTOS.put("CardInfo", CardInfo.class);
        DTOS.put("BillingInfo", BillingInfo.class);
        DTOS.put("DeviceInfo", DeviceInfo.class);
        DTOS.put("PaymentResponse", PaymentResponse.class);
        DTOS.put("PaymentStatus", PaymentStatus.class);
        DTOS.put("Amount", Amount.class);
        DTOS.put("ErrorResponse", ErrorResponse.class);
        DTOS.put("ErrorDetail", ErrorDetail.class);
    }

    /** DTOs we receive: their Bean Validation must match the YAML "required" list. */
    private static final Set<Class<?>> REQUEST_DTOS =
            Set.of(PaymentRequest.class, CardInfo.class, Amount.class, BillingInfo.class, DeviceInfo.class);

    @Test
    void everySchemaHasADto() {
        assertThat(schemas().keySet()).containsExactlyInAnyOrderElementsOf(DTOS.keySet());
    }

    @Test
    void dtosMatchTheSchemas() throws Exception {
        Map<String, Map<String, Object>> schemas = schemas();
        List<String> problems = new ArrayList<>();

        for (Map.Entry<String, Class<?>> entry : DTOS.entrySet()) {
            String name = entry.getKey();
            Class<?> dto = entry.getValue();
            Map<String, Object> schema = schemas.get(name);
            if (schema == null) {
                continue;   // reported by everySchemaHasADto
            }

            if (dto.isEnum()) {
                Set<String> yaml = new TreeSet<>(stringList(schema.get("enum")));
                Set<String> java = Arrays.stream(dto.getEnumConstants()).map(c -> ((Enum<?>) c).name())
                        .collect(Collectors.toCollection(TreeSet::new));
                compare(problems, name + " values", yaml, java);
                continue;
            }

            @SuppressWarnings("unchecked")
            Map<String, Object> properties = (Map<String, Object>) schema.getOrDefault("properties", Map.of());
            Set<String> yamlFields = new TreeSet<>(properties.keySet());
            Set<String> javaFields = Arrays.stream(dto.getRecordComponents()).map(RecordComponent::getName)
                    .collect(Collectors.toCollection(TreeSet::new));
            compare(problems, name + " fields", yamlFields, javaFields);

            if (REQUEST_DTOS.contains(dto)) {
                Set<String> yamlRequired = new TreeSet<>(stringList(schema.get("required")));
                Set<String> javaRequired = new TreeSet<>();
                for (RecordComponent component : dto.getRecordComponents()) {
                    Field field = dto.getDeclaredField(component.getName());
                    if (field.isAnnotationPresent(NotNull.class) || field.isAnnotationPresent(NotBlank.class)) {
                        javaRequired.add(component.getName());
                    }
                }
                compare(problems, name + " required", yamlRequired, javaRequired);
            }
        }

        assertThat(problems).as("payment-api.yaml and the DTOs differ").isEmpty();
    }

    private static void compare(List<String> problems, String what, Set<String> yaml, Set<String> java) {
        if (!yaml.equals(java)) {
            Set<String> onlyYaml = new TreeSet<>(yaml);
            onlyYaml.removeAll(java);
            Set<String> onlyJava = new TreeSet<>(java);
            onlyJava.removeAll(yaml);
            problems.add(what + ": only in YAML " + onlyYaml + ", only in Java " + onlyJava);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Map<String, Object>> schemas() {
        try (InputStream in = ContractTest.class.getResourceAsStream(SPEC)) {
            Map<String, Object> spec = new Yaml().load(in);
            Map<String, Object> components = (Map<String, Object>) spec.get("components");
            return (Map<String, Map<String, Object>>) components.get("schemas");
        } catch (Exception ex) {
            throw new IllegalStateException("Cannot read " + SPEC, ex);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<String> stringList(Object value) {
        return value == null ? List.of() : ((List<Object>) value).stream().map(String::valueOf).toList();
    }
}
