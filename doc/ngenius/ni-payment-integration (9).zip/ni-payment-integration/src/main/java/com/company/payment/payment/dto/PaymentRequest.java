package com.company.payment.payment.dto;

import com.company.payment.common.dto.Amount;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * POST /api/v1/payments request. Documented in payment-api.yaml (schema PaymentRequest);
 * ContractTest fails the build if the two drift apart.
 */
public record PaymentRequest(
        @NotBlank @Size(max = 64) String merchantOrderId,
        @NotNull CardType cardType,
        @NotNull @Valid CardInfo card,
        @NotNull @Valid Amount amount,
        @NotNull @Valid BillingInfo billingInfo,
        @NotNull @Valid DeviceInfo deviceInfo) {
}
