package com.company.payment.payment.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record BillingInfo(
        @NotBlank @Size(max = 60) String firstName,
        @NotBlank @Size(max = 60) String lastName,
        @NotBlank @Email @Size(max = 254) String email,
        @Size(max = 200) String address,
        @Size(max = 60) String city,
        @Pattern(regexp = "^[A-Z]{2}$") String countryCode) {
}
