package com.company.payment.common.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.math.BigDecimal;

/**
 * Money in MAJOR units (AED 250.00). Shared by every feature (payment, capture, refund...).
 * Max decimals = the currency's decimals (AED 2, KWD 3), checked by Amounts.normalize.
 */
public record Amount(
        @NotNull @DecimalMin("0.001") BigDecimal value,
        @NotNull @Pattern(regexp = "^[A-Z]{3}$") String currency) {
}
