package com.company.payment.payment.dto;

/**
 * Status shown to clients, and the next call they make:
 *   AUTHORISED          -> capture
 *   CHALLENGE_REQUIRED  -> 3DS API
 *   PENDING             -> status API, or retry with the same Idempotency-Key
 *   DECLINED / FAILED   -> stop
 */
public enum PaymentStatus {
    AUTHORISED,
    CHALLENGE_REQUIRED,
    PENDING,
    DECLINED,
    FAILED
}
