package com.company.payment.payment.dto;

import com.company.payment.common.dto.Amount;

import java.time.OffsetDateTime;

/** The client decides the next call from status (see PaymentStatus). Null fields are not sent. */
public record PaymentResponse(
        String paymentId,
        String merchantOrderId,
        PaymentStatus status,
        Amount amount,
        String orderReference,
        String failureReason,
        OffsetDateTime createdAt) {
}
