package com.company.payment.common.exception;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Body of every non-200 response. errors is only present for VALIDATION_ERROR.
 * (Not to be confused with Spring's interface org.springframework.web.ErrorResponse.)
 */
public record ErrorResponse(
        String code,
        String message,
        String correlationId,
        String traceId,
        OffsetDateTime timestamp,
        List<ErrorDetail> errors) {
}
