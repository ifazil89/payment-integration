package com.company.payment.payment.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * One card object for both card types; cardType decides which of pan / token is required
 * (checked by PaymentRequestValidator).
 */
public record CardInfo(
        @Pattern(regexp = "^\\d{12,19}$") String pan,
        @Size(min = 1, max = 512) String token,
        @NotBlank @Pattern(regexp = "^\\d{4}-(0[1-9]|1[0-2])$") String expiry,
        @NotBlank @Pattern(regexp = "^\\d{3,4}$") String cvv,
        @NotBlank @Size(max = 100) String cardholderName) {

    /** Never print card data (a record's default toString would). */
    @Override
    public String toString() {
        return "CardInfo[pan=" + (pan == null ? null : "***" + last4(pan)) + ", token=" + (token == null ? null : "***")
                + ", expiry=" + expiry + ", cvv=***, cardholderName=" + cardholderName + "]";
    }

    private static String last4(String value) {
        return value.length() <= 4 ? value : value.substring(value.length() - 4);
    }
}
