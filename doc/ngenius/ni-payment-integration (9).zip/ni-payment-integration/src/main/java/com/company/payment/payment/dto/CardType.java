package com.company.payment.payment.dto;

/**
 * CARD          = new card: card.pan required, card.token empty
 * CARD_ON_FILE  = saved N-Genius card token: card.token required, card.pan empty
 */
public enum CardType {
    CARD,
    CARD_ON_FILE
}
