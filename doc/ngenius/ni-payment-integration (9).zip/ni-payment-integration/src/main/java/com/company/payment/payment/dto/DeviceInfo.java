package com.company.payment.payment.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Shopper's browser data, used for EMV 3DS 2.x when N-Genius asks for 3DS. */
public record DeviceInfo(
        @NotBlank @Size(max = 45) String ip,
        @NotBlank @Size(max = 2048) String userAgent,
        @NotBlank @Size(max = 2048) String acceptHeader,
        @NotBlank @Size(max = 8) String language,
        @Pattern(regexp = "^-?\\d{1,4}$") String timeZoneOffset,
        @Pattern(regexp = "^\\d{1,6}$") String screenWidth,
        @Pattern(regexp = "^\\d{1,6}$") String screenHeight,
        @Pattern(regexp = "^\\d{1,2}$") String colorDepth,
        Boolean javascriptEnabled,
        Boolean javaEnabled,
        /** 01=250x400, 02=390x400, 03=500x600, 04=600x400, 05=full screen (default) */
        @Pattern(regexp = "^0[1-5]$") String challengeWindowSize) {
}
