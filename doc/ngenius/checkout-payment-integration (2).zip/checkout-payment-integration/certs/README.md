# certs/ (local development only)

The app reads the Apple Pay files from a folder **outside the jar** (`wallet.apple-pay.certificate-dir`).
Locally that is `certs/apple-pay` in this project folder (see `application-local.yml`).
In QA/prod it is `/opt/checkout/certs/apple-pay` (or `APPLE_PAY_CERT_DIR`), mounted from a secret.

```
certs/apple-pay/
├── apple-pay.p12          Payment Processing Certificate + its EC private key   (secret, git-ignored)
└── AppleRootCA-G3.cer     Apple Root CA - G3 from https://www.apple.com/certificateauthority/  (public)
```

- The `.p12` password comes from `APPLE_PAY_KEYSTORE_PASSWORD`, never from a file in this folder.
- Everything in this folder except this README is git-ignored.
- No keys yet? Start with `APPLE_PAY_ENABLED=false` (Apple Pay requests then return 422 `WALLET_NOT_ENABLED`).
