-- Oracle (qa, prod). One row per wallet payment.
-- Never stored: the decrypted card number / DPAN, the cryptogram, the encrypted wallet token.
CREATE TABLE payment (
    id                     VARCHAR2(36)              NOT NULL PRIMARY KEY,
    client_id              VARCHAR2(64)              NOT NULL,
    idempotency_key        VARCHAR2(100)             NOT NULL,
    request_hash           VARCHAR2(64)              NOT NULL,
    merchant_order_id      VARCHAR2(64)              NOT NULL,
    wallet_type            VARCHAR2(20)              NOT NULL,
    auth_method            VARCHAR2(20),
    wallet_transaction_id  VARCHAR2(128),
    card_scheme            VARCHAR2(30),
    card_last4             VARCHAR2(4),
    amount                 NUMBER(19, 3)             NOT NULL,
    currency               VARCHAR2(3)               NOT NULL,
    email                  VARCHAR2(254),
    state                  VARCHAR2(30)              NOT NULL,
    failure_reason         VARCHAR2(500),
    cko_payment_id         VARCHAR2(64),
    cko_action_id          VARCHAR2(64),
    cko_status             VARCHAR2(40),
    cko_response_code      VARCHAR2(10),
    three_ds_redirect_url  VARCHAR2(2048),
    created_at             TIMESTAMP WITH TIME ZONE  NOT NULL,
    updated_at             TIMESTAMP WITH TIME ZONE  NOT NULL,
    version                NUMBER(19)                NOT NULL,
    CONSTRAINT uk_payment_client_idem UNIQUE (client_id, idempotency_key),
    CONSTRAINT uk_payment_wallet_txn  UNIQUE (wallet_transaction_id)
);

CREATE INDEX ix_payment_cko_id ON payment (cko_payment_id);
CREATE INDEX ix_payment_merchant_order ON payment (merchant_order_id);
