-- H2 (local development). Same table as db/migration/oracle, in H2 types. One row per wallet payment.
-- Never stored: the decrypted card number / DPAN, the cryptogram, the encrypted wallet token.
CREATE TABLE payment (
    id                     VARCHAR(36)              NOT NULL PRIMARY KEY,
    client_id              VARCHAR(64)              NOT NULL,
    idempotency_key        VARCHAR(100)             NOT NULL,
    request_hash           VARCHAR(64)              NOT NULL,
    merchant_order_id      VARCHAR(64)              NOT NULL,
    wallet_type            VARCHAR(20)              NOT NULL,
    auth_method            VARCHAR(20),
    wallet_transaction_id  VARCHAR(128),
    card_scheme            VARCHAR(30),
    card_last4             VARCHAR(4),
    amount                 NUMERIC(19, 3)             NOT NULL,
    currency               VARCHAR(3)               NOT NULL,
    email                  VARCHAR(254),
    state                  VARCHAR(30)              NOT NULL,
    failure_reason         VARCHAR(500),
    cko_payment_id         VARCHAR(64),
    cko_action_id          VARCHAR(64),
    cko_status             VARCHAR(40),
    cko_response_code      VARCHAR(10),
    three_ds_redirect_url  VARCHAR(2048),
    created_at             TIMESTAMP WITH TIME ZONE  NOT NULL,
    updated_at             TIMESTAMP WITH TIME ZONE  NOT NULL,
    version                BIGINT                   NOT NULL,
    CONSTRAINT uk_payment_client_idem UNIQUE (client_id, idempotency_key),
    CONSTRAINT uk_payment_wallet_txn  UNIQUE (wallet_transaction_id)
);

CREATE INDEX ix_payment_cko_id ON payment (cko_payment_id);
CREATE INDEX ix_payment_merchant_order ON payment (merchant_order_id);
