-- Oracle (qa, prod). Payments are no longer wallet-only: CARD, NETWORK_TOKEN, APPLE_PAY, GOOGLE_PAY.
-- Existing rows keep their value (APPLE_PAY / GOOGLE_PAY are valid payment methods).
ALTER TABLE payment RENAME COLUMN wallet_type TO payment_method;
