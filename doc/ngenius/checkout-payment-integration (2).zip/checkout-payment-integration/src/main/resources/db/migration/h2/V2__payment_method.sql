-- H2 (local development). Payments are no longer wallet-only: CARD, NETWORK_TOKEN, APPLE_PAY, GOOGLE_PAY.
-- Existing rows keep their value (APPLE_PAY / GOOGLE_PAY are valid payment methods).
ALTER TABLE payment ALTER COLUMN wallet_type RENAME TO payment_method;
