package com.company.checkout.payment.entity;

import com.company.checkout.payment.dto.PaymentMethodType;
import com.company.wallet.api.AuthMethod;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * A payment (card, network token, Apple Pay, Google Pay). Never stored here: card number, network token,
 * DPAN, cvv, cryptogram, wallet token. Only last 4 digits, scheme, payment method, and for wallets the
 * wallet's transaction id (to reject a token used twice).
 *
 * Fields copied from the request have setters (PaymentMapper). Everything that changes during the flow
 * goes through the methods at the bottom.
 */
@Entity
@Table(name = "payment")
@Getter
@NoArgsConstructor   // for JPA and MapStruct
public class Payment {

    @Id
    private String id;
    @Column(name = "client_id", nullable = false)
    private String clientId;
    @Column(name = "idempotency_key", nullable = false)
    private String idempotencyKey;
    /** Fingerprint of the request: the same Idempotency-Key with a different request is rejected. */
    @Column(name = "request_hash", nullable = false)
    private String requestHash;

    @Column(name = "merchant_order_id", nullable = false)
    @Setter
    private String merchantOrderId;
    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "payment_method", nullable = false)
    @Setter
    private PaymentMethodType paymentMethod;
    @Column(nullable = false, precision = 19, scale = 3)
    @Setter
    private BigDecimal amount;
    @Column(nullable = false, length = 3)
    @Setter
    private String currency;
    @Column
    @Setter
    private String email;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "auth_method")
    private AuthMethod authMethod;
    /** Wallets only: Apple Pay header.transactionId / Google Pay messageId; unique, so one token pays once. */
    @Column(name = "wallet_transaction_id")
    private String walletTransactionId;
    @Column(name = "card_scheme")
    private String cardScheme;
    @Column(name = "card_last4")
    private String cardLast4;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(nullable = false)
    private PaymentState state;
    @Column(name = "failure_reason")
    private String failureReason;

    @Column(name = "cko_payment_id")
    private String ckoPaymentId;
    @Column(name = "cko_action_id")
    private String ckoActionId;
    /** Last status reported by Checkout.com (raw), for support. */
    @Column(name = "cko_status")
    private String ckoStatus;
    @Column(name = "cko_response_code")
    private String ckoResponseCode;
    @Column(name = "three_ds_redirect_url")
    private String threeDsRedirectUrl;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
    @Version
    private Long version;

    // ------------------------------------------------------------------ flow

    /** Before the first save, right after the payment method was checked (and a wallet token decrypted). */
    public void start(String clientId, String idempotencyKey, String requestHash,
                      String walletTransactionId, AuthMethod authMethod, String cardLast4) {
        this.id = UUID.randomUUID().toString();
        this.clientId = clientId;
        this.idempotencyKey = idempotencyKey;
        this.requestHash = requestHash;
        this.walletTransactionId = walletTransactionId;
        this.authMethod = authMethod;
        this.cardLast4 = cardLast4;
        this.state = PaymentState.CREATED;
        this.createdAt = Instant.now();
        this.updatedAt = this.createdAt;
    }

    /**
     * Applies a Checkout.com answer (POST or GET). Values Checkout.com left out keep what we had
     * (GET /payments/{id} has no response code, for example). An unknown status keeps our state.
     */
    public void applyProviderResult(ProviderResult result) {
        this.ckoPaymentId = keep(result.providerPaymentId(), ckoPaymentId);
        this.ckoActionId = keep(result.actionId(), ckoActionId);
        this.ckoStatus = keep(result.status(), ckoStatus);
        this.ckoResponseCode = keep(result.responseCode(), ckoResponseCode);
        this.cardScheme = keep(result.cardScheme(), cardScheme);
        this.cardLast4 = keep(result.cardLast4(), cardLast4);
        this.threeDsRedirectUrl = keep(result.redirectUrl(), threeDsRedirectUrl);

        PaymentState mapped = PaymentState.fromCko(result.status(), result.redirectUrl() != null
                || (state == PaymentState.CHALLENGE_REQUIRED && threeDsRedirectUrl != null));
        if (mapped != null) {
            this.state = mapped;
        }
        if (state == PaymentState.DECLINED) {
            this.failureReason = result.responseSummary() != null
                    ? result.responseSummary() + (result.responseCode() == null ? "" : " (" + result.responseCode() + ")")
                    : keep(failureReason, "Declined");
        }
        touch();
    }

    public void fail(String reason) {
        this.state = PaymentState.FAILED;
        this.failureReason = reason;
        touch();
    }

    private static String keep(String newValue, String oldValue) {
        return newValue != null ? newValue : oldValue;
    }

    private void touch() {
        this.updatedAt = Instant.now();
    }
}
