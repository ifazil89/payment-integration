package com.company.wallet.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The encrypted Apple Pay token: {@code PKPaymentToken.paymentData} from the device.
 *
 * @param version   "EC_v1" (supported) or "RSA_v1" (China only, not supported)
 * @param data      base64 ciphertext
 * @param signature base64 detached PKCS#7 signature
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ApplePayToken(String version, String data, String signature, Header header) {

    /**
     * @param ephemeralPublicKey base64 X.509 SubjectPublicKeyInfo
     * @param publicKeyHash      base64 SHA-256 of the merchant certificate's public key: which key to decrypt with
     * @param transactionId      hex, unique per token
     * @param applicationData    hex SHA-256 of the app's applicationData, if the app set one
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Header(String ephemeralPublicKey, String publicKeyHash, String transactionId, String applicationData) {
    }

    @Override
    public String toString() {
        return "ApplePayToken[version=" + version + ", data=***, signature=***, transactionId="
                + (header == null ? null : header.transactionId()) + "]";
    }
}
