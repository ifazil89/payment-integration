package com.company.checkout.payment.dto;

/**
 * Status shown to clients, and what they do next:
 *   APPROVED            authorised; Checkout.com captures it automatically (soon CAPTURED). Done.
 *   CAPTURED            money taken. Done.
 *   CHALLENGE_REQUIRED  Google Pay PAN_ONLY: send the shopper to threeDsRedirectUrl, then GET the payment
 *   PENDING             outcome not known yet: GET the payment
 *   DECLINED / FAILED   stop (a new attempt needs a new wallet token)
 *   CANCELLED / REFUNDED  changed later in Checkout.com (void / refund)
 */
public enum PaymentStatus {
    APPROVED,
    CAPTURED,
    CHALLENGE_REQUIRED,
    PENDING,
    DECLINED,
    FAILED,
    CANCELLED,
    REFUNDED
}
