package com.company.checkout.cko.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record CkoCustomer(String email, String name) {
}
