package com.company.checkout.common.openapi.schema;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.List;

/** DOCUMENTATION ONLY for common.exception.ErrorResponse (never instantiated). */
@Schema(name = "ErrorResponse",
        description = "Body of every non-200 response. `errors` is present only for VALIDATION_ERROR.")
public record ErrorResponseSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "VALIDATION_ERROR", description = """
                VALIDATION_ERROR, MALFORMED_REQUEST, MISSING_HEADER, UNAUTHORIZED, IDEMPOTENCY_KEY_REUSED,
                REQUEST_IN_PROGRESS, INVALID_AMOUNT, GATEWAY_REJECTED, GATEWAY_ERROR, GATEWAY_TIMEOUT,
                REQUEST_ERROR, INTERNAL_ERROR""")
        String code,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "Request validation failed")
        String message,

        @Schema(description = "X-Correlation-Id of the request (sent by you or generated). Quote it when reporting a problem.",
                example = "demo-1")
        String correlationId,

        @Schema(description = "Distributed trace id (also in the X-Trace-Id response header)",
                example = "4bf92f3577b34da6a3ce929d0e0e4736")
        String traceId,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "2026-10-24T07:00:01.412Z")
        OffsetDateTime timestamp,

        @ArraySchema(arraySchema = @Schema(description = "One entry per invalid field (VALIDATION_ERROR only)"))
        List<ErrorDetailSchema> errors) {
}
