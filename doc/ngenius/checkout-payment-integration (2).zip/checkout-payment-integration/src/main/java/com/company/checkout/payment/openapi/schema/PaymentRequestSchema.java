package com.company.checkout.payment.openapi.schema;

import com.company.checkout.common.openapi.schema.AmountSchema;
import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for payment.dto.PaymentRequest (never instantiated). */
@Schema(name = "PaymentRequest")
public record PaymentRequestSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, minLength = 1, maxLength = 64, example = "SO-1001",
                description = "Your order id (sent to Checkout.com as reference)")
        String merchantOrderId,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        PaymentMethodSchema paymentMethod,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED,
                description = "Apple Pay: must equal the amount the shopper approved in the wallet sheet")
        AmountSchema amount,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        BillingInfoSchema billingInfo) {
}
