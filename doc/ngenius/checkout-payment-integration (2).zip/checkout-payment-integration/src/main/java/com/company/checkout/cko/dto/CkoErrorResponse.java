package com.company.checkout.cko.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/** Checkout.com error body, e.g. {"request_id":"...","error_type":"request_invalid","error_codes":["token_invalid"]}. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record CkoErrorResponse(
        @JsonProperty("request_id") String requestId,
        @JsonProperty("error_type") String errorType,
        @JsonProperty("error_codes") List<String> errorCodes) {
}
