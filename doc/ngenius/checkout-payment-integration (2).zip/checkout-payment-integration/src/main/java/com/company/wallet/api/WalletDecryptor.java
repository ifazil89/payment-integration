package com.company.wallet.api;

import com.company.wallet.applepay.ApplePayDecryptor;
import com.company.wallet.googlepay.GooglePayDecryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Supplier;

/**
 * The one entry point: verify + decrypt a wallet token. Built once at startup (with Spring:
 * WalletAutoConfiguration; without: {@code new WalletDecryptor(applePay, googlePay)}).
 * A wallet that is switched off has no decryptor (null) and answers {@link WalletDecryptionException#NOT_ENABLED}.
 *
 * Thread-safe. Logs only safe facts: wallet, auth method, last 4 digits, transaction id, duration.
 */
public class WalletDecryptor {

    private static final Logger log = LoggerFactory.getLogger(WalletDecryptor.class);

    private final ApplePayDecryptor applePay;
    private final GooglePayDecryptor googlePay;

    /** @param applePay / googlePay null = that wallet is switched off */
    public WalletDecryptor(ApplePayDecryptor applePay, GooglePayDecryptor googlePay) {
        this.applePay = applePay;
        this.googlePay = googlePay;
    }

    public boolean isEnabled(WalletType walletType) {
        return switch (walletType) {
            case APPLE_PAY -> applePay != null;
            case GOOGLE_PAY -> googlePay != null;
        };
    }

    /** Apple Pay token as an object (PKPaymentToken.paymentData). */
    public DecryptedWalletCard decryptApplePay(ApplePayToken token) {
        return timed(WalletType.APPLE_PAY, () -> require(applePay, WalletType.APPLE_PAY).decrypt(token));
    }

    /** Apple Pay token as the JSON of PKPaymentToken.paymentData, or that JSON base64-encoded. */
    public DecryptedWalletCard decryptApplePay(String token) {
        return timed(WalletType.APPLE_PAY, () -> require(applePay, WalletType.APPLE_PAY).decrypt(token));
    }

    /** Google Pay token as an object (tokenizationData.token parsed). */
    public DecryptedWalletCard decryptGooglePay(GooglePayToken token) {
        return timed(WalletType.GOOGLE_PAY, () -> require(googlePay, WalletType.GOOGLE_PAY).decrypt(token));
    }

    /** Google Pay token as the string tokenizationData.token. */
    public DecryptedWalletCard decryptGooglePay(String token) {
        return timed(WalletType.GOOGLE_PAY, () -> require(googlePay, WalletType.GOOGLE_PAY).decrypt(token));
    }

    private static DecryptedWalletCard timed(WalletType walletType, Supplier<DecryptedWalletCard> decryption) {
        long start = System.nanoTime();
        DecryptedWalletCard card = decryption.get();
        log.atInfo()
                .setMessage("Wallet token decrypted: {} {} card ****{} ({} ms)")
                .addArgument(walletType).addArgument(card.authMethod()).addArgument(card.last4())
                .addArgument((System.nanoTime() - start) / 1_000_000)
                .addKeyValue("wallet.type", walletType.name())
                .addKeyValue("wallet.auth_method", card.authMethod().name())
                .addKeyValue("wallet.transaction_id", card.walletTransactionId())
                .log();
        return card;
    }

    private static <T> T require(T decryptor, WalletType walletType) {
        if (decryptor == null) {
            throw WalletDecryptionException.notEnabled(walletType);
        }
        return decryptor;
    }
}
