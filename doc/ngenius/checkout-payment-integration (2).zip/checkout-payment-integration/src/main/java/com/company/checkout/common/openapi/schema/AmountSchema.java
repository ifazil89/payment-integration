package com.company.checkout.common.openapi.schema;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

/** DOCUMENTATION ONLY for common.dto.Amount (never instantiated). */
@Schema(name = "Amount",
        description = "MAJOR units (AED 250.00). Max decimals = the currency's decimals (AED 2, KWD 3).")
public record AmountSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, minimum = "0.001", example = "250.00")
        BigDecimal value,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, pattern = "^[A-Z]{3}$",
                description = "ISO 4217", example = "AED")
        String currency) {
}
