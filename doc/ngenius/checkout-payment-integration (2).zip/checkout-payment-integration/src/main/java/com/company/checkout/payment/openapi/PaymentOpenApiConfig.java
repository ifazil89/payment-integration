package com.company.checkout.payment.openapi;

import com.company.checkout.payment.dto.ApplePayWalletToken;
import com.company.checkout.payment.dto.BillingInfo;
import com.company.checkout.payment.dto.GooglePayWalletToken;
import com.company.checkout.payment.dto.CardDetails;
import com.company.checkout.payment.dto.NetworkTokenDetails;
import com.company.checkout.payment.dto.PaymentMethod;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.dto.PaymentResponse;
import com.company.checkout.payment.openapi.schema.ApplePayWalletTokenSchema;
import com.company.checkout.payment.openapi.schema.BillingInfoSchema;
import com.company.checkout.payment.openapi.schema.GooglePayWalletTokenSchema;
import com.company.checkout.payment.openapi.schema.CardDetailsSchema;
import com.company.checkout.payment.openapi.schema.NetworkTokenDetailsSchema;
import com.company.checkout.payment.openapi.schema.PaymentMethodSchema;
import com.company.checkout.payment.openapi.schema.PaymentRequestSchema;
import com.company.checkout.payment.openapi.schema.PaymentResponseSchema;
import org.springdoc.core.utils.SpringDocUtils;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * Payment DTO -> its documentation class: springdoc documents the right-hand class wherever the
 * left-hand one appears. New DTO = new Schema class + one line here (DocSchemaTest checks both).
 */
@Configuration
public class PaymentOpenApiConfig {

    public static final Map<Class<?>, Class<?>> DOC_SCHEMAS = Map.ofEntries(
            Map.entry(PaymentRequest.class, PaymentRequestSchema.class),
            Map.entry(PaymentMethod.class, PaymentMethodSchema.class),
            Map.entry(CardDetails.class, CardDetailsSchema.class),
            Map.entry(NetworkTokenDetails.class, NetworkTokenDetailsSchema.class),
            Map.entry(ApplePayWalletToken.class, ApplePayWalletTokenSchema.class),
            Map.entry(ApplePayWalletToken.Header.class, ApplePayWalletTokenSchema.HeaderSchema.class),
            Map.entry(GooglePayWalletToken.class, GooglePayWalletTokenSchema.class),
            Map.entry(GooglePayWalletToken.IntermediateSigningKey.class, GooglePayWalletTokenSchema.IntermediateSigningKeySchema.class),
            Map.entry(BillingInfo.class, BillingInfoSchema.class),
            Map.entry(PaymentResponse.class, PaymentResponseSchema.class));

    static {
        DOC_SCHEMAS.forEach((dto, schema) -> SpringDocUtils.getConfig().replaceWithClass(dto, schema));
    }
}
