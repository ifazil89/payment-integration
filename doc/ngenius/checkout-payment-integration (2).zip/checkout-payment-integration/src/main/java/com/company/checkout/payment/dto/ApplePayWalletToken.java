package com.company.checkout.payment.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Apple Pay PKPaymentToken.paymentData, sent as a JSON object, unchanged from the device. Encrypted;
 * decrypted by this service. Never stored; masked in logs (paymentMethod.walletToken -> "***").
 *
 * @param version   "EC_v1" (RSA_v1 is not supported)
 * @param data      base64 ciphertext
 * @param signature base64 detached PKCS#7 signature
 */
public record ApplePayWalletToken(
        @NotBlank @Size(max = 10) String version,
        @NotBlank @Size(max = 16000) String data,
        @NotBlank @Size(max = 16000) String signature,
        @NotNull @Valid Header header) {

    /**
     * @param ephemeralPublicKey base64 X.509 SubjectPublicKeyInfo
     * @param publicKeyHash      base64 SHA-256 of our Payment Processing Certificate's public key
     * @param transactionId      hex, unique per token
     * @param applicationData    hex SHA-256 of the app's applicationData, if the app set one
     */
    public record Header(
            @NotBlank @Size(max = 500) String ephemeralPublicKey,
            @NotBlank @Size(max = 100) String publicKeyHash,
            @NotBlank @Size(max = 128) String transactionId,
            @Size(max = 128) String applicationData) {
    }

    @Override
    public String toString() {
        return "ApplePayWalletToken[version=" + version + ", data=***, signature=***, transactionId="
                + (header == null ? null : header.transactionId()) + "]";
    }
}
