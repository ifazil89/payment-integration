package com.company.checkout.common.openapi.schema;

import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for common.exception.ErrorDetail (never instantiated). */
@Schema(name = "ErrorDetail", description = "One invalid field")
public record ErrorDetailSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "card.pan")
        String field,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, example = "is required for cardType CARD")
        String message) {
}
