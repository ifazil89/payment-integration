package com.company.wallet.api;

/** The wallet the shopper paid with. */
public enum WalletType {
    APPLE_PAY,
    GOOGLE_PAY
}
