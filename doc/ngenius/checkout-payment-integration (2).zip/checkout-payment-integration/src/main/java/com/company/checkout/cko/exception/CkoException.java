package com.company.checkout.cko.exception;

import com.company.checkout.cko.dto.CkoErrorResponse;
import lombok.Getter;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import tools.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Checkout.com answered 4xx/5xx: the outcome is KNOWN (the call was refused).
 * A timeout is different: Spring throws ResourceAccessException and the outcome is UNKNOWN.
 *
 *   422 request_invalid / ...  -> the payment is FAILED (error codes say why)
 *   401 / 403 / 404            -> our key, channel or URL is wrong: a configuration problem (502 + alert)
 *   429                        -> rate limited (503, retry later)
 *   5xx                        -> Checkout.com problem (502), outcome of a payment request unknown
 */
@Getter
public class CkoException extends RuntimeException {

    private static final int MAX_BODY = 1000;

    private final int status;
    private final String requestId;
    private final String errorType;
    private final List<String> errorCodes;
    private final String responseBody;

    public CkoException(int status, String path, String requestId, String errorType, List<String> errorCodes,
                        String responseBody) {
        super("Checkout.com returned HTTP " + status + " for " + path
                + (errorType == null ? "" : " (" + errorType + " " + errorCodes + ")"));
        this.status = status;
        this.requestId = requestId;
        this.errorType = errorType;
        this.errorCodes = errorCodes == null ? List.of() : List.copyOf(errorCodes);
        this.responseBody = responseBody;
    }

    public static CkoException from(HttpRequest request, ClientHttpResponse response, ObjectMapper objectMapper)
            throws IOException {
        String body = new String(response.getBody().readAllBytes(), StandardCharsets.UTF_8);
        CkoErrorResponse error = null;
        try {
            error = body.isBlank() ? null : objectMapper.readValue(body, CkoErrorResponse.class);
        } catch (RuntimeException ignored) {
            // not JSON (e.g. a proxy error page): keep the raw body
        }
        String requestId = error != null && error.requestId() != null
                ? error.requestId() : response.getHeaders().getFirst("Cko-Request-Id");
        return new CkoException(response.getStatusCode().value(), request.getURI().getPath(), requestId,
                error == null ? null : error.errorType(), error == null ? null : error.errorCodes(),
                body.length() > MAX_BODY ? body.substring(0, MAX_BODY) + "..." : body);
    }

    /** 422: Checkout.com refused the payment request itself; the payment is FAILED. */
    public boolean isUnprocessable() {
        return status == 422;
    }
}
