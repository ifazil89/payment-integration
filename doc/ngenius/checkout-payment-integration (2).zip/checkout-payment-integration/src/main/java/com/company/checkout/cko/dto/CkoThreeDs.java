package com.company.checkout.cko.dto;

/** "3ds": {"enabled": true} asks Checkout.com to run 3D Secure (used for Google Pay PAN_ONLY). */
public record CkoThreeDs(boolean enabled) {
}
