package com.company.wallet.googlepay;

import com.company.wallet.api.AuthMethod;
import com.company.wallet.api.DecryptedWalletCard;
import com.company.wallet.api.GooglePayToken;
import com.company.wallet.api.WalletDecryptionException;
import com.company.wallet.api.WalletType;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;

import java.security.GeneralSecurityException;
import java.time.Clock;

/**
 * Google Pay ECv2 (DIRECT tokenization): Tink verifies Google's signature chain and decrypts
 * ({@link Unsealer}); this class checks expiry and turns the message into a card.
 *
 * The token is {@code paymentMethodData.tokenizationData.token} from the Google Pay response: as the string
 * Google returns, or parsed into a {@link GooglePayToken}. Built once by WalletAutoConfiguration; thread-safe.
 */
public class GooglePayDecryptor {

    /** Verify + decrypt a sealed Google Pay message. In production: Tink's PaymentMethodTokenRecipient::unseal. */
    @FunctionalInterface
    public interface Unsealer {
        String unseal(String sealedMessage) throws GeneralSecurityException;
    }

    private final Unsealer unsealer;
    private final ObjectMapper objectMapper;
    private final Clock clock;

    public GooglePayDecryptor(Unsealer unsealer, ObjectMapper objectMapper, Clock clock) {
        this.unsealer = unsealer;
        this.objectMapper = objectMapper;
        this.clock = clock;
    }

    /** Token as an object: written back to Google's JSON (signedMessage / signedKey stay the same strings). */
    public DecryptedWalletCard decrypt(GooglePayToken token) {
        if (token == null) {
            throw WalletDecryptionException.invalid("Google Pay token is missing");
        }
        String sealed;
        try {
            sealed = objectMapper.writeValueAsString(token);
        } catch (JacksonException e) {
            throw WalletDecryptionException.invalid("Google Pay token could not be serialized", e);
        }
        return decrypt(sealed);
    }

    /** Token as the string tokenizationData.token, unchanged. */
    public DecryptedWalletCard decrypt(String walletToken) {
        if (walletToken == null || walletToken.isBlank()) {
            throw WalletDecryptionException.invalid("Google Pay token is missing");
        }
        String json;
        try {
            json = unsealer.unseal(walletToken);
        } catch (GeneralSecurityException | RuntimeException e) {
            throw WalletDecryptionException.invalid("Google Pay verification/decryption failed: " + e.getMessage(), e);
        }

        GooglePayDecryptedData message;
        try {
            message = objectMapper.readValue(json, GooglePayDecryptedData.class);
        } catch (JacksonException e) {
            throw WalletDecryptionException.invalid("decrypted Google Pay message is not valid JSON");
        }
        return toCard(message, clock.millis());
    }

    static DecryptedWalletCard toCard(GooglePayDecryptedData message, long nowMillis) {
        if (!"CARD".equals(message.paymentMethod())) {
            throw WalletDecryptionException.unsupported("Google Pay paymentMethod " + message.paymentMethod());
        }
        if (message.messageExpiration() == null || nowMillis > Long.parseLong(message.messageExpiration())) {
            throw WalletDecryptionException.expired("Google Pay message expired at " + message.messageExpiration());
        }
        GooglePayDecryptedData.PaymentMethodDetails details = message.paymentMethodDetails();
        if (details == null || details.pan() == null || details.expirationMonth() == null
                || details.expirationYear() == null) {
            throw WalletDecryptionException.invalid("decrypted Google Pay card details are incomplete");
        }

        AuthMethod authMethod;
        if ("CRYPTOGRAM_3DS".equals(details.authMethod())) {
            if (details.cryptogram() == null || details.cryptogram().isBlank()) {
                throw WalletDecryptionException.invalid("Google Pay CRYPTOGRAM_3DS token without cryptogram");
            }
            authMethod = AuthMethod.CRYPTOGRAM_3DS;
        } else if ("PAN_ONLY".equals(details.authMethod())) {
            authMethod = AuthMethod.PAN_ONLY;
        } else {
            throw WalletDecryptionException.unsupported("Google Pay authMethod " + details.authMethod());
        }

        return new DecryptedWalletCard(
                WalletType.GOOGLE_PAY,
                authMethod,
                details.pan(),
                details.expirationMonth(),
                details.expirationYear(),
                authMethod == AuthMethod.CRYPTOGRAM_3DS ? details.cryptogram() : null,
                details.eciIndicator(),
                message.messageId(),
                null,
                null);
    }
}
