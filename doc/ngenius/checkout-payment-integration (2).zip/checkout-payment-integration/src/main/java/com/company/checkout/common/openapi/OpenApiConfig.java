package com.company.checkout.common.openapi;

import com.company.checkout.common.dto.Amount;
import com.company.checkout.common.exception.ErrorDetail;
import com.company.checkout.common.exception.ErrorResponse;
import com.company.checkout.common.openapi.schema.AmountSchema;
import com.company.checkout.common.openapi.schema.ErrorDetailSchema;
import com.company.checkout.common.openapi.schema.ErrorResponseSchema;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.utils.SpringDocUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * OpenAPI documentation, built from code by springdoc: /v3/api-docs (JSON), /v3/api-docs.yaml, /swagger-ui.html
 *
 *   - here: title, description, API-key security (shared by every feature)
 *   - <feature>/openapi/<Feature>Api: endpoints (@Operation, @ApiResponse, examples)
 *   - [feature]/openapi/schema/...Schema: field docs. The real DTOs stay free of documentation annotations:
 *     replaceWithClass tells springdoc "when you meet Amount, document AmountSchema instead".
 */
@Configuration
public class OpenApiConfig {

    public static final String API_KEY_SCHEME = "apiKey";

    /** Shared DTO -> its documentation class (DocSchemaTest checks they match). */
    public static final Map<Class<?>, Class<?>> DOC_SCHEMAS = Map.of(
            Amount.class, AmountSchema.class,
            ErrorResponse.class, ErrorResponseSchema.class,
            ErrorDetail.class, ErrorDetailSchema.class);

    static {
        DOC_SCHEMAS.forEach((dto, schema) -> SpringDocUtils.getConfig().replaceWithClass(dto, schema));
    }

    @Bean
    OpenAPI openApi(@Value("${spring.application.name}") String name) {
        return new OpenAPI()
                .info(new Info()
                        .title("Wallet Payment API")
                        .version("1.0.0")
                        .description("""
                                Apple Pay and Google Pay payments for downstream clients, processed by Checkout.com.

                                **Decryption:** this service verifies and decrypts the wallet token itself and sends \
                                the card data to Checkout.com. Payments are **captured automatically**.

                                **Next call depends on `status`:**

                                | status | next |
                                |---|---|
                                | `APPROVED` / `CAPTURED` | done: Checkout.com captures approved payments automatically |
                                | `CHALLENGE_REQUIRED` | send the shopper to `threeDsRedirectUrl`, then `GET /api/v1/payments/{paymentId}` |
                                | `PENDING` | `GET /api/v1/payments/{paymentId}` |
                                | `DECLINED` / `FAILED` | stop, or a new attempt (new wallet token, new `Idempotency-Key`) |

                                **Tracing:** send `X-Correlation-Id` (optional). Every response returns \
                                `X-Correlation-Id` and `X-Trace-Id`; quote them when reporting a problem.

                                Service: `%s`""".formatted(name)))
                .components(new Components().addSecuritySchemes(API_KEY_SCHEME, new SecurityScheme()
                        .type(SecurityScheme.Type.APIKEY)
                        .in(SecurityScheme.In.HEADER)
                        .name("X-Api-Key")
                        .description("Per-client API key")))
                .addSecurityItem(new SecurityRequirement().addList(API_KEY_SCHEME));
    }
}
