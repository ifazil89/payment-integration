package com.company.checkout.cko.config;

import com.company.checkout.cko.exception.CkoException;
import com.company.checkout.common.logging.RestClientLoggingInterceptor;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.httpcomponents.hc5.PoolingHttpClientConnectionManagerMetricsBinder;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.core5.util.TimeValue;
import org.apache.hc.core5.util.Timeout;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClient;
import tools.jackson.databind.ObjectMapper;

/**
 * The HTTP client for every Checkout.com call:
 *  - connection pool: connect / response / pool-wait timeouts from "cko.*"
 *  - stale-connection check (2 s) + idle eviction (30 s) + 5 min TTL: no "timeouts after a few days"
 *  - NO automatic retries: a payment request is never sent twice by the HTTP layer
 *  - pool metrics httpcomponents.httpclient.pool.* (tag httpclient=cko)
 *  - built from Boot's RestClient.Builder: traceparent header, http.client.requests metric, a span per call
 *  - every request + response logged by RestClientLoggingInterceptor (card data, cryptograms, keys masked)
 *  - any 4xx/5xx becomes CkoException
 */
@Configuration
@EnableConfigurationProperties(CkoProperties.class)
public class CkoConfig {

    @Bean(destroyMethod = "close")
    CloseableHttpClient ckoHttpClient(CkoProperties properties, ObjectProvider<MeterRegistry> meterRegistry) {
        PoolingHttpClientConnectionManager pool = PoolingHttpClientConnectionManagerBuilder.create()
                .setDefaultConnectionConfig(ConnectionConfig.custom()
                        .setConnectTimeout(Timeout.of(properties.connectTimeout()))
                        .setSocketTimeout(Timeout.of(properties.responseTimeout()))
                        .setTimeToLive(TimeValue.ofMinutes(5))
                        .setValidateAfterInactivity(TimeValue.ofSeconds(2))
                        .build())
                .setMaxConnTotal(properties.maxConnections())
                .setMaxConnPerRoute(properties.maxConnections())
                .build();

        meterRegistry.ifAvailable(registry ->
                new PoolingHttpClientConnectionManagerMetricsBinder(pool, "cko").bindTo(registry));

        return HttpClients.custom()
                .setConnectionManager(pool)
                .evictIdleConnections(TimeValue.ofSeconds(30))
                .evictExpiredConnections()
                .disableAutomaticRetries()
                .setDefaultRequestConfig(RequestConfig.custom()
                        .setConnectionRequestTimeout(Timeout.of(properties.connectionRequestTimeout()))
                        .setResponseTimeout(Timeout.of(properties.responseTimeout()))
                        .build())
                .build();
    }

    @Bean
    RestClient ckoRestClient(RestClient.Builder builder, CloseableHttpClient ckoHttpClient, CkoProperties properties,
                             RestClientLoggingInterceptor loggingInterceptor, ObjectMapper objectMapper) {
        return builder.clone()
                .baseUrl(properties.baseUrl())
                .requestFactory(new HttpComponentsClientHttpRequestFactory(ckoHttpClient))
                .requestInterceptor(loggingInterceptor)
                .defaultHeaders(headers -> {
                    headers.setBearerAuth(properties.secretKey());
                    headers.setContentType(MediaType.APPLICATION_JSON);
                    headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
                })
                .defaultStatusHandler(HttpStatusCode::isError, (request, response) -> {
                    throw CkoException.from(request, response, objectMapper);
                })
                .build();
    }
}
