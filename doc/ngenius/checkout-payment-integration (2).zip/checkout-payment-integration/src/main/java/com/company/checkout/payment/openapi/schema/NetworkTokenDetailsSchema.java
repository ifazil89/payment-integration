package com.company.checkout.payment.openapi.schema;

import com.company.checkout.payment.dto.NetworkTokenType;
import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for payment.dto.NetworkTokenDetails (never instantiated). */
@Schema(name = "NetworkTokenDetails",
        description = "A network token from VTS or MDES with this payment's cryptogram. Never stored; masked in all logs.")
public record NetworkTokenDetailsSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, pattern = "^\\d{12,19}$", example = "4543474002249996",
                description = "The network token number")
        String token,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = "VTS (Visa) or MDES (Mastercard)")
        NetworkTokenType tokenType,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, minimum = "1", maximum = "12", example = "6")
        Integer expiryMonth,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, minimum = "2000", maximum = "2099", example = "2029")
        Integer expiryYear,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 100, example = "AhJ3hnYAoAbVz5zg1e17MAACAAA=",
                description = "One-time cryptogram (TAVV / DSRP) for this payment")
        String cryptogram,

        @Schema(pattern = "^\\d{2}$", example = "05", description = "ECI from the token service, if it returned one")
        String eci) {
}
