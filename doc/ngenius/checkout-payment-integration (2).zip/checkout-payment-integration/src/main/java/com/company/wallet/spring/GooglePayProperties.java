package com.company.wallet.spring;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.util.List;

/**
 * "wallet.google-pay.*"
 *
 * @param environment TEST trusts Google's test signing keys, PRODUCTION the live ones
 * @param merchantId  Google merchant id from the Google Pay &amp; Wallet Console (recipient "merchant:&lt;id&gt;")
 * @param privateKeys base64 (or PEM) PKCS#8 EC P-256 private keys whose public keys are registered with Google;
 *                    two during a rotation
 */
@ConfigurationProperties("wallet.google-pay")
public record GooglePayProperties(
        @DefaultValue("true") boolean enabled,
        @DefaultValue("TEST") Environment environment,
        String merchantId,
        List<String> privateKeys) {

    public enum Environment { TEST, PRODUCTION }

    @Override
    public String toString() {
        return "GooglePayProperties[enabled=" + enabled + ", environment=" + environment + ", merchantId=" + merchantId
                + ", privateKeys=***]";
    }
}
