package com.company.checkout.common.logging;

/**
 * How a matched JSON value is written to the log. The result is always a JSON string.
 *
 *   FULL   "***"                       secrets: cvv, cryptogram, passwords, whole objects
 *   PAN    "411111******1111"          card numbers / network tokens (first 6 + last 4, allowed by PCI DSS)
 *   LAST4  "****1111"                  ids or tokens where only the end helps support
 *   EMAIL  "j***@example.com"          personal data
 */
public enum MaskStrategy {

    FULL {
        @Override
        public String apply(String value) {
            return MASK;
        }
    },
    PAN {
        @Override
        public String apply(String value) {
            String digits = value == null ? "" : value.replaceAll("\\D", "");
            if (digits.length() < 10) {
                return MASK;
            }
            return digits.substring(0, 6) + "*".repeat(digits.length() - 10) + digits.substring(digits.length() - 4);
        }
    },
    LAST4 {
        @Override
        public String apply(String value) {
            return value == null || value.length() < 8 ? MASK : "****" + value.substring(value.length() - 4);
        }
    },
    EMAIL {
        @Override
        public String apply(String value) {
            int at = value == null ? -1 : value.indexOf('@');
            return at < 1 ? MASK : value.charAt(0) + "***" + value.substring(at);
        }
    };

    public static final String MASK = "***";

    /** @param value the original value as text (a JSON string unescaped, a number as written, an object as raw JSON) */
    public abstract String apply(String value);
}
