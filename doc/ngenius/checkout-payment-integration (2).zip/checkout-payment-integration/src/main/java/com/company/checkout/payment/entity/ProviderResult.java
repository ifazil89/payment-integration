package com.company.checkout.payment.entity;

/**
 * What Checkout.com said about a payment, in our words (built by PaymentCkoMapper from the Checkout.com
 * response), so the entity does not depend on Checkout.com's DTOs.
 */
public record ProviderResult(
        String providerPaymentId,
        String actionId,
        String status,
        Boolean approved,
        String responseCode,
        String responseSummary,
        String redirectUrl,
        String cardScheme,
        String cardLast4) {
}
