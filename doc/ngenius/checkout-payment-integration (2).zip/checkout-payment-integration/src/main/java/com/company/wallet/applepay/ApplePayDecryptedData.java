package com.company.wallet.applepay;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The decrypted Apple Pay payment data (Apple's "Payment Token Format Reference").
 *
 * @param applicationPrimaryAccountNumber the device account number (DPAN)
 * @param applicationExpirationDate       YYMMDD
 * @param currencyCode                    ISO 4217 numeric, e.g. "784" (AED)
 * @param transactionAmount               minor units, as shown to the shopper in the Apple Pay sheet
 * @param paymentDataType                 "3DSecure" (supported) or "EMV" (China only)
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ApplePayDecryptedData(
        String applicationPrimaryAccountNumber,
        String applicationExpirationDate,
        String currencyCode,
        Long transactionAmount,
        String deviceManufacturerIdentifier,
        String paymentDataType,
        PaymentData paymentData) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record PaymentData(String onlinePaymentCryptogram, String eciIndicator) {
    }

    @Override
    public String toString() {
        return "ApplePayDecryptedData[***]";
    }
}
