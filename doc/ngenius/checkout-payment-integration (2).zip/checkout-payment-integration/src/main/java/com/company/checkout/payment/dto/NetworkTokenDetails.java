package com.company.checkout.payment.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * A network token (paymentMethod.type = NETWORK_TOKEN) your token requestor got from VTS or MDES,
 * with the one-time cryptogram for this payment. Never stored, never logged.
 */
public record NetworkTokenDetails(
        @NotBlank @Pattern(regexp = "\\d{12,19}", message = "must be 12-19 digits") String token,
        @NotNull NetworkTokenType tokenType,
        @NotNull @Min(1) @Max(12) Integer expiryMonth,
        @NotNull @Min(2000) @Max(2099) Integer expiryYear,
        @NotBlank @Size(max = 100) String cryptogram,
        @Pattern(regexp = "\\d{2}", message = "must be 2 digits") String eci) {

    public String last4() {
        return token == null || token.length() < 4 ? null : token.substring(token.length() - 4);
    }

    @Override
    public String toString() {
        return "NetworkTokenDetails[token=****" + last4() + ", tokenType=" + tokenType
                + ", expiry=" + expiryMonth + "/" + expiryYear + ", cryptogram=***, eci=" + eci + "]";
    }
}
