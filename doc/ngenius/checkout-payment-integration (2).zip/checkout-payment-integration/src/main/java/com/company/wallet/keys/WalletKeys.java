package com.company.wallet.keys;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;

/**
 * Loading wallet keys and certificates. Pure JDK, static, no configuration: where the bytes come from
 * (properties, a folder, a vault) is decided by the caller (WalletAutoConfiguration).
 *
 *   decode(...)       base64 DER, or PEM ("-----BEGIN ...-----" lines removed)
 *   certificate(...)  X.509 certificate from DER bytes or a stream
 *   ecPrivateKey(...) PKCS#8 EC private key
 *   fromPkcs12(...)   certificate + private key from a .p12 file
 */
public final class WalletKeys {

    /** A certificate and its private key, e.g. Apple's Payment Processing Certificate. */
    public record CertificateAndKey(X509Certificate certificate, PrivateKey privateKey) {

        @Override
        public String toString() {
            return "CertificateAndKey[" + certificate.getSubjectX500Principal().getName() + ", privateKey=***]";
        }
    }

    private WalletKeys() {
    }

    /** Accepts base64 DER, or PEM ("-----BEGIN ...-----" lines and whitespace are removed). */
    public static byte[] decode(String base64OrPem) {
        String body = base64OrPem.replaceAll("-----[A-Z ]+-----", "").replaceAll("\\s", "");
        return Base64.getDecoder().decode(body);
    }

    /** Tink wants base64 PKCS#8 without PEM armour. */
    public static String base64Pkcs8(String base64OrPem) {
        return Base64.getEncoder().encodeToString(decode(base64OrPem));
    }

    public static X509Certificate certificate(byte[] der) throws GeneralSecurityException {
        return certificate(new ByteArrayInputStream(der));
    }

    public static X509Certificate certificate(InputStream in) throws GeneralSecurityException {
        return (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(in);
    }

    public static PrivateKey ecPrivateKey(byte[] pkcs8) throws GeneralSecurityException {
        return KeyFactory.getInstance("EC").generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
    }

    /**
     * Certificate + private key from a PKCS#12 (.p12) file. The password is used for the file and the key.
     *
     * @param alias  entry to use; null/blank = the first entry with a private key
     * @param source shown in error messages (e.g. the file path); never the password
     * @throws IllegalStateException with a clear message: wrong password, no key, not an EC key
     */
    public static CertificateAndKey fromPkcs12(InputStream in, char[] password, String alias, String source) {
        char[] pwd = password == null ? new char[0] : password;
        try {
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(in, pwd);   // wrong password -> IOException
            String entry = alias != null && !alias.isBlank() ? alias : firstKeyAlias(keyStore, source);
            if (!keyStore.isKeyEntry(entry)) {
                throw new IllegalStateException("Keystore " + source + " has no private key under alias '" + entry + "'");
            }
            PrivateKey privateKey = (PrivateKey) keyStore.getKey(entry, pwd);
            X509Certificate certificate = (X509Certificate) keyStore.getCertificate(entry);
            if (certificate == null) {
                throw new IllegalStateException("Keystore " + source + " has no certificate under alias '" + entry + "'");
            }
            if (!"EC".equals(privateKey.getAlgorithm())) {
                throw new IllegalStateException("Keystore " + source + ": the key is " + privateKey.getAlgorithm()
                        + ", an EC P-256 key is needed (Apple Pay: the Payment Processing Certificate, "
                        + "not the Merchant Identity Certificate)");
            }
            return new CertificateAndKey(certificate, privateKey);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot open keystore " + source
                    + ": wrong password, or not a PKCS#12 file (an old macOS export may need re-exporting, see README)", e);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Cannot read keystore " + source + ": " + e.getMessage(), e);
        } finally {
            Arrays.fill(pwd, '\0');
        }
    }

    private static String firstKeyAlias(KeyStore keyStore, String source) throws KeyStoreException {
        for (String alias : Collections.list(keyStore.aliases())) {
            if (keyStore.isKeyEntry(alias)) {
                return alias;
            }
        }
        throw new IllegalStateException("Keystore " + source + " contains no private key");
    }
}
