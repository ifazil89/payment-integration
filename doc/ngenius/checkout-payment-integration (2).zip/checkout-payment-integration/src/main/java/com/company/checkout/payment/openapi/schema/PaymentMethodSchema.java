package com.company.checkout.payment.openapi.schema;

import com.company.checkout.payment.dto.PaymentMethodType;
import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for payment.dto.PaymentMethod (never instantiated). */
@Schema(name = "PaymentMethod", description = """
        How the shopper pays. Send exactly the part that belongs to `type`, nothing else:
        CARD -> `card`, NETWORK_TOKEN -> `networkToken`, APPLE_PAY -> `walletToken`, GOOGLE_PAY -> `googlePayToken`.""")
public record PaymentMethodSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, description = """
                CARD: plain card, sent to Checkout.com with 3DS (status CHALLENGE_REQUIRED). \
                NETWORK_TOKEN: VTS / MDES token + cryptogram, no 3DS. \
                APPLE_PAY / GOOGLE_PAY: encrypted wallet token, decrypted by this service.""")
        PaymentMethodType type,

        @Schema(description = "Required for CARD, must be absent otherwise")
        CardDetailsSchema card,

        @Schema(description = "Required for NETWORK_TOKEN, must be absent otherwise")
        NetworkTokenDetailsSchema networkToken,

        @Schema(description = "Required for APPLE_PAY, must be absent otherwise: PKPaymentToken.paymentData as a "
                + "JSON object, unchanged from the device. Never decrypt or change it before sending.")
        ApplePayWalletTokenSchema walletToken,

        @Schema(description = "Required for GOOGLE_PAY, must be absent otherwise: paymentMethodData.tokenizationData.token "
                + "(tokenization type DIRECT) parsed into a JSON object; signedMessage and intermediateSigningKey.signedKey "
                + "stay strings, exactly as received.")
        GooglePayWalletTokenSchema googlePayToken) {
}
