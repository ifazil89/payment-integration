package com.company.checkout.cko.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;
import java.util.Optional;

/**
 * Response of POST /payments (201 processed, 202 pending e.g. 3DS) and of GET /payments/{id}.
 *
 * @param status        Authorized, Captured, Partially Captured, Paid, Pending, Card Verified, Declined,
 *                      Voided, Canceled, Expired, Refunded, Partially Refunded, ...
 * @param responseCode  e.g. 10000 approved, 20051 insufficient funds (POST only)
 * @param links         _links: "self", "actions", "redirect" (3DS challenge page), ...
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record CkoPaymentResponse(
        @JsonProperty("id") String id,
        @JsonProperty("action_id") String actionId,
        @JsonProperty("amount") Long amount,
        @JsonProperty("currency") String currency,
        @JsonProperty("approved") Boolean approved,
        @JsonProperty("status") String status,
        @JsonProperty("auth_code") String authCode,
        @JsonProperty("response_code") String responseCode,
        @JsonProperty("response_summary") String responseSummary,
        @JsonProperty("reference") String reference,
        @JsonProperty("source") Source source,
        @JsonProperty("_links") Map<String, Link> links) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Source(
            @JsonProperty("type") String type,
            @JsonProperty("scheme") String scheme,
            @JsonProperty("last4") String last4,
            @JsonProperty("payment_account_reference") String paymentAccountReference) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Link(@JsonProperty("href") String href) {
    }

    /** The 3DS challenge page the shopper must be sent to (status Pending + _links.redirect). */
    public Optional<String> redirectUrl() {
        return Optional.ofNullable(links).map(l -> l.get("redirect")).map(Link::href);
    }
}
