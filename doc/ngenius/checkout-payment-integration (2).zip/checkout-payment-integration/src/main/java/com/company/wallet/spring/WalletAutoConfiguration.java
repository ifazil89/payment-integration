package com.company.wallet.spring;

import com.company.wallet.api.WalletDecryptor;
import com.company.wallet.applepay.ApplePayCrypto;
import com.company.wallet.applepay.ApplePayDecryptor;
import com.company.wallet.applepay.ApplePaySignatureVerifier;
import com.company.wallet.googlepay.GooglePayDecryptor;
import com.company.wallet.keys.WalletKeys;
import com.company.wallet.keys.WalletKeys.CertificateAndKey;
import com.google.crypto.tink.apps.paymentmethodtoken.GooglePaymentsPublicKeysManager;
import com.google.crypto.tink.apps.paymentmethodtoken.PaymentMethodTokenRecipient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.time.Clock;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Spring Boot glue of the wallet library: builds the decryptors from "wallet.*" properties.
 * Registered in META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports, so it is
 * found the same way inside this app today and from a separate jar later. Not component-scanned.
 *
 * Everything is checked at STARTUP: a missing key, a broken certificate, a missing folder or Apple root
 * stops the app with a message naming the property. A wallet with enabled=false gets no decryptor
 * (WALLET_NOT_ENABLED). Every bean is @ConditionalOnMissingBean: an application can replace any of them.
 *
 * Optional beans used if present: ObjectMapper (else a default JsonMapper), Clock (else UTC system clock).
 */
@AutoConfiguration
@EnableConfigurationProperties({ApplePayProperties.class, GooglePayProperties.class})
public class WalletAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(WalletAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    WalletDecryptor walletDecryptor(ObjectProvider<ApplePayDecryptor> applePay,
                                    ObjectProvider<GooglePayDecryptor> googlePay) {
        WalletDecryptor decryptor = new WalletDecryptor(applePay.getIfAvailable(), googlePay.getIfAvailable());
        log.info("Wallet decryption ready: Apple Pay {}, Google Pay {}",
                applePay.getIfAvailable() != null ? "on" : "off", googlePay.getIfAvailable() != null ? "on" : "off");
        return decryptor;
    }

    // ------------------------------------------------------------------ Apple Pay

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "wallet.apple-pay.enabled", havingValue = "true", matchIfMissing = true)
    ApplePayDecryptor applePayDecryptor(ApplePayProperties properties, ResourceLoader resourceLoader,
                                        ObjectProvider<ObjectMapper> objectMapper, ObjectProvider<Clock> clock)
            throws Exception {
        require(properties.merchantIdentifier(), "wallet.apple-pay.merchant-identifier (APPLE_PAY_MERCHANT_ID)");
        Path certificateDir = certificateDir(properties.certificateDir());

        Map<String, PrivateKey> keysByPublicKeyHash = new LinkedHashMap<>();
        for (ApplePayProperties.Key key : properties.keys()) {
            if (key.isEmpty()) {
                continue;
            }
            CertificateAndKey loaded = key.isKeystore()
                    ? fromKeystore(key, resource(key.keystore(), certificateDir, resourceLoader))
                    : fromBase64(key);
            String publicKeyHash = ApplePayCrypto.publicKeyHash(loaded.certificate().getPublicKey());
            keysByPublicKeyHash.put(publicKeyHash, loaded.privateKey());
            log.info("Apple Pay key loaded from {}: publicKeyHash {}, subject {}, valid until {}",
                    key.isKeystore() ? key.keystore() : "certificate/private-key properties", publicKeyHash,
                    loaded.certificate().getSubjectX500Principal().getName(), loaded.certificate().getNotAfter());
        }
        if (keysByPublicKeyHash.isEmpty()) {
            throw new IllegalStateException("Apple Pay is enabled but wallet.apple-pay.keys is empty "
                    + "(set keys[].keystore or keys[].certificate + private-key, or wallet.apple-pay.enabled=false)");
        }

        Resource root = resource(properties.rootCaCertificate(), certificateDir, resourceLoader);
        if (!root.exists()) {
            throw new IllegalStateException("Apple Root CA - G3 not found at " + describe(root)
                    + ". Download it from https://www.apple.com/certificateauthority/ (see README), "
                    + "or set wallet.apple-pay.enabled=false");
        }
        X509Certificate appleRoot;
        try (InputStream in = root.getInputStream()) {
            appleRoot = WalletKeys.certificate(in);
        }
        log.info("Apple Pay root CA loaded from {}: {}", describe(root), appleRoot.getSubjectX500Principal().getName());

        ApplePaySignatureVerifier verifier = new ApplePaySignatureVerifier(appleRoot, properties.maxTokenAge(),
                clock.getIfAvailable(Clock::systemUTC));
        return new ApplePayDecryptor(verifier, keysByPublicKeyHash,
                ApplePayCrypto.merchantIdentifierHash(properties.merchantIdentifier()), mapper(objectMapper));
    }

    /** Separate certificate + private key (base64 / PEM) in properties. */
    private static CertificateAndKey fromBase64(ApplePayProperties.Key key) throws GeneralSecurityException {
        require(key.certificate(), "wallet.apple-pay.keys[].certificate (APPLE_PAY_CERTIFICATE)");
        require(key.privateKey(), "wallet.apple-pay.keys[].private-key (APPLE_PAY_PRIVATE_KEY)");
        return new CertificateAndKey(WalletKeys.certificate(WalletKeys.decode(key.certificate())),
                WalletKeys.ecPrivateKey(WalletKeys.decode(key.privateKey())));
    }

    /** Certificate + private key from one .p12 file. */
    private static CertificateAndKey fromKeystore(ApplePayProperties.Key key, Resource resource) throws IOException {
        if (!resource.exists()) {
            throw new IllegalStateException("Apple Pay keystore not found: " + describe(resource)
                    + " (wallet.apple-pay.keys[].keystore / APPLE_PAY_KEYSTORE)");
        }
        if (!resource.isReadable()) {
            throw new IllegalStateException("Apple Pay keystore is not readable by the application user: "
                    + describe(resource));
        }
        char[] password = key.keystorePassword() == null ? new char[0] : key.keystorePassword().toCharArray();
        try (InputStream in = resource.getInputStream()) {
            return WalletKeys.fromPkcs12(in, password, key.alias(), describe(resource));
        }
    }

    // ------------------------------------------------------------------ Google Pay

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "wallet.google-pay.enabled", havingValue = "true", matchIfMissing = true)
    GooglePayDecryptor googlePayDecryptor(GooglePayProperties properties, ObjectProvider<ObjectMapper> objectMapper,
                                          ObjectProvider<Clock> clock) throws GeneralSecurityException {
        require(properties.merchantId(), "wallet.google-pay.merchant-id (GOOGLE_PAY_MERCHANT_ID)");
        List<String> privateKeys = properties.privateKeys() == null ? List.of()
                : properties.privateKeys().stream().filter(k -> k != null && !k.isBlank()).toList();
        if (privateKeys.isEmpty()) {
            throw new IllegalStateException(
                    "Google Pay is enabled but wallet.google-pay.private-keys (GOOGLE_PAY_PRIVATE_KEYS) is empty");
        }

        PaymentMethodTokenRecipient.Builder builder = new PaymentMethodTokenRecipient.Builder()
                .fetchSenderVerifyingKeysWith(properties.environment() == GooglePayProperties.Environment.PRODUCTION
                        ? GooglePaymentsPublicKeysManager.INSTANCE_PRODUCTION
                        : GooglePaymentsPublicKeysManager.INSTANCE_TEST)
                .recipientId("merchant:" + properties.merchantId())
                .protocolVersion("ECv2");
        for (String privateKey : privateKeys) {
            builder.addRecipientPrivateKey(WalletKeys.base64Pkcs8(privateKey));
        }
        PaymentMethodTokenRecipient recipient = builder.build();
        log.info("Google Pay decryption ready: environment {}, merchant {}, {} key(s)",
                properties.environment(), properties.merchantId(), privateKeys.size());
        return new GooglePayDecryptor(recipient::unseal, mapper(objectMapper), clock.getIfAvailable(Clock::systemUTC));
    }

    // ------------------------------------------------------------------ helpers

    private static ObjectMapper mapper(ObjectProvider<ObjectMapper> objectMapper) {
        return objectMapper.getIfAvailable(() -> JsonMapper.builder().build());
    }

    private static void require(String value, String property) {
        if (value == null || value.isBlank()) {
            throw new IllegalStateException(property + " is not set (or switch the wallet off with enabled=false)");
        }
    }

    /** The external folder, checked at startup; null when not configured (then only full locations work). */
    private static Path certificateDir(String dir) {
        if (dir == null || dir.isBlank()) {
            return null;
        }
        Path path = Path.of(dir).toAbsolutePath().normalize();
        if (!Files.isDirectory(path)) {
            throw new IllegalStateException("wallet.apple-pay.certificate-dir (APPLE_PAY_CERT_DIR) is not a folder: "
                    + path);
        }
        if (!Files.isReadable(path)) {
            throw new IllegalStateException(
                    "wallet.apple-pay.certificate-dir is not readable by the application user: " + path);
        }
        log.info("Apple Pay certificate folder: {}", path);
        return path;
    }

    /**
     * Where a file is:
     *   "classpath:apple/x.cer", "file:/etc/x.p12"  -> as written
     *   "/opt/certs/x.p12" (absolute path)          -> that file
     *   "apple-pay.p12" (plain name)                -> certificate-dir/apple-pay.p12
     */
    static Resource resource(String location, Path certificateDir, ResourceLoader resourceLoader) {
        if (location == null || location.isBlank()) {
            throw new IllegalStateException("Apple Pay file location is empty (keys[].keystore / root-ca-certificate)");
        }
        if (location.startsWith("classpath:") || location.startsWith("file:")) {
            return resourceLoader.getResource(location);
        }
        Path path = Path.of(location);
        if (!path.isAbsolute()) {
            if (certificateDir == null) {
                throw new IllegalStateException("'" + location + "' is a plain file name but "
                        + "wallet.apple-pay.certificate-dir (APPLE_PAY_CERT_DIR) is not set");
            }
            path = certificateDir.resolve(location).normalize();
        }
        return new FileSystemResource(path);
    }

    private static String describe(Resource resource) {
        try {
            return resource.getFile().getAbsolutePath();
        } catch (IOException ex) {
            return resource.getDescription();   // classpath resource inside a jar
        }
    }
}
