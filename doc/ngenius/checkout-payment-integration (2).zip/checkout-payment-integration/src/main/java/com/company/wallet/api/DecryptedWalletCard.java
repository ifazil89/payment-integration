package com.company.wallet.api;

/**
 * The card data inside a verified, decrypted wallet token. PSP-neutral: each PSP integration maps it to its
 * own request. Lives only in memory for the duration of one payment request: never stored, never logged
 * (toString shows last 4 digits only).
 *
 * @param pan                 DPAN (CRYPTOGRAM_3DS) or real card number (PAN_ONLY)
 * @param cryptogram          one-time cryptogram; null for PAN_ONLY
 * @param eci                 ECI from the wallet; may be null (e.g. some Mastercard tokens)
 * @param walletTransactionId Apple header.transactionId / Google messageId: one payment per token
 * @param amountMinor         amount the shopper approved in the wallet sheet (Apple Pay only, else null)
 * @param currencyNumeric     ISO 4217 numeric currency of that amount (Apple Pay only, e.g. "784")
 */
public record DecryptedWalletCard(
        WalletType walletType,
        AuthMethod authMethod,
        String pan,
        int expiryMonth,
        int expiryYear,
        String cryptogram,
        String eci,
        String walletTransactionId,
        Long amountMinor,
        String currencyNumeric) {

    public String last4() {
        return pan == null || pan.length() < 4 ? null : pan.substring(pan.length() - 4);
    }

    @Override
    public String toString() {
        return "DecryptedWalletCard[" + walletType + ", " + authMethod + ", pan=****" + last4()
                + ", expiry=" + expiryMonth + "/" + expiryYear + ", cryptogram=" + (cryptogram == null ? null : "***")
                + ", eci=" + eci + ", walletTransactionId=" + walletTransactionId + "]";
    }
}
