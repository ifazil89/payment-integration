package com.company.checkout.cko.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The payment source, in one of two shapes:
 *
 *   network_token   decrypted Apple Pay / Google Pay CRYPTOGRAM_3DS: DPAN + cryptogram (+ ECI)
 *                   {"type":"network_token","token":"<DPAN>","token_type":"applepay|googlepay",
 *                    "expiry_month":..,"expiry_year":..,"cryptogram":"..","eci":".."}
 *                   or a VTS / MDES network token from the client (token_type "vts" / "mdes")
 *   card            a plain card (with cvv) or decrypted Google Pay PAN_ONLY (no cvv)
 *                   {"type":"card","number":"..","expiry_month":..,"expiry_year":..,"cvv":"..","name":".."}
 *
 * Holds card data: toString masks it, and the logging masker hides source.token / number / cvv / cryptogram.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record CkoSource(
        @JsonProperty("type") String type,
        @JsonProperty("token") String token,
        @JsonProperty("token_type") String tokenType,
        @JsonProperty("number") String number,
        @JsonProperty("expiry_month") Integer expiryMonth,
        @JsonProperty("expiry_year") Integer expiryYear,
        @JsonProperty("cvv") String cvv,
        @JsonProperty("cryptogram") String cryptogram,
        @JsonProperty("eci") String eci,
        @JsonProperty("name") String name,
        @JsonProperty("billing_address") CkoAddress billingAddress) {

    public static CkoSource networkToken(String token, String tokenType, int expiryMonth, int expiryYear,
                                         String cryptogram, String eci, CkoAddress billingAddress) {
        return new CkoSource("network_token", token, tokenType, null, expiryMonth, expiryYear, null, cryptogram, eci,
                null, billingAddress);
    }

    /** @param cvv null for Google Pay PAN_ONLY (the wallet has none) */
    public static CkoSource card(String number, int expiryMonth, int expiryYear, String cvv, String name,
                                 CkoAddress billingAddress) {
        return new CkoSource("card", null, null, number, expiryMonth, expiryYear, cvv, null, null, name, billingAddress);
    }

    @Override
    public String toString() {
        return "CkoSource[type=" + type + ", tokenType=" + tokenType + ", ***]";
    }
}
