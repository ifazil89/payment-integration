package com.company.checkout.cko.client;

import com.company.checkout.cko.dto.CkoPaymentRequest;
import com.company.checkout.cko.dto.CkoPaymentResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.function.Supplier;

/**
 * Every call to Checkout.com, one method per operation. Shared by all features (payment now;
 * refund / void / webhooks later). It knows only Checkout.com DTOs: no API DTOs, no entities.
 *
 * Logging: the raw HTTP request/response (masked) comes from RestClientLoggingInterceptor; this class
 * adds one business line per call:  CKO <operation> -> <status> (<ms> ms)
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class CkoClient {

    static final String IDEMPOTENCY_HEADER = "Cko-Idempotency-Key";

    private final RestClient ckoRestClient;

    /**
     * POST /payments. The same idempotency key always returns the same payment, so a retry after a
     * timeout can never charge twice: we use our own payment id.
     */
    public CkoPaymentResponse requestPayment(CkoPaymentRequest request, String idempotencyKey) {
        return call("request payment", () -> ckoRestClient.post()
                .uri("/payments")
                .header(IDEMPOTENCY_HEADER, idempotencyKey)
                .body(request)
                .retrieve()
                .body(CkoPaymentResponse.class));
    }

    /** GET /payments/{id}: the current status (e.g. Captured after auto capture, or after a 3DS challenge). */
    public CkoPaymentResponse getPayment(String ckoPaymentId) {
        return call("get payment", () -> ckoRestClient.get()
                .uri("/payments/{id}", ckoPaymentId)
                .retrieve()
                .body(CkoPaymentResponse.class));
    }

    private CkoPaymentResponse call(String operation, Supplier<CkoPaymentResponse> request) {
        long start = System.nanoTime();
        try {
            CkoPaymentResponse response = request.get();
            log.atInfo()
                    .setMessage("CKO {} -> {} ({} ms)")
                    .addArgument(operation)
                    .addArgument(response == null ? "no body" : response.status())
                    .addArgument(elapsedMs(start))
                    .addKeyValue("cko.operation", operation)
                    .addKeyValue("cko.status", response == null ? null : response.status())
                    .addKeyValue("cko.payment_id", response == null ? null : response.id())
                    .addKeyValue("cko.response_code", response == null ? null : response.responseCode())
                    .addKeyValue("cko.duration_ms", elapsedMs(start))
                    .log();
            return response;
        } catch (RuntimeException ex) {
            log.atWarn()
                    .setMessage("CKO {} FAILED after {} ms: {}")
                    .addArgument(operation).addArgument(elapsedMs(start)).addArgument(ex.getMessage())
                    .addKeyValue("cko.operation", operation)
                    .addKeyValue("cko.duration_ms", elapsedMs(start))
                    .addKeyValue("error.type", ex.getClass().getSimpleName())
                    .log();
            throw ex;
        }
    }

    private static long elapsedMs(long start) {
        return (System.nanoTime() - start) / 1_000_000;
    }
}
