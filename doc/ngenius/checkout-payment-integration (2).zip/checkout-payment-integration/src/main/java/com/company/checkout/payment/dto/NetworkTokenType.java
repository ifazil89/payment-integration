package com.company.checkout.payment.dto;

/** Who issued the network token: Visa Token Service or Mastercard Digital Enablement Service. */
public enum NetworkTokenType {
    VTS,
    MDES
}
