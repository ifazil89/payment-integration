package com.company.checkout.payment.openapi.schema;

import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for payment.dto.CardDetails (never instantiated). */
@Schema(name = "CardDetails", description = "A plain card. Never stored; masked in all logs.")
public record CardDetailsSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, pattern = "^\\d{12,19}$", example = "4242424242424242",
                description = "Card number, digits only; must pass the Luhn check")
        String number,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, minimum = "1", maximum = "12", example = "12")
        Integer expiryMonth,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, minimum = "2000", maximum = "2099", example = "2030",
                description = "4 digits. An expired card is rejected with 422 CARD_EXPIRED")
        Integer expiryYear,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, pattern = "^\\d{3,4}$", example = "100")
        String cvv,

        @Schema(maxLength = 100, example = "Jane Doe", description = "Cardholder name; default: billing first + last name")
        String name) {
}
