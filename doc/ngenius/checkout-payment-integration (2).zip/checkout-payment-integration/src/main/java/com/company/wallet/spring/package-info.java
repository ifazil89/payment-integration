/**
 * Spring Boot glue of the wallet library (the future "wallet-decryption-spring-boot-starter"): properties
 * ("wallet.*") and {@link com.company.wallet.spring.WalletAutoConfiguration}. The only wallet package that may use
 * Spring.
 */
package com.company.wallet.spring;
