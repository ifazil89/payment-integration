package com.company.checkout.common.logging;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.util.List;

/**
 * What to mask in logged bodies and headers ("app.logging.masking.*").
 *
 * Rules are JSON paths from the root of the body, dot-separated, case-insensitive:
 *   paymentMethod.card.number     exactly that field
 *   *.card.number                 "*" = any ONE field name
 *   **.cvv                        "**" = any depth (zero or more fields): cvv anywhere
 *   items.card.number             arrays are transparent: matches every element of "items"
 *                                 ("items[*].card.number" is accepted too)
 * The first matching rule wins. A rule on an object masks the whole object.
 * A built-in baseline (cvv, cryptogram, passwords, wallet tokens anywhere) always applies after your rules.
 *
 * @param rules   path + strategy, checked in order
 * @param headers extra header names to mask (Authorization, X-Api-Key, cookies are always masked)
 */
@ConfigurationProperties("app.logging.masking")
public record MaskingProperties(List<Rule> rules, List<String> headers) {

    /**
     * @param path     e.g. "paymentMethod.card.number"
     * @param strategy FULL (default), PAN, LAST4, EMAIL
     */
    public record Rule(String path, @DefaultValue("FULL") MaskStrategy strategy) {
    }

    public List<Rule> rules() {
        return rules == null ? List.of() : rules;
    }

    public List<String> headers() {
        return headers == null ? List.of() : headers;
    }
}
