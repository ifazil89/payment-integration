/**
 * PUBLIC API of the wallet decryption library. Applications use only this package (and configure it through
 * {@code wallet.*} properties, see com.company.wallet.spring). Everything else is internal and may change.
 *
 * <pre>
 *   WalletDecryptor.decryptApplePay(ApplePayToken | String)   -> DecryptedWalletCard
 *   WalletDecryptor.decryptGooglePay(GooglePayToken | String) -> DecryptedWalletCard
 *   WalletDecryptionException(code)                           -> map to your API error
 * </pre>
 *
 * Rules (enforced by WalletBoundaryTest): no Spring, no Lombok, nothing from the application using it.
 */
package com.company.wallet.api;
