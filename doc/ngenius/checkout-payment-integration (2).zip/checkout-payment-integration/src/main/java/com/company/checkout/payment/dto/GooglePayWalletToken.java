package com.company.checkout.payment.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * Google Pay paymentMethodData.tokenizationData.token, sent as a JSON object (the client parses Google's string
 * once). Encrypted (ECv2); decrypted by this service. Never stored; masked in logs.
 *
 * @param protocolVersion        "ECv2"
 * @param signature              base64 signature of signedMessage by the intermediate key
 * @param intermediateSigningKey key signed by Google's root signing key
 * @param signedMessage          JSON as a STRING {encryptedMessage, ephemeralPublicKey, tag}; exactly as received
 */
public record GooglePayWalletToken(
        @NotBlank @Size(max = 10) String protocolVersion,
        @NotBlank @Size(max = 1000) String signature,
        @NotNull @Valid IntermediateSigningKey intermediateSigningKey,
        @NotBlank @Size(max = 20000) String signedMessage) {

    /**
     * @param signedKey  JSON as a STRING {keyValue, keyExpiration}; exactly as received
     * @param signatures base64 signatures of signedKey by Google's root keys
     */
    public record IntermediateSigningKey(
            @NotBlank @Size(max = 2000) String signedKey,
            @NotEmpty @Size(max = 10) List<@NotBlank @Size(max = 1000) String> signatures) {
    }

    @Override
    public String toString() {
        return "GooglePayWalletToken[protocolVersion=" + protocolVersion + ", signature=***, signedMessage=***]";
    }
}
