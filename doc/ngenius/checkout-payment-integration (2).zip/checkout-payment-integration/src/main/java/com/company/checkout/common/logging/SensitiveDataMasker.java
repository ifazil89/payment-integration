package com.company.checkout.common.logging;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.StringJoiner;
import java.util.regex.Pattern;

/**
 * Makes payloads and headers safe to log (PCI DSS: no full card number, never a CVV or cryptogram).
 *
 * Masking follows the JSON STRUCTURE: every value is masked by its path from the root, so
 * "paymentMethod.card.number" masks exactly that field and nothing else called "number".
 * Rules come from configuration (app.logging.masking.rules, see {@link MaskingProperties}):
 *
 *   paymentMethod.card.number     PAN    -> "411111******1111"
 *   paymentMethod.card.cvv        FULL   -> "***"
 *   **.email                      EMAIL  -> "j***@example.com"
 *
 * After the configured rules a BASELINE is always applied (cvv, cryptogram, wallet tokens, passwords,
 * OAuth secrets anywhere in the body), so a missing rule can never leak a secret.
 *
 * How it works: a small JSON scanner copies the body character by character and keeps the current path.
 * When a field's path matches a rule, its value (string, number, object or array) is replaced. Everything
 * else, including formatting, is copied unchanged. No Jackson, no object tree: cheap and easy to debug.
 *
 * Bodies that are not valid JSON are never logged as-is:
 *   starts with { or [ but broken  -> "[invalid JSON, N chars, not logged]"
 *   other text (form, plain text)  -> logged with every 12-19 digit run masked as a card number
 */
public class SensitiveDataMasker {

    static final String MASK = MaskStrategy.MASK;
    private static final int MAX_DEPTH = 64;

    /** Applied after the configured rules, cannot be switched off. */
    static final List<MaskingProperties.Rule> BASELINE = List.of(
            rule("**.cvv", MaskStrategy.FULL),
            rule("**.cvc", MaskStrategy.FULL),
            rule("**.cryptogram", MaskStrategy.FULL),
            rule("**.onlinePaymentCryptogram", MaskStrategy.FULL),
            rule("**.walletToken", MaskStrategy.FULL),
            rule("**.googlePayToken", MaskStrategy.FULL),
            rule("**.applicationPrimaryAccountNumber", MaskStrategy.PAN),
            rule("**.pan", MaskStrategy.PAN),
            rule("**.password", MaskStrategy.FULL),
            rule("**.access_token", MaskStrategy.FULL),
            rule("**.refresh_token", MaskStrategy.FULL),
            rule("**.client_secret", MaskStrategy.FULL));

    private static final Set<String> BASELINE_HEADERS =
            Set.of("authorization", "proxy-authorization", "x-api-key", "cookie", "set-cookie");

    /** 12-19 digits, optionally separated by single spaces or dashes: a card number in free text. */
    private static final Pattern PAN_IN_TEXT = Pattern.compile("(?<!\\d)\\d(?:[ -]?\\d){11,18}(?!\\d)");

    private final LoggingProperties properties;
    private final List<CompiledRule> rules;
    private final Set<String> secretHeaders;

    public SensitiveDataMasker(LoggingProperties properties, MaskingProperties masking) {
        this.properties = properties;
        List<CompiledRule> compiled = new ArrayList<>();
        masking.rules().forEach(r -> compiled.add(CompiledRule.of(r)));
        BASELINE.forEach(r -> compiled.add(CompiledRule.of(r)));
        this.rules = List.copyOf(compiled);
        Set<String> headers = new LinkedHashSet<>(BASELINE_HEADERS);
        masking.headers().forEach(h -> headers.add(h.toLowerCase(Locale.ROOT)));
        this.secretHeaders = Set.copyOf(headers);
    }

    /** Body for the log: masked, cut to the max length; binary content is not logged. */
    public String body(byte[] content, String contentType) {
        if (!properties.logBodies()) {
            return "[not logged]";
        }
        if (content == null || content.length == 0) {
            return "";
        }
        if (!isText(contentType)) {
            return "[" + content.length + " bytes " + contentType + "]";
        }
        return truncate(mask(new String(content, StandardCharsets.UTF_8)));
    }

    /** Masks any text body: JSON by path, other text by scrubbing card-number-like digit runs. */
    public String mask(String text) {
        if (text == null || text.isBlank()) {
            return text;
        }
        char first = text.stripLeading().charAt(0);
        if (first == '{' || first == '[') {
            return maskJson(text);
        }
        return PAN_IN_TEXT.matcher(text).replaceAll(m -> MaskStrategy.PAN.apply(m.group()));
    }

    /** Masks a JSON document by path. Invalid JSON is not returned at all (it could hide anything). */
    public String maskJson(String json) {
        if (json == null || json.isBlank()) {
            return json;
        }
        try {
            return new Scanner(json).run();
        } catch (InvalidJson ex) {
            return "[invalid JSON, " + json.length() + " chars, not logged]";
        }
    }

    public String headers(HttpHeaders headers) {
        StringJoiner joiner = new StringJoiner(", ", "{", "}");
        headers.forEach((name, values) -> joiner.add(name + "=" + headerValue(name, String.join(",", values))));
        return joiner.toString();
    }

    public String headerValue(String name, String value) {
        return secretHeaders.contains(name.toLowerCase(Locale.ROOT)) ? MASK : value;
    }

    /** 4111111111111111 -> 411111******1111; too short to be a card number -> *** */
    static String maskPan(String pan) {
        return MaskStrategy.PAN.apply(pan);
    }

    /** The first rule whose path matches, or null. Path segments are lower-case field names. */
    MaskStrategy strategyFor(List<String> path) {
        for (CompiledRule rule : rules) {
            if (rule.matches(path)) {
                return rule.strategy();
            }
        }
        return null;
    }

    // ------------------------------------------------------------------------------------------------
    // Rules
    // ------------------------------------------------------------------------------------------------

    private static MaskingProperties.Rule rule(String path, MaskStrategy strategy) {
        return new MaskingProperties.Rule(path, strategy);
    }

    /** "paymentMethod.card.number" -> ["paymentmethod","card","number"]; "items[*]" -> "items". */
    record CompiledRule(String[] segments, MaskStrategy strategy) {

        static CompiledRule of(MaskingProperties.Rule rule) {
            if (rule.path() == null || rule.path().isBlank()) {
                throw new IllegalArgumentException("app.logging.masking.rules: path is required");
            }
            String[] segments = Arrays.stream(rule.path().trim().split("\\."))
                    .map(s -> s.replaceAll("\\[[^]]*]", "").trim().toLowerCase(Locale.ROOT))
                    .toArray(String[]::new);
            if (Arrays.stream(segments).anyMatch(String::isEmpty)) {
                throw new IllegalArgumentException("app.logging.masking.rules: invalid path '" + rule.path() + "'");
            }
            return new CompiledRule(segments, rule.strategy() == null ? MaskStrategy.FULL : rule.strategy());
        }

        boolean matches(List<String> path) {
            return matches(0, path, 0);
        }

        private boolean matches(int ri, List<String> path, int pi) {
            if (ri == segments.length) {
                return pi == path.size();
            }
            String segment = segments[ri];
            if (segment.equals("**")) {
                for (int k = pi; k <= path.size(); k++) {   // ** = zero or more fields
                    if (matches(ri + 1, path, k)) {
                        return true;
                    }
                }
                return false;
            }
            if (pi == path.size()) {
                return false;
            }
            return (segment.equals("*") || segment.equals(path.get(pi))) && matches(ri + 1, path, pi + 1);
        }
    }

    // ------------------------------------------------------------------------------------------------
    // JSON scanner: copies the input to the output, replacing values whose path matches a rule.
    // Arrays do not add a path segment, so "items.card.number" matches every element of "items".
    // ------------------------------------------------------------------------------------------------

    private static final class InvalidJson extends RuntimeException {
        InvalidJson(String message) {
            super(message, null, false, false);
        }
    }

    private final class Scanner {
        private final String in;
        private final StringBuilder out;
        private final List<String> path = new ArrayList<>();
        private int pos;

        Scanner(String in) {
            this.in = in;
            this.out = new StringBuilder(in.length());
        }

        String run() {
            copyWhitespace();
            value(0);
            copyWhitespace();
            if (pos != in.length()) {
                throw new InvalidJson("unexpected content after the document at " + pos);
            }
            return out.toString();
        }

        private void value(int depth) {
            if (depth > MAX_DEPTH) {
                throw new InvalidJson("too deep");
            }
            char c = peek();
            if (c == '{') {
                object(depth);
            } else if (c == '[') {
                array(depth);
            } else if (c == '"') {
                out.append(in, pos, skipString());
            } else {
                out.append(in, pos, skipLiteral());
            }
        }

        private void object(int depth) {
            out.append(in.charAt(pos++));                       // {
            copyWhitespace();
            if (peek() == '}') {
                out.append(in.charAt(pos++));
                return;
            }
            while (true) {
                copyWhitespace();
                if (peek() != '"') {
                    throw new InvalidJson("field name expected at " + pos);
                }
                int keyStart = pos;
                int keyEnd = skipString();
                String key = unescape(in.substring(keyStart + 1, keyEnd - 1));
                out.append(in, keyStart, keyEnd);
                copyWhitespace();
                expect(':');
                copyWhitespace();

                path.add(key.toLowerCase(Locale.ROOT));
                MaskStrategy strategy = strategyFor(path);
                if (strategy == null) {
                    value(depth + 1);
                } else {
                    maskedValue(strategy);
                }
                path.removeLast();

                copyWhitespace();
                char c = peek();
                out.append(c);
                pos++;
                if (c == '}') {
                    return;
                }
                if (c != ',') {
                    throw new InvalidJson("',' or '}' expected at " + (pos - 1));
                }
            }
        }

        private void array(int depth) {
            out.append(in.charAt(pos++));                       // [
            copyWhitespace();
            if (peek() == ']') {
                out.append(in.charAt(pos++));
                return;
            }
            while (true) {
                copyWhitespace();
                value(depth + 1);
                copyWhitespace();
                char c = peek();
                out.append(c);
                pos++;
                if (c == ']') {
                    return;
                }
                if (c != ',') {
                    throw new InvalidJson("',' or ']' expected at " + (pos - 1));
                }
            }
        }

        /** Replaces the value at pos. Objects and arrays are always replaced by "***" as a whole. */
        private void maskedValue(MaskStrategy strategy) {
            char c = peek();
            String masked;
            if (c == '{' || c == '[') {
                skipStructure();
                masked = MASK;
            } else if (c == '"') {
                int start = pos;
                int end = skipString();
                masked = strategy.apply(unescape(in.substring(start + 1, end - 1)));
            } else {
                int start = pos;
                int end = skipLiteral();
                String literal = in.substring(start, end);
                if (literal.equals("null")) {                   // nothing to hide; keeps "was it sent?" visible
                    out.append(literal);
                    return;
                }
                masked = strategy.apply(literal);
            }
            out.append('"').append(escape(masked)).append('"');
        }

        // ---- low-level helpers: each skipX moves pos past the token and returns the new pos ----

        private int skipString() {
            pos++;                                              // opening quote
            while (pos < in.length()) {
                char c = in.charAt(pos++);
                if (c == '\\') {
                    if (pos >= in.length()) {
                        break;
                    }
                    pos++;
                } else if (c == '"') {
                    return pos;
                }
            }
            throw new InvalidJson("unterminated string");
        }

        private int skipLiteral() {
            int start = pos;
            while (pos < in.length() && "{}[],:\" \t\r\n".indexOf(in.charAt(pos)) < 0) {
                pos++;
            }
            String literal = in.substring(start, pos);
            if (literal.isEmpty() || !(literal.equals("true") || literal.equals("false") || literal.equals("null")
                    || literal.matches("-?(0|[1-9]\\d*)(\\.\\d+)?([eE][+-]?\\d+)?"))) {
                throw new InvalidJson("invalid value at " + start);
            }
            return pos;
        }

        /** Skips a whole object or array without copying it (still validated). */
        private void skipStructure() {
            int outLength = out.length();
            List<String> saved = new ArrayList<>(path);
            value(path.size());                                 // reuse the scanner, then drop what it wrote
            out.setLength(outLength);
            path.clear();
            path.addAll(saved);
        }

        private void copyWhitespace() {
            while (pos < in.length() && Character.isWhitespace(in.charAt(pos))) {
                out.append(in.charAt(pos++));
            }
        }

        private void expect(char expected) {
            if (peek() != expected) {
                throw new InvalidJson("'" + expected + "' expected at " + pos);
            }
            out.append(in.charAt(pos++));
        }

        private char peek() {
            if (pos >= in.length()) {
                throw new InvalidJson("unexpected end");
            }
            return in.charAt(pos);
        }
    }

    // ------------------------------------------------------------------------------------------------

    private static String unescape(String s) {
        if (s.indexOf('\\') < 0) {
            return s;
        }
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '\\' || i + 1 >= s.length()) {
                sb.append(c);
                continue;
            }
            char e = s.charAt(++i);
            switch (e) {
                case 'n' -> sb.append('\n');
                case 't' -> sb.append('\t');
                case 'r' -> sb.append('\r');
                case 'b' -> sb.append('\b');
                case 'f' -> sb.append('\f');
                case 'u' -> {
                    if (i + 4 >= s.length()) {
                        throw new InvalidJson("bad unicode escape");
                    }
                    try {
                        sb.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16));
                    } catch (NumberFormatException ex) {
                        throw new InvalidJson("bad unicode escape");
                    }
                    i += 4;
                }
                default -> sb.append(e);                        // \" \\ \/
            }
        }
        return sb.toString();
    }

    private static String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String truncate(String text) {
        int max = properties.maxBodyLength();
        return text.length() <= max ? text : text.substring(0, max) + "...[truncated, " + text.length() + " chars]";
    }

    private static boolean isText(String contentType) {
        if (contentType == null) {
            return true;   // some error responses omit it; masking still applies
        }
        try {
            MediaType type = MediaType.parseMediaType(contentType);
            return "text".equals(type.getType())
                    || type.getSubtype().contains("json")
                    || type.getSubtype().contains("xml")
                    || type.isCompatibleWith(MediaType.APPLICATION_FORM_URLENCODED);
        } catch (RuntimeException ex) {
            return false;
        }
    }
}
