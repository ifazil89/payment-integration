package com.company.checkout.cko.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * POST /payments body.
 *
 * @param amount    MINOR units (AED 250.00 -> 25000)
 * @param reference our merchantOrderId (shown in the Checkout.com Dashboard)
 * @param capture   true = auto capture
 * @param threeDs   only for Google Pay PAN_ONLY; then successUrl / failureUrl are where the shopper returns
 * @param metadata  our paymentId, to find the payment from the Dashboard or a webhook
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record CkoPaymentRequest(
        @JsonProperty("source") CkoSource source,
        @JsonProperty("amount") long amount,
        @JsonProperty("currency") String currency,
        @JsonProperty("reference") String reference,
        @JsonProperty("capture") boolean capture,
        @JsonProperty("processing_channel_id") String processingChannelId,
        @JsonProperty("payment_type") String paymentType,
        @JsonProperty("customer") CkoCustomer customer,
        @JsonProperty("3ds") CkoThreeDs threeDs,
        @JsonProperty("success_url") String successUrl,
        @JsonProperty("failure_url") String failureUrl,
        @JsonProperty("metadata") Map<String, String> metadata) {

    @Override
    public String toString() {
        return "CkoPaymentRequest[reference=" + reference + ", amount=" + amount + " " + currency + ", source=" + source + "]";
    }
}
