package com.company.wallet.applepay;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * Apple Pay EC_v1 decryption, as in Apple's "Payment Token Format Reference". Pure JDK:
 *
 *   1. shared secret = ECDH(our Payment Processing private key, the token's ephemeral public key)
 *   2. symmetric key = NIST SP 800-56A concatenation KDF, one SHA-256 round:
 *        SHA-256( 00 00 00 01 || sharedSecret || 0x0D || "id-aes256-GCM" || "Apple" || SHA-256(merchantIdentifier) )
 *   3. plaintext     = AES-256-GCM decrypt(data), IV = 16 zero bytes, 128-bit tag at the end of data
 *
 * The signature check comes BEFORE this (ApplePaySignatureVerifier).
 */
public final class ApplePayCrypto {

    private static final byte[] COUNTER = {0, 0, 0, 1};
    private static final byte[] ALGORITHM_ID = concat(new byte[]{0x0D}, "id-aes256-GCM".getBytes(StandardCharsets.US_ASCII));
    private static final byte[] PARTY_U_INFO = "Apple".getBytes(StandardCharsets.US_ASCII);
    private static final int GCM_TAG_BITS = 128;
    private static final byte[] GCM_IV = new byte[16];

    private ApplePayCrypto() {
    }

    /** Decrypts the token's {@code data}. Throws GeneralSecurityException on any failure (wrong key, tampering). */
    public static byte[] decrypt(byte[] data, byte[] ephemeralPublicKeyX509, PrivateKey merchantPrivateKey,
                                 byte[] merchantIdentifierHash) throws GeneralSecurityException {
        PublicKey ephemeral = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(ephemeralPublicKeyX509));

        KeyAgreement agreement = KeyAgreement.getInstance("ECDH");
        agreement.init(merchantPrivateKey);
        agreement.doPhase(ephemeral, true);
        byte[] sharedSecret = agreement.generateSecret();

        byte[] symmetricKey = deriveKey(sharedSecret, merchantIdentifierHash);

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(symmetricKey, "AES"), new GCMParameterSpec(GCM_TAG_BITS, GCM_IV));
        return cipher.doFinal(data);
    }

    /** KDF step (2). Package-visible for tests. */
    static byte[] deriveKey(byte[] sharedSecret, byte[] merchantIdentifierHash) throws GeneralSecurityException {
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        sha256.update(COUNTER);
        sha256.update(sharedSecret);
        sha256.update(ALGORITHM_ID);
        sha256.update(PARTY_U_INFO);
        sha256.update(merchantIdentifierHash);
        return sha256.digest();
    }

    /** Party V info: SHA-256 of the merchant identifier, e.g. "merchant.com.company.shop". */
    public static byte[] merchantIdentifierHash(String merchantIdentifier) {
        return sha256(merchantIdentifier.getBytes(StandardCharsets.UTF_8));
    }

    /** What Apple puts in header.publicKeyHash: base64(SHA-256(DER SubjectPublicKeyInfo of our certificate's key)). */
    public static String publicKeyHash(PublicKey publicKey) {
        return Base64.getEncoder().encodeToString(sha256(publicKey.getEncoded()));
    }

    static byte[] sha256(byte[] input) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(input);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    static byte[] concat(byte[]... parts) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (byte[] part : parts) {
            out.writeBytes(part);
        }
        return out.toByteArray();
    }
}
