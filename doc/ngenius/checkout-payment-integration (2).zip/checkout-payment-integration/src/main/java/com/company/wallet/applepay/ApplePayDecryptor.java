package com.company.wallet.applepay;

import com.company.wallet.api.ApplePayToken;
import com.company.wallet.api.AuthMethod;
import com.company.wallet.api.DecryptedWalletCard;
import com.company.wallet.api.WalletDecryptionException;
import com.company.wallet.api.WalletType;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.util.Arrays;
import java.util.Base64;
import java.util.Map;

/**
 * Apple Pay EC_v1: parse → verify signature → pick our key by publicKeyHash → decrypt → read the card.
 *
 * Accepts the token as an object ({@link ApplePayToken}), or as the JSON of {@code PKPaymentToken.paymentData}
 * (or that JSON base64-encoded). Built once by WalletAutoConfiguration (or by hand); thread-safe.
 */
public class ApplePayDecryptor {

    private final ApplePaySignatureVerifier signatureVerifier;
    /** publicKeyHash (as in the token header) -> our Payment Processing private key. Two during a rotation. */
    private final Map<String, PrivateKey> keysByPublicKeyHash;
    private final byte[] merchantIdentifierHash;
    private final ObjectMapper objectMapper;

    public ApplePayDecryptor(ApplePaySignatureVerifier signatureVerifier, Map<String, PrivateKey> keysByPublicKeyHash,
                             byte[] merchantIdentifierHash, ObjectMapper objectMapper) {
        this.signatureVerifier = signatureVerifier;
        this.keysByPublicKeyHash = Map.copyOf(keysByPublicKeyHash);
        this.merchantIdentifierHash = merchantIdentifierHash.clone();
        this.objectMapper = objectMapper;
    }

    /** Token as a string: JSON of PKPaymentToken.paymentData, or that JSON base64-encoded. */
    public DecryptedWalletCard decrypt(String walletToken) {
        return decrypt(parseToken(walletToken));
    }

    /** Token already parsed, e.g. sent by the client as a JSON object. */
    public DecryptedWalletCard decrypt(ApplePayToken token) {
        if (token == null) {
            throw WalletDecryptionException.invalid("Apple Pay token is missing");
        }
        if (!"EC_v1".equals(token.version())) {
            throw WalletDecryptionException.unsupported("Apple Pay token version " + token.version());
        }
        ApplePayToken.Header header = token.header();
        if (token.data() == null || token.signature() == null || header == null || header.ephemeralPublicKey() == null
                || header.publicKeyHash() == null || header.transactionId() == null) {
            throw WalletDecryptionException.invalid("Apple Pay token is incomplete");
        }

        signatureVerifier.verify(token);

        PrivateKey privateKey = keysByPublicKeyHash.get(header.publicKeyHash());
        if (privateKey == null) {
            throw WalletDecryptionException.invalid("token is encrypted for another Payment Processing Certificate "
                    + "(publicKeyHash " + header.publicKeyHash() + ")");
        }

        byte[] plaintext;
        try {
            plaintext = ApplePayCrypto.decrypt(Base64.getDecoder().decode(token.data()),
                    Base64.getDecoder().decode(header.ephemeralPublicKey()), privateKey, merchantIdentifierHash);
        } catch (GeneralSecurityException | IllegalArgumentException e) {
            throw WalletDecryptionException.invalid("Apple Pay decryption failed: " + e.getClass().getSimpleName(), e);
        }

        ApplePayDecryptedData decrypted;
        try {
            decrypted = objectMapper.readValue(plaintext, ApplePayDecryptedData.class);
        } catch (JacksonException e) {
            throw WalletDecryptionException.invalid("decrypted Apple Pay data is not valid JSON");
        } finally {
            Arrays.fill(plaintext, (byte) 0);
        }
        return toCard(decrypted, header.transactionId());
    }

    static DecryptedWalletCard toCard(ApplePayDecryptedData decrypted, String transactionId) {
        if (!"3DSecure".equals(decrypted.paymentDataType())) {
            throw WalletDecryptionException.unsupported("Apple Pay paymentDataType " + decrypted.paymentDataType());
        }
        String expiry = decrypted.applicationExpirationDate();
        ApplePayDecryptedData.PaymentData paymentData = decrypted.paymentData();
        if (decrypted.applicationPrimaryAccountNumber() == null || expiry == null || expiry.length() != 6
                || paymentData == null || paymentData.onlinePaymentCryptogram() == null) {
            throw WalletDecryptionException.invalid("decrypted Apple Pay data is incomplete");
        }
        return new DecryptedWalletCard(
                WalletType.APPLE_PAY,
                AuthMethod.CRYPTOGRAM_3DS,
                decrypted.applicationPrimaryAccountNumber(),
                Integer.parseInt(expiry.substring(2, 4)),          // YYMMDD -> MM
                2000 + Integer.parseInt(expiry.substring(0, 2)),   // YYMMDD -> 20YY
                paymentData.onlinePaymentCryptogram(),
                paymentData.eciIndicator(),
                transactionId,
                decrypted.transactionAmount(),
                decrypted.currencyCode());
    }

    private ApplePayToken parseToken(String walletToken) {
        if (walletToken == null || walletToken.isBlank()) {
            throw WalletDecryptionException.invalid("Apple Pay token is missing");
        }
        try {
            String trimmed = walletToken.trim();
            String json = trimmed.startsWith("{")
                    ? trimmed
                    : new String(Base64.getMimeDecoder().decode(trimmed), StandardCharsets.UTF_8);
            return objectMapper.readValue(json, ApplePayToken.class);
        } catch (JacksonException | IllegalArgumentException e) {
            throw WalletDecryptionException.invalid("Apple Pay token is not valid JSON / base64");
        }
    }
}
