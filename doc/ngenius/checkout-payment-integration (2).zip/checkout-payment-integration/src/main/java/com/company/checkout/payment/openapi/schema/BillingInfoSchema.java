package com.company.checkout.payment.openapi.schema;

import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for payment.dto.BillingInfo (never instantiated). */
@Schema(name = "BillingInfo")
public record BillingInfoSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 60, example = "Jane")
        String firstName,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 60, example = "Doe")
        String lastName,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, format = "email", maxLength = 254,
                example = "jane@example.com")
        String email,

        @Schema(maxLength = 200, example = "Sheikh Zayed Road 1")
        String address,

        @Schema(maxLength = 60, example = "Dubai")
        String city,

        @Schema(pattern = "^[A-Z]{2}$", description = "ISO 3166-1 alpha-2", example = "AE")
        String countryCode) {
}
