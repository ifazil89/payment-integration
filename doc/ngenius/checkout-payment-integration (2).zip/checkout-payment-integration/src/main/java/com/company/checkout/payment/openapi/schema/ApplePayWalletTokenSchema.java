package com.company.checkout.payment.openapi.schema;

import io.swagger.v3.oas.annotations.media.Schema;

/** DOCUMENTATION ONLY for payment.dto.ApplePayWalletToken (never instantiated). */
@Schema(name = "ApplePayWalletToken", description = "Apple Pay PKPaymentToken.paymentData, unchanged from the device")
public record ApplePayWalletTokenSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 10, example = "EC_v1")
        String version,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 16000, description = "base64 ciphertext")
        String data,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 16000,
                description = "base64 detached PKCS#7 signature")
        String signature,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        HeaderSchema header) {

    /** DOCUMENTATION ONLY for payment.dto.ApplePayWalletToken.Header. */
    @Schema(name = "ApplePayWalletTokenHeader")
    public record HeaderSchema(

            @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 500,
                    description = "base64 X.509 SubjectPublicKeyInfo")
            String ephemeralPublicKey,

            @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 100,
                    description = "base64 SHA-256 of the merchant certificate's public key")
            String publicKeyHash,

            @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 128, description = "hex, unique per token")
            String transactionId,

            @Schema(maxLength = 128, description = "hex SHA-256 of the app's applicationData, if set")
            String applicationData) {
    }
}
