package com.company.wallet.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * The encrypted Google Pay token (ECv2): {@code paymentMethodData.tokenizationData.token}.
 * Field names are Google's JSON names: the token is written back to that JSON for Tink.
 *
 * @param signedMessage JSON as a STRING {encryptedMessage, ephemeralPublicKey, tag}; must stay exactly as received
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record GooglePayToken(String protocolVersion, String signature,
                             IntermediateSigningKey intermediateSigningKey, String signedMessage) {

    /** @param signedKey JSON as a STRING {keyValue, keyExpiration}; must stay exactly as received */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record IntermediateSigningKey(String signedKey, List<String> signatures) {
    }

    @Override
    public String toString() {
        return "GooglePayToken[protocolVersion=" + protocolVersion + ", signature=***, signedMessage=***]";
    }
}
