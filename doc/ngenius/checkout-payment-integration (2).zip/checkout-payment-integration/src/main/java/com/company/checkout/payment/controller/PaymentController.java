package com.company.checkout.payment.controller;

import com.company.checkout.common.security.ApiKeyFilter;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.dto.PaymentResponse;
import com.company.checkout.payment.openapi.PaymentApi;
import com.company.checkout.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Implements PaymentApi (payment/openapi): path, headers, @Valid and all API documentation are on the
 * interface. This class only hands over to PaymentService, with the authenticated client.
 */
@RestController
@RequiredArgsConstructor
public class PaymentController implements PaymentApi {

    private final PaymentService paymentService;

    @Override
    public ResponseEntity<PaymentResponse> createPayment(String idempotencyKey, PaymentRequest paymentRequest) {
        return ResponseEntity.ok(
                paymentService.createPayment(ApiKeyFilter.currentClientId(), idempotencyKey, paymentRequest));
    }

    @Override
    public ResponseEntity<PaymentResponse> getPayment(String paymentId) {
        return ResponseEntity.ok(paymentService.getPayment(ApiKeyFilter.currentClientId(), paymentId));
    }
}
