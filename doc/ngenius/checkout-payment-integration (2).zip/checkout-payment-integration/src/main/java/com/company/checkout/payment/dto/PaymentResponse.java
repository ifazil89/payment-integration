package com.company.checkout.payment.dto;

import com.company.checkout.common.dto.Amount;

import java.time.OffsetDateTime;

/**
 * The payment as the client sees it. Null fields are not sent.
 *
 * @param cardLast4          last 4 digits of the card, network token or wallet device card
 * @param providerPaymentId  Checkout.com payment id (pay_...), for support and reconciliation
 * @param threeDsRedirectUrl only when status = CHALLENGE_REQUIRED
 */
public record PaymentResponse(
        String paymentId,
        String merchantOrderId,
        PaymentMethodType paymentMethod,
        PaymentStatus status,
        Amount amount,
        String cardScheme,
        String cardLast4,
        String providerPaymentId,
        String threeDsRedirectUrl,
        String failureReason,
        OffsetDateTime createdAt,
        OffsetDateTime updatedAt) {
}
