package com.company.checkout.payment.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

/**
 * How the shopper pays. Fill in exactly the part that belongs to the type:
 *
 *   { "type": "CARD",          "card":           { "number": .., "expiryMonth": .., "expiryYear": .., "cvv": .. } }
 *   { "type": "NETWORK_TOKEN", "networkToken":   { "token": .., "tokenType": "VTS", .., "cryptogram": .. } }
 *   { "type": "APPLE_PAY",     "walletToken":    { "version": "EC_v1", "data": .., "signature": .., "header": {..} } }
 *   { "type": "GOOGLE_PAY",    "googlePayToken": { "protocolVersion": "ECv2", "signature": .., "intermediateSigningKey": {..},
 *                                                  "signedMessage": ".." } }
 *
 * "Exactly the right part" is checked in PaymentMethodResolver (field errors like the annotations).
 *
 * @param walletToken    APPLE_PAY: PKPaymentToken.paymentData as an object, unchanged from the device
 * @param googlePayToken GOOGLE_PAY: tokenizationData.token as an object, unchanged from Google
 */
public record PaymentMethod(
        @NotNull PaymentMethodType type,
        @Valid CardDetails card,
        @Valid NetworkTokenDetails networkToken,
        @Valid ApplePayWalletToken walletToken,
        @Valid GooglePayWalletToken googlePayToken) {

    /** Never prints card data or wallet token content. */
    @Override
    public String toString() {
        return "PaymentMethod[type=" + type + ", card=" + card + ", networkToken=" + networkToken
                + ", walletToken=" + walletToken + ", googlePayToken=" + googlePayToken + "]";
    }
}
