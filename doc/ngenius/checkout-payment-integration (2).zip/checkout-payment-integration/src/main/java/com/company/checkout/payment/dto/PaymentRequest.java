package com.company.checkout.payment.dto;

import com.company.checkout.common.dto.Amount;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * POST /api/v1/payments. No documentation annotations here: the API docs come from
 * payment/openapi/schema/PaymentRequestSchema (DocSchemaTest keeps the two the same).
 */
public record PaymentRequest(
        @NotBlank @Size(max = 64) String merchantOrderId,
        @NotNull @Valid PaymentMethod paymentMethod,
        @NotNull @Valid Amount amount,
        @NotNull @Valid BillingInfo billingInfo) {

    /** PaymentMethod.toString already hides card data and the wallet token. */
    @Override
    public String toString() {
        return "PaymentRequest[merchantOrderId=" + merchantOrderId + ", paymentMethod=" + paymentMethod
                + ", amount=" + amount + "]";
    }
}
