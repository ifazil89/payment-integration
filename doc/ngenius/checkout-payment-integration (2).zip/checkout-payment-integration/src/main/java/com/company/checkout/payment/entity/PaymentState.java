package com.company.checkout.payment.entity;

import java.util.Locale;

/**
 * Internal state of a payment (stored). Shown to clients as PaymentStatus (CREATED = PENDING).
 */
public enum PaymentState {

    CREATED,              // saved; Checkout.com has not answered (yet)
    PENDING,              // Checkout.com: Pending, no challenge
    CHALLENGE_REQUIRED,   // Checkout.com: Pending + 3DS redirect (Google Pay PAN_ONLY)
    APPROVED,             // Authorized: capture follows automatically
    CAPTURED,
    DECLINED,
    FAILED,
    CANCELLED,
    REFUNDED;

    /** GET /payments/{id} asks Checkout.com again only while the outcome can still change. */
    public boolean needsRefresh() {
        return this == CREATED || this == PENDING || this == CHALLENGE_REQUIRED || this == APPROVED;
    }

    /**
     * Checkout.com payment status -> our state. null = unknown status: keep the current state (logged).
     * A Pending payment with a redirect link is waiting for the shopper's 3DS challenge.
     */
    public static PaymentState fromCko(String ckoStatus, boolean hasRedirect) {
        if (ckoStatus == null) {
            return null;
        }
        return switch (ckoStatus.toLowerCase(Locale.ROOT)) {
            case "authorized", "card verified" -> APPROVED;
            case "captured", "partially captured", "paid" -> CAPTURED;
            case "pending" -> hasRedirect ? CHALLENGE_REQUIRED : PENDING;
            case "declined" -> DECLINED;
            case "voided", "canceled", "cancelled" -> CANCELLED;
            case "refunded", "partially refunded" -> REFUNDED;
            case "expired" -> FAILED;
            default -> null;
        };
    }
}
