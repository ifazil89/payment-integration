package com.company.wallet.spring;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.time.Duration;
import java.util.List;

/**
 * "wallet.apple-pay.*"
 *
 * File locations (rootCaCertificate, keys[].keystore) can be:
 *   "AppleRootCA-G3.cer"            a plain file name -> looked up in certificateDir
 *   "/opt/certs/apple-pay.p12"      an absolute path
 *   "file:/..." / "classpath:..."   as written
 *
 * @param certificateDir      folder on the server with the Apple Pay files (.p12, Apple root CA)
 * @param merchantIdentifier  the Apple merchant id, e.g. merchant.com.company.shop
 * @param rootCaCertificate   Apple Root CA - G3
 * @param maxTokenAge         tokens signed longer ago are rejected
 * @param keys                Payment Processing Certificates + their private keys (two during a rotation)
 */
@ConfigurationProperties("wallet.apple-pay")
public record ApplePayProperties(
        @DefaultValue("true") boolean enabled,
        String certificateDir,
        String merchantIdentifier,
        @DefaultValue("AppleRootCA-G3.cer") String rootCaCertificate,
        @DefaultValue("5m") Duration maxTokenAge,
        List<Key> keys) {

    public List<Key> keys() {
        return keys == null ? List.of() : keys;
    }

    /**
     * One Payment Processing Certificate + its private key. Set EITHER the .p12 OR certificate + private-key.
     *
     * @param keystore         .p12 file (see the locations above)
     * @param keystorePassword password of the .p12 (also used for the key inside it)
     * @param alias            entry in the .p12; empty = the first entry with a private key
     * @param certificate      base64 DER (or PEM) of the Payment Processing Certificate from Apple
     * @param privateKey       base64 (or PEM) PKCS#8 EC P-256 private key that belongs to it
     */
    public record Key(String keystore, String keystorePassword, String alias, String certificate, String privateKey) {

        public boolean isKeystore() {
            return keystore != null && !keystore.isBlank();
        }

        public boolean isEmpty() {
            return !isKeystore() && (certificate == null || certificate.isBlank())
                    && (privateKey == null || privateKey.isBlank());
        }

        @Override
        public String toString() {
            return "Key[keystore=" + keystore + ", alias=" + alias + ", keystorePassword=***, privateKey=***]";
        }
    }
}
