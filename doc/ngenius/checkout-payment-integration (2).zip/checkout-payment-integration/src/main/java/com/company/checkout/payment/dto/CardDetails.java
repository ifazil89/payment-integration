package com.company.checkout.payment.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * A plain card (paymentMethod.type = CARD). Lives only in memory: never stored, never logged
 * (toString shows last 4 digits; the log masker hides paymentMethod.card.number / .cvv).
 * Luhn check and "not expired" are in PaymentMethodResolver.
 */
public record CardDetails(
        @NotBlank @Pattern(regexp = "\\d{12,19}", message = "must be 12-19 digits") String number,
        @NotNull @Min(1) @Max(12) Integer expiryMonth,
        @NotNull @Min(2000) @Max(2099) Integer expiryYear,
        @NotBlank @Pattern(regexp = "\\d{3,4}", message = "must be 3 or 4 digits") String cvv,
        @Size(max = 100) String name) {

    public String last4() {
        return number == null || number.length() < 4 ? null : number.substring(number.length() - 4);
    }

    @Override
    public String toString() {
        return "CardDetails[number=****" + last4() + ", expiry=" + expiryMonth + "/" + expiryYear + ", cvv=***]";
    }
}
