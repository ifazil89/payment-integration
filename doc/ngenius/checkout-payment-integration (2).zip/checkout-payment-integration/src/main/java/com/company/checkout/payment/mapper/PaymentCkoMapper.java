package com.company.checkout.payment.mapper;

import com.company.checkout.cko.config.CkoProperties;
import com.company.checkout.cko.dto.CkoAddress;
import com.company.checkout.cko.dto.CkoCustomer;
import com.company.checkout.cko.dto.CkoPaymentRequest;
import com.company.checkout.cko.dto.CkoPaymentResponse;
import com.company.checkout.cko.dto.CkoSource;
import com.company.checkout.cko.dto.CkoThreeDs;
import com.company.checkout.payment.dto.BillingInfo;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.entity.ProviderResult;
import com.company.checkout.payment.service.ResolvedPaymentMethod;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Map;

/**
 * Our request + resolved payment method -> Checkout.com POST /payments body, and Checkout.com's answer ->
 * ProviderResult. MapStruct generates the field mappings; the source choice is written out by hand.
 */
@Mapper
public interface PaymentCkoMapper {

    /**
     * network token (NETWORK_TOKEN, Apple Pay, Google Pay CRYPTOGRAM_3DS) -> network_token source + cryptogram.
     * card (CARD, Google Pay PAN_ONLY) -> card source (cvv for CARD).
     * 3DS with success/failure URLs when method.threeDs() (decided by PaymentMethodResolver).
     */
    default CkoPaymentRequest toPaymentRequest(PaymentRequest request, ResolvedPaymentMethod method, String paymentId,
                                               long amountMinor, CkoProperties properties) {
        CkoAddress address = toAddress(request.billingInfo());
        CkoSource source = method.isNetworkToken()
                ? CkoSource.networkToken(method.number(), method.tokenType(), method.expiryMonth(), method.expiryYear(),
                        method.cryptogram(), method.eci(), address)
                : CkoSource.card(method.number(), method.expiryMonth(), method.expiryYear(), method.cvv(),
                        method.cardholderName() != null ? method.cardholderName() : fullName(request.billingInfo()),
                        address);
        boolean threeDs = method.threeDs();
        return new CkoPaymentRequest(
                source,
                amountMinor,
                request.amount().currency(),
                request.merchantOrderId(),
                properties.capture(),
                properties.processingChannelId(),
                "Regular",
                toCustomer(request.billingInfo()),
                threeDs ? new CkoThreeDs(true) : null,
                threeDs ? properties.threeDsSuccessUrl(paymentId) : null,
                threeDs ? properties.threeDsFailureUrl(paymentId) : null,
                Map.of("payment_id", paymentId, "payment_method", method.type().name()));
    }

    @Mapping(target = "addressLine1", source = "address")
    @Mapping(target = "zip", ignore = true)
    @Mapping(target = "country", source = "countryCode")
    CkoAddress toAddress(BillingInfo billingInfo);

    @Mapping(target = "name", expression = "java(fullName(billingInfo))")
    CkoCustomer toCustomer(BillingInfo billingInfo);

    @Mapping(target = "providerPaymentId", source = "id")
    @Mapping(target = "redirectUrl", expression = "java(response.redirectUrl().orElse(null))")
    @Mapping(target = "cardScheme", source = "source.scheme")
    @Mapping(target = "cardLast4", source = "source.last4")
    ProviderResult toResult(CkoPaymentResponse response);

    default String fullName(BillingInfo billingInfo) {
        return billingInfo == null ? null : (billingInfo.firstName() + " " + billingInfo.lastName()).trim();
    }
}
