package com.company.checkout.payment.openapi.schema;

import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/** DOCUMENTATION ONLY for payment.dto.GooglePayWalletToken (never instantiated). */
@Schema(name = "GooglePayWalletToken",
        description = "Google Pay tokenizationData.token (ECv2) as a JSON object, unchanged from Google")
public record GooglePayWalletTokenSchema(

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 10, example = "ECv2")
        String protocolVersion,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 1000, description = "base64 signature")
        String signature,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
        IntermediateSigningKeySchema intermediateSigningKey,

        @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 20000,
                description = "JSON as a string {encryptedMessage, ephemeralPublicKey, tag}; send exactly as received")
        String signedMessage) {

    /** DOCUMENTATION ONLY for payment.dto.GooglePayWalletToken.IntermediateSigningKey. */
    @Schema(name = "GooglePayIntermediateSigningKey")
    public record IntermediateSigningKeySchema(

            @Schema(requiredMode = Schema.RequiredMode.REQUIRED, maxLength = 2000,
                    description = "JSON as a string {keyValue, keyExpiration}; send exactly as received")
            String signedKey,

            @Schema(requiredMode = Schema.RequiredMode.REQUIRED,
                    description = "base64 signatures of signedKey by Google's root keys")
            List<String> signatures) {
    }
}
