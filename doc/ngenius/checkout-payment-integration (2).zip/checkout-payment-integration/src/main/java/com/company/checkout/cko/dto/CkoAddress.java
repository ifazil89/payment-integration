package com.company.checkout.cko.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/** Billing address, sent inside the payment source. country = ISO 3166-1 alpha-2. */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record CkoAddress(
        @JsonProperty("address_line1") String addressLine1,
        @JsonProperty("city") String city,
        @JsonProperty("zip") String zip,
        @JsonProperty("country") String country) {
}
