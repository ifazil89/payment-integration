package com.company.checkout.architecture;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Keeps com.company.wallet movable to its own project (docs/WALLET-LIBRARY.md). Plain source check, no extra
 * dependency: reads every .java file under src/main/java and src/test/java, ignores comments, and fails on
 * a forbidden package reference (import, static import or fully qualified name).
 *
 *   1. the wallet library never uses the application:      com.company.wallet.. -X-> com.company.checkout..
 *   2. only wallet "spring" uses Spring:                    com.company.wallet.(api|applepay|googlepay|keys).. -X-> org.springframework..
 *   3. the wallet library uses no Lombok and no app stack:  com.company.wallet.. -X-> lombok, jakarta.persistence, jakarta.servlet
 *   4. the application uses only the public API:            com.company.checkout.. -> com.company.wallet.api.. only
 *   5. the wallet is loaded like a library (auto-configuration file lists WalletAutoConfiguration)
 */
class WalletBoundaryTest {

    private static final List<Path> SOURCE_ROOTS = List.of(Path.of("src/main/java"), Path.of("src/test/java"));
    private static final String WALLET = "com/company/wallet/";
    private static final String CHECKOUT = "com/company/checkout/";

    private static final Pattern BLOCK_COMMENT = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
    private static final Pattern LINE_COMMENT = Pattern.compile("//[^\\n]*");
    private static final Pattern STRING_LITERAL = Pattern.compile("\"(?:\\\\.|[^\"\\\\])*\"");
    private static final Pattern WALLET_PACKAGE = Pattern.compile("\\bcom\\.company\\.wallet\\.(\\w+)");

    @Test
    void walletDoesNotUseTheApplication() {
        assertThat(violations(WALLET, null, Pattern.compile("\\bcom\\.company\\.checkout\\b")))
                .as("com.company.wallet must not use com.company.checkout (it becomes a separate library)")
                .isEmpty();
    }

    @Test
    void onlyWalletSpringUsesSpring() {
        assertThat(violations(WALLET, WALLET + "spring/", Pattern.compile("\\borg\\.springframework\\b")))
                .as("Spring is allowed only in com.company.wallet.spring (the future starter); "
                        + "api / applepay / googlepay / keys are plain Java (the future core module)")
                .isEmpty();
    }

    @Test
    void walletUsesNoLombokAndNoApplicationStack() {
        assertThat(violations(WALLET, null,
                Pattern.compile("\\blombok\\b|\\bjakarta\\.persistence\\b|\\bjakarta\\.servlet\\b")))
                .as("the wallet library must not need Lombok, JPA or the servlet API")
                .isEmpty();
    }

    @Test
    void applicationUsesOnlyTheWalletApi() {
        List<String> problems = new ArrayList<>();
        forEachSource(CHECKOUT, null, (file, code) -> {
            Matcher m = WALLET_PACKAGE.matcher(code);
            while (m.find()) {
                if (!m.group(1).equals("api")) {
                    problems.add(file + ": uses com.company.wallet." + m.group(1));
                }
            }
        });
        assertThat(problems)
                .as("com.company.checkout may use only com.company.wallet.api; configure the rest with wallet.* properties")
                .isEmpty();
    }

    @Test
    void walletIsRegisteredAsAutoConfiguration() throws IOException {
        Path imports = Path.of("src/main/resources/META-INF/spring/"
                + "org.springframework.boot.autoconfigure.AutoConfiguration.imports");
        assertThat(imports).exists();
        assertThat(Files.readAllLines(imports)).contains("com.company.wallet.spring.WalletAutoConfiguration");
    }

    // ------------------------------------------------------------------

    private interface SourceVisitor {
        void visit(String file, String codeWithoutComments);
    }

    /** Files under {@code area} (minus {@code exceptArea}) whose code (comments removed) matches {@code forbidden}. */
    private static List<String> violations(String area, String exceptArea, Pattern forbidden) {
        List<String> problems = new ArrayList<>();
        forEachSource(area, exceptArea, (file, code) -> {
            Matcher m = forbidden.matcher(code);
            if (m.find()) {
                problems.add(file + ": uses " + m.group());
            }
        });
        return problems;
    }

    private static void forEachSource(String area, String exceptArea, SourceVisitor visitor) {
        for (Path root : SOURCE_ROOTS) {
            Path dir = root.resolve(area);
            if (!Files.isDirectory(dir)) {
                continue;
            }
            try (Stream<Path> files = Files.walk(dir)) {
                files.filter(f -> f.toString().endsWith(".java")).forEach(file -> {
                    String relative = root.relativize(file).toString().replace('\\', '/');
                    if (exceptArea != null && relative.startsWith(exceptArea)) {
                        return;
                    }
                    visitor.visit(root.resolve(relative).toString(), code(file));
                });
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }
    }

    /** Source without comments and string contents, so documentation and messages may mention anything. */
    private static String code(Path file) {
        try {
            String source = Files.readString(file);
            source = STRING_LITERAL.matcher(source).replaceAll("\"\"");
            source = BLOCK_COMMENT.matcher(source).replaceAll(" ");
            return LINE_COMMENT.matcher(source).replaceAll(" ");
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
