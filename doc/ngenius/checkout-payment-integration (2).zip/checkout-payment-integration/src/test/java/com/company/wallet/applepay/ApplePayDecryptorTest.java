package com.company.wallet.applepay;

import com.company.wallet.api.ApplePayToken;
import com.company.wallet.api.AuthMethod;
import com.company.wallet.api.DecryptedWalletCard;
import com.company.wallet.api.WalletDecryptionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

import javax.crypto.AEADBadTagException;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.spec.ECGenParameterSpec;
import java.util.Base64;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

/**
 * Apple Pay EC_v1 decryption with a token built here the way Apple builds it (ECDH + KDF + AES-GCM,
 * written independently of ApplePayCrypto). The signature check is mocked: it needs Apple-signed
 * certificates; it is exercised with real sandbox tokens (README, "Testing with real wallets").
 */
class ApplePayDecryptorTest {

    private static final String MERCHANT_ID = "merchant.com.company.shop";
    private static final String DECRYPTED = """
            {"applicationPrimaryAccountNumber":"4817499999999999","applicationExpirationDate":"301231",
             "currencyCode":"784","transactionAmount":25000,"deviceManufacturerIdentifier":"040010030273",
             "paymentDataType":"3DSecure",
             "paymentData":{"onlinePaymentCryptogram":"AOrEWbIACBzFTkgXZ1aWAoABFA==","eciIndicator":"7"}}""";

    private final ApplePaySignatureVerifier verifier = mock(ApplePaySignatureVerifier.class);
    private KeyPair merchant;
    private KeyPairGenerator generator;
    private ApplePayDecryptor decryptor;

    @BeforeEach
    void setUp() throws Exception {
        generator = KeyPairGenerator.getInstance("EC");
        generator.initialize(new ECGenParameterSpec("secp256r1"));
        merchant = generator.generateKeyPair();
        decryptor = new ApplePayDecryptor(verifier,
                Map.of(ApplePayCrypto.publicKeyHash(merchant.getPublic()), merchant.getPrivate()),
                ApplePayCrypto.merchantIdentifierHash(MERCHANT_ID), JsonMapper.builder().build());
    }

    @Test
    void decryptsApplePayToken() throws Exception {
        DecryptedWalletCard card = decryptor.decrypt(token(DECRYPTED, merchant.getPublic(), MERCHANT_ID));

        assertThat(card.pan()).isEqualTo("4817499999999999");
        assertThat(card.expiryMonth()).isEqualTo(12);
        assertThat(card.expiryYear()).isEqualTo(2030);
        assertThat(card.cryptogram()).isEqualTo("AOrEWbIACBzFTkgXZ1aWAoABFA==");
        assertThat(card.eci()).isEqualTo("7");
        assertThat(card.authMethod()).isEqualTo(AuthMethod.CRYPTOGRAM_3DS);
        assertThat(card.amountMinor()).isEqualTo(25000L);
        assertThat(card.currencyNumeric()).isEqualTo("784");
        assertThat(card.walletTransactionId()).isEqualTo("c1caf5ae72f0039a82bad92b828363734f85bf2f9cadf193d1bad9ddcb60a795");
        assertThat(card.toString()).doesNotContain("4817499999999999", "AOrEWb");
    }

    @Test
    void acceptsTheTokenAsAnObject() throws Exception {
        ApplePayToken token = JsonMapper.builder().build()
                .readValue(token(DECRYPTED, merchant.getPublic(), MERCHANT_ID), ApplePayToken.class);

        DecryptedWalletCard card = decryptor.decrypt(token);

        assertThat(card.pan()).isEqualTo("4817499999999999");
        assertThat(token.toString()).doesNotContain(token.data());
    }

    @Test
    void missingTokenIsInvalid() {
        assertThatThrownBy(() -> decryptor.decrypt((ApplePayToken) null))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_INVALID");
        assertThatThrownBy(() -> decryptor.decrypt(" "))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_INVALID");
    }

    @Test
    void acceptsBase64EncodedToken() throws Exception {
        String json = token(DECRYPTED, merchant.getPublic(), MERCHANT_ID);
        String base64 = Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));

        assertThat(decryptor.decrypt(base64).pan()).isEqualTo("4817499999999999");
    }

    @Test
    void tokenForAnotherCertificateIsRejected() throws Exception {
        KeyPair other = generator.generateKeyPair();

        assertThatThrownBy(() -> decryptor.decrypt(token(DECRYPTED, other.getPublic(), MERCHANT_ID)))
                .isInstanceOf(WalletDecryptionException.class)
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_INVALID")
                .hasMessageContaining("another Payment Processing Certificate");
    }

    @Test
    void wrongMerchantIdentifierFailsDecryption() throws Exception {
        assertThatThrownBy(() -> decryptor.decrypt(token(DECRYPTED, merchant.getPublic(), "merchant.someone.else")))
                .isInstanceOf(WalletDecryptionException.class)
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_INVALID")
                .hasRootCauseInstanceOf(AEADBadTagException.class);
    }

    @Test
    void failedSignatureStopsBeforeDecryption() throws Exception {
        doThrow(WalletDecryptionException.invalid("signature does not match")).when(verifier).verify(any());

        assertThatThrownBy(() -> decryptor.decrypt(token(DECRYPTED, merchant.getPublic(), MERCHANT_ID)))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_INVALID")
                .hasMessage("signature does not match");
    }

    @Test
    void rsaAndEmvTokensAreNotSupported() throws Exception {
        assertThatThrownBy(() -> decryptor.decrypt("{\"version\":\"RSA_v1\"}"))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_UNSUPPORTED");

        String emv = DECRYPTED.replace("3DSecure", "EMV");
        assertThatThrownBy(() -> decryptor.decrypt(token(emv, merchant.getPublic(), MERCHANT_ID)))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_UNSUPPORTED");
    }

    @Test
    void garbageIsInvalid() {
        assertThatThrownBy(() -> decryptor.decrypt("not a token"))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_INVALID");
    }

    // ------------------------------------------------------------------ Apple's side, written independently

    private String token(String plaintext, PublicKey recipient, String merchantIdentifier) throws Exception {
        KeyPair ephemeral = generator.generateKeyPair();
        KeyAgreement agreement = KeyAgreement.getInstance("ECDH");
        agreement.init(ephemeral.getPrivate());
        agreement.doPhase(recipient, true);
        byte[] sharedSecret = agreement.generateSecret();

        MessageDigest kdf = MessageDigest.getInstance("SHA-256");
        kdf.update(new byte[]{0, 0, 0, 1});
        kdf.update(sharedSecret);
        kdf.update((byte) 0x0D);
        kdf.update("id-aes256-GCM".getBytes(StandardCharsets.US_ASCII));
        kdf.update("Apple".getBytes(StandardCharsets.US_ASCII));
        kdf.update(MessageDigest.getInstance("SHA-256").digest(merchantIdentifier.getBytes(StandardCharsets.UTF_8)));
        byte[] key = kdf.digest();

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, new byte[16]));
        byte[] data = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));

        Base64.Encoder b64 = Base64.getEncoder();
        return """
                {"version":"EC_v1","data":"%s","signature":"%s",
                 "header":{"ephemeralPublicKey":"%s","publicKeyHash":"%s",
                           "transactionId":"c1caf5ae72f0039a82bad92b828363734f85bf2f9cadf193d1bad9ddcb60a795"}}"""
                .formatted(b64.encodeToString(data), b64.encodeToString(new byte[]{1}),
                        b64.encodeToString(ephemeral.getPublic().getEncoded()), ApplePayCrypto.publicKeyHash(recipient));
    }
}
