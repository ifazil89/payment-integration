package com.company.checkout.common.logging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** PCI DSS: no full card number, CVV, cryptogram, token or credential may ever reach a log line. */
class SensitiveDataMaskerTest {

    private static final LoggingProperties LOG_ALL = new LoggingProperties(true, 10_000);

    /** The masker exactly as the application builds it: rules from application.yml. */
    private final SensitiveDataMasker masker = new SensitiveDataMasker(LOG_ALL, shippedRules());

    private static SensitiveDataMasker withRules(MaskingProperties.Rule... rules) {
        return new SensitiveDataMasker(LOG_ALL, new MaskingProperties(List.of(rules), List.of()));
    }

    private static MaskingProperties.Rule rule(String path, MaskStrategy strategy) {
        return new MaskingProperties.Rule(path, strategy);
    }

    // ------------------------------------------------------------------ path rules

    @Test
    void masksExactlyTheConfiguredPath() {
        SensitiveDataMasker m = withRules(rule("payment.card.number", MaskStrategy.PAN));

        String masked = m.maskJson("""
                {"payment":{"card":{"number":"4111111111111111","name":"Jane"}},"order":{"number":"4111111111111111"}}""");

        assertThat(masked).isEqualTo("""
                {"payment":{"card":{"number":"411111******1111","name":"Jane"}},"order":{"number":"4111111111111111"}}""");
    }

    @Test
    void wildcardsArraysAndCase() {
        SensitiveDataMasker m = withRules(
                rule("*.card.number", MaskStrategy.LAST4),          // one level: x.card.number
                rule("orders.items.serial", MaskStrategy.FULL),     // arrays are transparent
                rule("**.secret", MaskStrategy.FULL));               // any depth

        assertThat(m.maskJson("{\"x\":{\"Card\":{\"NUMBER\":\"5555555555554444\"}},\"card\":{\"number\":\"1\"}}"))
                .isEqualTo("{\"x\":{\"Card\":{\"NUMBER\":\"****4444\"}},\"card\":{\"number\":\"1\"}}");
        assertThat(m.maskJson("{\"orders\":[{\"items\":[{\"serial\":\"A1\"},{\"serial\":\"B2\"}]}]}"))
                .isEqualTo("{\"orders\":[{\"items\":[{\"serial\":\"***\"},{\"serial\":\"***\"}]}]}");
        assertThat(m.maskJson("{\"secret\":1,\"a\":{\"b\":{\"secret\":{\"deep\":[1,2]}}}}"))
                .isEqualTo("{\"secret\":\"***\",\"a\":{\"b\":{\"secret\":\"***\"}}}");
    }

    @Test
    void bracketSyntaxIsAccepted() {
        assertThat(withRules(rule("items[*].card.number", MaskStrategy.PAN))
                .maskJson("{\"items\":[{\"card\":{\"number\":\"4111111111111111\"}}]}"))
                .contains("411111******1111");
    }

    @Test
    void strategies() {
        assertThat(MaskStrategy.PAN.apply("4111 1111 1111 1111")).isEqualTo("411111******1111");
        assertThat(MaskStrategy.PAN.apply("12345")).isEqualTo("***");
        assertThat(MaskStrategy.LAST4.apply("pay_abcdefgh1234")).isEqualTo("****1234");
        assertThat(MaskStrategy.EMAIL.apply("jane@example.com")).isEqualTo("j***@example.com");
        assertThat(MaskStrategy.FULL.apply("anything")).isEqualTo("***");
    }

    @Test
    void baselineAlwaysApplies() {
        SensitiveDataMasker noRules = new SensitiveDataMasker(LOG_ALL, new MaskingProperties(null, null));

        assertThat(noRules.maskJson("""
                {"a":{"cvv":"123"},"b":[{"cryptogram":"AgAA"}],"walletToken":"x","pan":"4111111111111111","cvc":null}"""))
                .isEqualTo("""
                        {"a":{"cvv":"***"},"b":[{"cryptogram":"***"}],"walletToken":"***","pan":"411111******1111","cvc":null}""");
    }

    @Test
    void invalidRulesFailAtStartup() {
        assertThatThrownBy(() -> withRules(rule("a..b", MaskStrategy.FULL))).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> withRules(rule(" ", MaskStrategy.FULL))).isInstanceOf(IllegalArgumentException.class);
    }

    // ------------------------------------------------------------------ the shipped rules on our real payloads

    @Test
    void ourCardRequest() {
        String masked = masker.maskJson("""
                {"merchantOrderId":"SO-1","paymentMethod":{"type":"CARD","card":{"number":"4242424242424242",
                 "expiryMonth":12,"expiryYear":2030,"cvv":"737","name":"Jane"}},
                 "billingInfo":{"firstName":"Jane","email":"jane@example.com"}}""");

        assertThat(masked)
                .contains("\"number\":\"424242******4242\"", "\"cvv\":\"***\"", "\"expiryMonth\":12",
                        "\"email\":\"j***@example.com\"", "\"merchantOrderId\":\"SO-1\"")
                .doesNotContain("4242424242424242", "737", "jane@example.com");
    }

    @Test
    void ourNetworkTokenAndWalletRequests() {
        assertThat(masker.maskJson("""
                {"paymentMethod":{"type":"NETWORK_TOKEN","networkToken":{"token":"4543474002249996","tokenType":"VTS",
                 "cryptogram":"AhJ3hnYAoAbVz5zg1e17MAACAAA=","eci":"05"}}}"""))
                .contains("454347******9996", "\"cryptogram\":\"***\"", "\"eci\":\"05\"")
                .doesNotContain("4543474002249996", "AhJ3hnYA");

        String wallet = "{\"paymentMethod\":{\"type\":\"APPLE_PAY\",\"walletToken\":\"{\\\"data\\\":\\\"QUJD\\\"}\"}}";
        assertThat(masker.maskJson(wallet)).isEqualTo("{\"paymentMethod\":{\"type\":\"APPLE_PAY\",\"walletToken\":\"***\"}}");

        // tokens sent as JSON objects are replaced whole
        assertThat(masker.maskJson("""
                {"paymentMethod":{"type":"APPLE_PAY","walletToken":{"version":"EC_v1","data":"QUJD","signature":"U0lH",
                 "header":{"transactionId":"a1"}}}}"""))
                .isEqualTo("""
                        {"paymentMethod":{"type":"APPLE_PAY","walletToken":"***"}}""");
        assertThat(masker.maskJson("""
                {"paymentMethod":{"type":"GOOGLE_PAY","googlePayToken":{"protocolVersion":"ECv2","signature":"R1NJRw==",
                 "signedMessage":"{\\"encryptedMessage\\":\\"RU5D\\"}"}}}"""))
                .isEqualTo("""
                        {"paymentMethod":{"type":"GOOGLE_PAY","googlePayToken":"***"}}""");
    }

    @Test
    void checkoutRequestSources() {
        assertThat(masker.maskJson("""
                {"source":{"type":"card","number":"4242424242424242","cvv":"737","expiry_month":12},
                 "customer":{"email":"jane@example.com"},"reference":"SO-1"}"""))
                .contains("424242******4242", "\"cvv\":\"***\"", "\"expiry_month\":12", "j***@example.com", "SO-1")
                .doesNotContain("4242424242424242", "737");

        assertThat(masker.maskJson("""
                {"source":{"type":"network_token","token":"4817499999999999","token_type":"applepay",
                 "cryptogram":"AOrEWbIACBzF","eci":"07"}}"""))
                .contains("481749******9999", "\"cryptogram\":\"***\"", "\"eci\":\"07\"", "applepay")
                .doesNotContain("4817499999999999", "AOrEWbIACBzF");
    }

    // ------------------------------------------------------------------ unsafe input

    @Test
    void numbersEscapesAndFormattingSurvive() {
        assertThat(masker.maskJson("{ \"source\" : { \"number\" : 4111111111111111 } }"))
                .isEqualTo("{ \"source\" : { \"number\" : \"411111******1111\" } }");
        assertThat(masker.maskJson("{\"source\":{\"cvv\":\"1\\\"2\"},\"x\":[true,null,-1.5e3]}"))
                .isEqualTo("{\"source\":{\"cvv\":\"***\"},\"x\":[true,null,-1.5e3]}");
    }

    @Test
    void brokenJsonIsNeverLogged() {
        assertThat(masker.maskJson("{\"source\":{\"number\":\"41111111111"))     // body cut mid-value
                .startsWith("[invalid JSON").doesNotContain("41111111111");
        assertThat(masker.maskJson("{\"a\":1} {\"number\":\"4111111111111111\"}")).startsWith("[invalid JSON");
        assertThat(masker.maskJson("[".repeat(100) + "]".repeat(100))).startsWith("[invalid JSON");   // too deep
    }

    @Test
    void cardNumbersInPlainTextAreScrubbed() {
        assertThat(masker.mask("card=4111 1111 1111 1111&amount=1000")).isEqualTo("card=411111******1111&amount=1000");
    }

    // ------------------------------------------------------------------ headers and body

    @Test
    void masksSecretHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer secret");
        headers.add("X-Api-Key", "sandbox-key");
        headers.add("traceparent", "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01");

        assertThat(masker.headers(headers))
                .contains("Authorization=***", "X-Api-Key=***", "traceparent=00-4bf92f")
                .doesNotContain("secret", "sandbox-key");
        assertThat(new SensitiveDataMasker(LOG_ALL, new MaskingProperties(null, List.of("X-Partner-Token")))
                .headerValue("x-partner-token", "abc")).isEqualTo("***");
    }

    @Test
    void bodyIsTruncatedAndBinaryIsNotLogged() {
        byte[] json = "{\"source\":{\"number\":\"4111111111111111\"},\"long\":\"xxxxxxxxxxxxxxxxxxxxxx\"}"
                .getBytes(StandardCharsets.UTF_8);

        assertThat(new SensitiveDataMasker(new LoggingProperties(true, 40), shippedRules()).body(json, "application/json"))
                .contains("411111******1111").contains("[truncated");
        assertThat(masker.body(new byte[]{1, 2}, "image/png")).isEqualTo("[2 bytes image/png]");
        assertThat(new SensitiveDataMasker(new LoggingProperties(false, 30), shippedRules()).body(json, "application/json"))
                .isEqualTo("[not logged]");
    }

    // ------------------------------------------------------------------

    /** app.logging.masking from src/main/resources/application.yml, bound like Spring Boot does. */
    private static MaskingProperties shippedRules() {
        try {
            var sources = new YamlPropertySourceLoader().load("application", new ClassPathResource("application.yml"));
            return new Binder(ConfigurationPropertySources.from(sources))
                    .bind("app.logging.masking", MaskingProperties.class)
                    .orElseThrow(() -> new IllegalStateException("app.logging.masking missing in application.yml"));
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }
}
