package com.company.checkout.payment;

import com.company.checkout.cko.config.CkoProperties;
import com.company.checkout.cko.dto.CkoPaymentRequest;
import com.company.checkout.cko.dto.CkoPaymentResponse;
import com.company.checkout.common.dto.Amount;
import com.company.checkout.payment.dto.BillingInfo;
import com.company.checkout.payment.dto.PaymentMethod;
import com.company.checkout.payment.dto.PaymentMethodType;
import com.company.checkout.payment.dto.PaymentRequest;
import com.company.checkout.payment.dto.PaymentStatus;
import com.company.checkout.payment.entity.Payment;
import com.company.checkout.payment.entity.PaymentState;
import com.company.checkout.payment.entity.ProviderResult;
import com.company.checkout.payment.mapper.PaymentCkoMapper;
import com.company.checkout.payment.mapper.PaymentMapper;
import com.company.checkout.payment.service.ResolvedPaymentMethod;
import com.company.wallet.api.AuthMethod;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/** The MapStruct mappers and the Checkout.com status rules, without Spring. */
class PaymentMappersTest {

    private final PaymentMapper paymentMapper = Mappers.getMapper(PaymentMapper.class);
    private final PaymentCkoMapper ckoMapper = Mappers.getMapper(PaymentCkoMapper.class);
    private final CkoProperties properties = new CkoProperties("https://x.api.sandbox.checkout.com", "sk_sbox_x", "pc_1",
            true, "https://shop/{paymentId}/ok", "https://shop/{paymentId}/fail", true, Duration.ofSeconds(3),
            Duration.ofSeconds(20), Duration.ofSeconds(1), 100);

    private static PaymentRequest request(PaymentMethodType type) {
        return new PaymentRequest("SO-1", new PaymentMethod(type, null, null, null, null),
                new Amount(new BigDecimal("250.00"), "AED"),
                new BillingInfo("Jane", "Doe", "jane@example.com", "Street 1", "Dubai", "AE"));
    }

    @Test
    void applePayBecomesNetworkTokenWithoutThreeDs() {
        ResolvedPaymentMethod card = new ResolvedPaymentMethod(PaymentMethodType.APPLE_PAY, AuthMethod.CRYPTOGRAM_3DS,
                "4817499999999999", 12, 2030, null, "AOrEWb==", "07", "applepay", null, false, "txn", 25000L, "784");

        CkoPaymentRequest cko = ckoMapper.toPaymentRequest(request(PaymentMethodType.APPLE_PAY), card, "p-1", 25000L, properties);

        assertThat(cko.source().type()).isEqualTo("network_token");
        assertThat(cko.source().tokenType()).isEqualTo("applepay");
        assertThat(cko.source().cryptogram()).isEqualTo("AOrEWb==");
        assertThat(cko.source().billingAddress().addressLine1()).isEqualTo("Street 1");
        assertThat(cko.source().billingAddress().country()).isEqualTo("AE");
        assertThat(cko.customer().name()).isEqualTo("Jane Doe");
        assertThat(cko.capture()).isTrue();
        assertThat(cko.threeDs()).isNull();
        assertThat(cko.successUrl()).isNull();
        assertThat(cko.metadata()).containsEntry("payment_id", "p-1").containsEntry("payment_method", "APPLE_PAY");
    }

    @Test
    void googlePayPanOnlyBecomesCardWithThreeDs() {
        ResolvedPaymentMethod card = new ResolvedPaymentMethod(PaymentMethodType.GOOGLE_PAY, AuthMethod.PAN_ONLY,
                "4895370012003478", 12, 2028, null, null, null, null, null, true, "msg", null, null);

        CkoPaymentRequest cko = ckoMapper.toPaymentRequest(request(PaymentMethodType.GOOGLE_PAY), card, "p-2", 25000L, properties);

        assertThat(cko.source().type()).isEqualTo("card");
        assertThat(cko.source().number()).isEqualTo("4895370012003478");
        assertThat(cko.source().cvv()).isNull();
        assertThat(cko.source().name()).isEqualTo("Jane Doe");
        assertThat(cko.threeDs().enabled()).isTrue();
        assertThat(cko.successUrl()).isEqualTo("https://shop/p-2/ok");
        assertThat(cko.failureUrl()).isEqualTo("https://shop/p-2/fail");
    }

    @Test
    void plainCardBecomesCardWithCvvAndThreeDs() {
        ResolvedPaymentMethod card = new ResolvedPaymentMethod(PaymentMethodType.CARD, AuthMethod.PAN_ONLY,
                "4242424242424242", 12, 2030, "100", null, null, null, "J DOE", true, null, null, null);

        CkoPaymentRequest cko = ckoMapper.toPaymentRequest(request(PaymentMethodType.CARD), card, "p-3", 9900L, properties);

        assertThat(cko.source().type()).isEqualTo("card");
        assertThat(cko.source().number()).isEqualTo("4242424242424242");
        assertThat(cko.source().cvv()).isEqualTo("100");
        assertThat(cko.source().name()).isEqualTo("J DOE");               // card name wins over billing name
        assertThat(cko.source().token()).isNull();
        assertThat(cko.threeDs().enabled()).isTrue();
        assertThat(cko.successUrl()).isEqualTo("https://shop/p-3/ok");
        assertThat(cko.metadata()).containsEntry("payment_method", "CARD");
    }

    @Test
    void plainCardWithoutThreeDsWhenSwitchedOff() {
        ResolvedPaymentMethod card = new ResolvedPaymentMethod(PaymentMethodType.CARD, AuthMethod.PAN_ONLY,
                "4242424242424242", 12, 2030, "100", null, null, null, null, false, null, null, null);

        CkoPaymentRequest cko = ckoMapper.toPaymentRequest(request(PaymentMethodType.CARD), card, "p-4", 9900L, properties);

        assertThat(cko.source().name()).isEqualTo("Jane Doe");
        assertThat(cko.threeDs()).isNull();
        assertThat(cko.successUrl()).isNull();
    }

    @Test
    void networkTokenBecomesNetworkTokenSource() {
        ResolvedPaymentMethod token = new ResolvedPaymentMethod(PaymentMethodType.NETWORK_TOKEN,
                AuthMethod.CRYPTOGRAM_3DS, "4543474002249996", 6, 2029, null, "AhJ3hnYAoAbVz5zg1e17MAACAAA=", "05",
                "vts", null, false, null, null, null);

        CkoPaymentRequest cko = ckoMapper.toPaymentRequest(request(PaymentMethodType.NETWORK_TOKEN), token, "p-5",
                12000L, properties);

        assertThat(cko.source().type()).isEqualTo("network_token");
        assertThat(cko.source().token()).isEqualTo("4543474002249996");
        assertThat(cko.source().tokenType()).isEqualTo("vts");
        assertThat(cko.source().cryptogram()).isEqualTo("AhJ3hnYAoAbVz5zg1e17MAACAAA=");
        assertThat(cko.source().eci()).isEqualTo("05");
        assertThat(cko.source().number()).isNull();
        assertThat(cko.source().cvv()).isNull();
        assertThat(cko.threeDs()).isNull();
    }

    @Test
    void entityKeepsTheMethodButNoCardData() {
        Payment payment = paymentMapper.toEntity(request(PaymentMethodType.NETWORK_TOKEN));
        assertThat(payment.getPaymentMethod()).isEqualTo(PaymentMethodType.NETWORK_TOKEN);
    }

    @Test
    void checkoutResponseUpdatesThePayment() {
        Payment payment = paymentMapper.toEntity(request(PaymentMethodType.APPLE_PAY));
        payment.setAmount(new BigDecimal("250.000"));          // as read back from NUMBER(19,3)
        payment.start("client", "key", "hash", "txn", AuthMethod.CRYPTOGRAM_3DS, "9999");

        CkoPaymentResponse pending = new CkoPaymentResponse("pay_1", "act_1", 25000L, "AED", null, "Pending", null,
                null, null, "SO-1", null, Map.of("redirect", new CkoPaymentResponse.Link("https://3ds/x")));
        payment.applyProviderResult(ckoMapper.toResult(pending));
        assertThat(payment.getState()).isEqualTo(PaymentState.CHALLENGE_REQUIRED);
        assertThat(paymentMapper.toResponse(payment).threeDsRedirectUrl()).isEqualTo("https://3ds/x");

        // GET after the challenge: no redirect link, no response code -> keeps what it had
        CkoPaymentResponse captured = new CkoPaymentResponse("pay_1", null, 25000L, "AED", true, "Captured", null,
                null, null, "SO-1", new CkoPaymentResponse.Source("card", "Visa", "3478", null), Map.of());
        payment.applyProviderResult(ckoMapper.toResult(captured));
        var response = paymentMapper.toResponse(payment);

        assertThat(response.status()).isEqualTo(PaymentStatus.CAPTURED);
        assertThat(response.threeDsRedirectUrl()).isNull();
        assertThat(response.cardScheme()).isEqualTo("Visa");
        assertThat(response.providerPaymentId()).isEqualTo("pay_1");
        assertThat(response.amount().value().scale()).isEqualTo(2);
    }

    @Test
    void checkoutStatusesMapToOurStates() {
        assertThat(PaymentState.fromCko("Authorized", false)).isEqualTo(PaymentState.APPROVED);
        assertThat(PaymentState.fromCko("Captured", false)).isEqualTo(PaymentState.CAPTURED);
        assertThat(PaymentState.fromCko("Pending", true)).isEqualTo(PaymentState.CHALLENGE_REQUIRED);
        assertThat(PaymentState.fromCko("Pending", false)).isEqualTo(PaymentState.PENDING);
        assertThat(PaymentState.fromCko("Declined", false)).isEqualTo(PaymentState.DECLINED);
        assertThat(PaymentState.fromCko("Voided", false)).isEqualTo(PaymentState.CANCELLED);
        assertThat(PaymentState.fromCko("Partially Refunded", false)).isEqualTo(PaymentState.REFUNDED);
        assertThat(PaymentState.fromCko("Brand New Status", false)).isNull();
        assertThat(paymentMapper.toStatus(PaymentState.CREATED)).isEqualTo(PaymentStatus.PENDING);
    }

    @Test
    void declineReasonComesFromCheckout() {
        Payment payment = paymentMapper.toEntity(request(PaymentMethodType.APPLE_PAY));
        payment.start("client", "key", "hash", "txn2", AuthMethod.CRYPTOGRAM_3DS, "9999");

        payment.applyProviderResult(new ProviderResult("pay_2", "act", "Declined", false, "20051", "Insufficient Funds",
                null, "Visa", "9999"));

        assertThat(payment.getState()).isEqualTo(PaymentState.DECLINED);
        assertThat(payment.getFailureReason()).isEqualTo("Insufficient Funds (20051)");
    }
}
