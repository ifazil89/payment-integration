package com.company.wallet.api;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class WalletDecryptorTest {

    private final WalletDecryptor bothOff = new WalletDecryptor(null, null);

    @Test
    void switchedOffWalletAnswersNotEnabled() {
        assertThat(bothOff.isEnabled(WalletType.APPLE_PAY)).isFalse();
        assertThat(bothOff.isEnabled(WalletType.GOOGLE_PAY)).isFalse();
        assertThatThrownBy(() -> bothOff.decryptApplePay("{}"))
                .isInstanceOf(WalletDecryptionException.class)
                .hasFieldOrPropertyWithValue("code", WalletDecryptionException.NOT_ENABLED);
        assertThatThrownBy(() -> bothOff.decryptGooglePay((GooglePayToken) null))
                .hasFieldOrPropertyWithValue("code", WalletDecryptionException.NOT_ENABLED);
    }
}
