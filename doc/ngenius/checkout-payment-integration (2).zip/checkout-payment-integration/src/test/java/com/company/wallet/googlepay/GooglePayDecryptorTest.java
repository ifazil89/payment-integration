package com.company.wallet.googlepay;

import com.company.wallet.api.AuthMethod;
import com.company.wallet.api.DecryptedWalletCard;
import com.company.wallet.api.GooglePayToken;
import com.company.wallet.api.WalletDecryptionException;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

import java.security.GeneralSecurityException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Google Pay: what we do with Tink's output. Tink's own verification/decryption (Google's signing keys,
 * ECv2) is exercised with real TEST-environment tokens (README, "Testing with real wallets").
 */
class GooglePayDecryptorTest {

    private static final Instant NOW = Instant.parse("2026-11-18T19:40:00Z");
    private static final Clock CLOCK = Clock.fixed(NOW, ZoneOffset.UTC);

    private static String message(long expiresAtMillis, String authMethod, String cryptogram) {
        return """
                {"gatewayMerchantId":"ignored","messageExpiration":"%d","messageId":"AH2EjtfQ9","paymentMethod":"CARD",
                 "paymentMethodDetails":{"expirationYear":2028,"expirationMonth":12,"pan":"4895370012003478",
                   "authMethod":"%s"%s,"eciIndicator":"05"}}"""
                .formatted(expiresAtMillis, authMethod, cryptogram == null ? "" : ",\"cryptogram\":\"" + cryptogram + "\"");
    }

    private static GooglePayDecryptor decryptorReturning(String json) {
        return new GooglePayDecryptor(sealed -> json, JsonMapper.builder().build(), CLOCK);
    }

    @Test
    void tokenObjectIsPassedToTinkAsGooglesJson() {
        AtomicReference<String> sealed = new AtomicReference<>();
        GooglePayDecryptor decryptor = new GooglePayDecryptor(token -> {
            sealed.set(token);
            return message(NOW.toEpochMilli() + 60_000, "CRYPTOGRAM_3DS", "AOrEWb==");
        }, JsonMapper.builder().build(), CLOCK);

        DecryptedWalletCard card = decryptor.decrypt(new GooglePayToken("ECv2", "R1NJRw==",
                new GooglePayToken.IntermediateSigningKey("{\"keyValue\":\"S1ZBTA==\"}", List.of("S1NJRw==")),
                "{\"encryptedMessage\":\"RU5D\"}"));

        assertThat(card.pan()).isEqualTo("4895370012003478");
        var json = JsonMapper.builder().build().readTree(sealed.get());
        assertThat(json.get("protocolVersion").asString()).isEqualTo("ECv2");
        assertThat(json.get("signedMessage").asString()).isEqualTo("{\"encryptedMessage\":\"RU5D\"}");   // still a string
        assertThat(json.get("intermediateSigningKey").get("signedKey").asString()).isEqualTo("{\"keyValue\":\"S1ZBTA==\"}");
        assertThat(json.get("intermediateSigningKey").get("signatures").get(0).asString()).isEqualTo("S1NJRw==");
    }

    @Test
    void cryptogram3dsTokenBecomesNetworkTokenCard() {
        DecryptedWalletCard card = decryptorReturning(
                message(NOW.toEpochMilli() + 60_000, "CRYPTOGRAM_3DS", "AgAAAAAABk4DWZ4C28yUQAAAAAA=")).decrypt("sealed");

        assertThat(card.authMethod()).isEqualTo(AuthMethod.CRYPTOGRAM_3DS);
        assertThat(card.cryptogram()).isEqualTo("AgAAAAAABk4DWZ4C28yUQAAAAAA=");
        assertThat(card.expiryMonth()).isEqualTo(12);
        assertThat(card.expiryYear()).isEqualTo(2028);
        assertThat(card.eci()).isEqualTo("05");
        assertThat(card.walletTransactionId()).isEqualTo("AH2EjtfQ9");
        assertThat(card.amountMinor()).isNull();
    }

    @Test
    void panOnlyTokenHasNoCryptogram() {
        DecryptedWalletCard card = decryptorReturning(message(NOW.toEpochMilli() + 60_000, "PAN_ONLY", null)).decrypt("sealed");

        assertThat(card.authMethod()).isEqualTo(AuthMethod.PAN_ONLY);
        assertThat(card.cryptogram()).isNull();
        assertThat(card.last4()).isEqualTo("3478");
    }

    @Test
    void expiredMessageIsRejected() {
        assertThatThrownBy(() -> decryptorReturning(message(NOW.toEpochMilli() - 1, "PAN_ONLY", null)).decrypt("sealed"))
                .isInstanceOf(WalletDecryptionException.class)
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_EXPIRED");
    }

    @Test
    void cryptogram3dsWithoutCryptogramIsInvalid() {
        assertThatThrownBy(() -> decryptorReturning(message(NOW.toEpochMilli() + 1, "CRYPTOGRAM_3DS", null)).decrypt("x"))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_INVALID");
    }

    @Test
    void unknownAuthMethodIsUnsupported() {
        assertThatThrownBy(() -> decryptorReturning(message(NOW.toEpochMilli() + 1, "SOMETHING_NEW", null)).decrypt("x"))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_UNSUPPORTED");
    }

    @Test
    void failedVerificationIsInvalid() {
        GooglePayDecryptor decryptor = new GooglePayDecryptor(
                sealed -> { throw new GeneralSecurityException("cannot verify signature"); },
                JsonMapper.builder().build(), CLOCK);

        assertThatThrownBy(() -> decryptor.decrypt("sealed"))
                .hasFieldOrPropertyWithValue("code", "WALLET_TOKEN_INVALID");
    }
}
