package com.company.wallet.keys;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.spec.ECGenParameterSpec;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** .p12 / PEM / base64 loading, with a self-signed certificate built here (no real Apple files needed). */
class WalletKeysTest {

    private static final char[] PASSWORD = "changeit".toCharArray();

    @Test
    void loadsCertificateAndKeyFromP12() throws Exception {
        KeyPair keyPair = keyPair("EC", new ECGenParameterSpec("secp256r1"));
        byte[] p12 = p12("apple-pay", keyPair, "SHA256withECDSA");

        WalletKeys.CertificateAndKey loaded = WalletKeys.fromPkcs12(new ByteArrayInputStream(p12), PASSWORD.clone(),
                null, "test.p12");

        assertThat(loaded.privateKey().getEncoded()).isEqualTo(keyPair.getPrivate().getEncoded());
        assertThat(loaded.certificate().getPublicKey()).isEqualTo(keyPair.getPublic());
        assertThat(loaded.toString()).contains("CN=merchant.com.company.shop").doesNotContain("PRIVATE");
    }

    @Test
    void usesTheGivenAlias() throws Exception {
        KeyPair keyPair = keyPair("EC", new ECGenParameterSpec("secp256r1"));
        byte[] p12 = p12("rotation-2027", keyPair, "SHA256withECDSA");

        assertThat(WalletKeys.fromPkcs12(new ByteArrayInputStream(p12), PASSWORD.clone(), "rotation-2027", "test.p12")
                .certificate().getPublicKey()).isEqualTo(keyPair.getPublic());
        assertThatThrownBy(() -> WalletKeys.fromPkcs12(new ByteArrayInputStream(p12), PASSWORD.clone(), "other", "test.p12"))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("alias 'other'");
    }

    @Test
    void wrongPasswordHasAClearMessage() throws Exception {
        byte[] p12 = p12("apple-pay", keyPair("EC", new ECGenParameterSpec("secp256r1")), "SHA256withECDSA");

        assertThatThrownBy(() -> WalletKeys.fromPkcs12(new ByteArrayInputStream(p12), "wrong".toCharArray(), null,
                "/opt/certs/apple-pay.p12"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("/opt/certs/apple-pay.p12").hasMessageContaining("wrong password");
    }

    @Test
    void rsaKeyIsRejected() throws Exception {
        KeyPairGenerator rsa = KeyPairGenerator.getInstance("RSA");
        rsa.initialize(2048);
        byte[] p12 = p12("identity", rsa.generateKeyPair(), "SHA256withRSA");

        assertThatThrownBy(() -> WalletKeys.fromPkcs12(new ByteArrayInputStream(p12), PASSWORD.clone(), null, "id.p12"))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("Merchant Identity Certificate");
    }

    @Test
    void pemAndBase64Decode() throws Exception {
        KeyPair keyPair = keyPair("EC", new ECGenParameterSpec("secp256r1"));
        String base64 = Base64.getEncoder().encodeToString(keyPair.getPrivate().getEncoded());
        String pem = "-----BEGIN PRIVATE KEY-----\n" + Base64.getMimeEncoder().encodeToString(keyPair.getPrivate().getEncoded())
                + "\n-----END PRIVATE KEY-----\n";

        assertThat(WalletKeys.ecPrivateKey(WalletKeys.decode(base64))).isEqualTo(keyPair.getPrivate());
        assertThat(WalletKeys.ecPrivateKey(WalletKeys.decode(pem))).isEqualTo(keyPair.getPrivate());
        assertThat(WalletKeys.base64Pkcs8(pem)).isEqualTo(base64);
    }

    // ------------------------------------------------------------------

    private static KeyPair keyPair(String algorithm, ECGenParameterSpec spec) throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance(algorithm);
        generator.initialize(spec);
        return generator.generateKeyPair();
    }

    private static byte[] p12(String alias, KeyPair keyPair, String signatureAlgorithm) throws Exception {
        X500Name name = new X500Name("CN=merchant.com.company.shop");
        Instant now = Instant.now();
        X509Certificate certificate = new JcaX509CertificateConverter().getCertificate(
                new JcaX509v3CertificateBuilder(name, BigInteger.ONE, Date.from(now),
                        Date.from(now.plus(365, ChronoUnit.DAYS)), name, keyPair.getPublic())
                        .build(new JcaContentSignerBuilder(signatureAlgorithm).build(keyPair.getPrivate())));

        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(null, null);
        keyStore.setKeyEntry(alias, keyPair.getPrivate(), PASSWORD, new Certificate[]{certificate});
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        keyStore.store(out, PASSWORD);
        return out.toByteArray();
    }
}
