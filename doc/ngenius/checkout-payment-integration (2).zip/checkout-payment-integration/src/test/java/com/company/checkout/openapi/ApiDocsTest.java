package com.company.checkout.openapi;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasItems;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * The generated OpenAPI document really uses the doc schemas (names, fields, required, patterns),
 * the endpoint documentation from PaymentApi, and the API-key security.
 */
@SpringBootTest
@ActiveProfiles({"local", "test"})
@AutoConfigureMockMvc
class ApiDocsTest {

    @Autowired
    MockMvc mvc;

    @Test
    void openApiDocumentDescribesThePaymentApi() throws Exception {
        mvc.perform(get("/v3/api-docs"))
                .andExpect(status().isOk())
                // endpoints, from PaymentApi
                .andExpect(jsonPath("$.paths['/api/v1/payments'].post.operationId").value("createPayment"))
                .andExpect(jsonPath("$.paths['/api/v1/payments'].post.parameters[*].name",
                        hasItems("Idempotency-Key", "X-Correlation-Id")))
                .andExpect(jsonPath("$.paths['/api/v1/payments'].post.responses['422']").exists())
                .andExpect(jsonPath("$.paths['/api/v1/payments/{paymentId}'].get.operationId").value("getPayment"))
                // schemas: documented under the DTO names, with the doc-class details
                .andExpect(jsonPath("$.components.schemas.PaymentRequest.required",
                        hasItems("merchantOrderId", "paymentMethod", "amount", "billingInfo")))
                .andExpect(jsonPath("$.components.schemas.PaymentMethod.properties.type.enum",
                        hasItems("CARD", "NETWORK_TOKEN", "APPLE_PAY", "GOOGLE_PAY")))
                .andExpect(jsonPath("$.components.schemas.CardDetails.required",
                        hasItems("number", "expiryMonth", "expiryYear", "cvv")))
                .andExpect(jsonPath("$.components.schemas.NetworkTokenDetails.properties.tokenType.enum",
                        hasItems("VTS", "MDES")))
                .andExpect(jsonPath("$.components.schemas.Amount.properties.currency.example").value("AED"))
                .andExpect(jsonPath("$.components.schemas.PaymentResponse.properties.threeDsRedirectUrl").exists())
                .andExpect(jsonPath("$.components.schemas.PaymentRequestSchema").doesNotExist())
                // security
                .andExpect(jsonPath("$.components.securitySchemes.apiKey.name").value("X-Api-Key"));
    }

    @Test
    void yamlVersionCanBeDownloaded() throws Exception {
        mvc.perform(get("/v3/api-docs.yaml")).andExpect(status().isOk());
    }
}
