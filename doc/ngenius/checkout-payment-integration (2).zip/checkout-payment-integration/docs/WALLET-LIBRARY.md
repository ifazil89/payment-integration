# Wallet decryption library (`com.company.wallet`)

Apple Pay and Google Pay token decryption, written as a **library that happens to live inside this project for now**.
It knows nothing about Checkout.com, our REST API or our database, so any PSP integration (Checkout.com, N-Genius, …)
can use it, and it can move to its own repository without changing the code that uses it.

- [1. What it does](#1-what-it-does)
- [2. Package layout](#2-package-layout)
- [3. Public API](#3-public-api)
- [4. The rules (checked on every build)](#4-the-rules-checked-on-every-build)
- [5. How it is loaded](#5-how-it-is-loaded)
- [6. Configuration (`wallet.*`)](#6-configuration-wallet)
- [7. How-to: future changes](#7-how-to-future-changes)
  - [7.1 Use it from another PSP integration](#71-use-it-from-another-psp-integration)
  - [7.2 Rotate an Apple Pay certificate or a Google Pay key](#72-rotate-an-apple-pay-certificate-or-a-google-pay-key)
  - [7.3 Add a key source (vault / KMS / HSM)](#73-add-a-key-source-vault--kms--hsm)
  - [7.4 Add a new wallet (e.g. Samsung Pay, Click to Pay)](#74-add-a-new-wallet-eg-samsung-pay-click-to-pay)
  - [7.5 Add a field to the decrypted card](#75-add-a-field-to-the-decrypted-card)
  - [7.6 Add a new error code](#76-add-a-new-error-code)
- [8. Move to a separate project](#8-move-to-a-separate-project)
- [9. Versioning and compatibility](#9-versioning-and-compatibility)
- [10. Checklist for every change](#10-checklist-for-every-change)

---

## 1. What it does

```
ApplePayToken  ──▶ verify Apple's signature (Apple Root CA G3, OIDs, signing time)
                   ──▶ pick our key by publicKeyHash ──▶ ECDH + KDF ──▶ AES-256-GCM ──▶ DecryptedWalletCard
GooglePayToken ──▶ Tink: verify Google's signature chain + decrypt (ECv2) ──▶ check expiry ──▶ DecryptedWalletCard
```

`DecryptedWalletCard` is **PSP-neutral**: card number or device card number (DPAN), expiry, cryptogram, ECI, auth method
(`CRYPTOGRAM_3DS` / `PAN_ONLY`), the wallet's transaction id, and for Apple Pay the amount the shopper approved.
Each PSP integration maps it to its own request (Checkout.com: `PaymentCkoMapper` → `network_token` or `card` source).

What the library does **not** do: HTTP, idempotency, storing anything, deciding 3DS, the PSP call. Those belong to
the application.

## 2. Package layout

```
src/main/java/com/company/wallet/
├── api/                      PUBLIC — the only package applications use              (future: wallet-decryption-core)
│   ├── WalletDecryptor            decryptApplePay(ApplePayToken | String), decryptGooglePay(GooglePayToken | String),
│   │                              isEnabled(WalletType)
│   ├── ApplePayToken              PKPaymentToken.paymentData {version, data, signature, header}
│   ├── GooglePayToken             tokenizationData.token {protocolVersion, signature, intermediateSigningKey, signedMessage}
│   ├── DecryptedWalletCard        the result (memory only, masked toString)
│   ├── AuthMethod, WalletType
│   └── WalletDecryptionException  code + public message (+ detail for logs only)
├── applepay/                 internal: ApplePayDecryptor, ApplePaySignatureVerifier, ApplePayCrypto, ApplePayDecryptedData
├── googlepay/                internal: GooglePayDecryptor, GooglePayDecryptedData
├── keys/                     internal: WalletKeys (.p12, PEM, base64; pure JDK)
└── spring/                   Spring Boot glue                                         (future: wallet-decryption-spring-boot-starter)
    ├── WalletAutoConfiguration    builds everything from wallet.* at startup, fails fast on bad keys
    ├── ApplePayProperties         wallet.apple-pay.*
    └── GooglePayProperties        wallet.google-pay.*

src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
                              registers com.company.wallet.spring.WalletAutoConfiguration

src/test/java/com/company/wallet/     the library's own tests (no checkout classes, no Spring context)
├── api/WalletDecryptorTest
├── applepay/ApplePayDecryptorTest
├── googlepay/GooglePayDecryptorTest
└── keys/WalletKeysTest
```

Dependencies the library needs (marked `wallet-decryption` in `pom.xml`):

| Dependency | Used by |
|---|---|
| `com.google.crypto.tink:apps-paymentmethodtoken` | `googlepay`, `spring` (Tink recipient) |
| `org.bouncycastle:bcpkix-jdk18on` | `applepay` (PKCS#7 signature) |
| `tools.jackson.core:jackson-databind` (Jackson 3) | `applepay`, `googlepay` (token / decrypted JSON) |
| `org.slf4j:slf4j-api` | `api.WalletDecryptor` (safe log line per decryption) |
| `org.springframework.boot:spring-boot-autoconfigure` | `spring` only |

## 3. Public API

```java
// Spring: inject it (built by WalletAutoConfiguration)
private final WalletDecryptor walletDecryptor;

DecryptedWalletCard card = walletDecryptor.decryptApplePay(applePayToken);   // or a String (JSON / base64)
DecryptedWalletCard card = walletDecryptor.decryptGooglePay(googlePayToken); // or the String from Google

// Without Spring: build it yourself
WalletDecryptor decryptor = new WalletDecryptor(applePayDecryptor, googlePayDecryptor);   // null = wallet off
```

Errors: every problem is a `WalletDecryptionException` with a code. Return `getCode()` + `getPublicMessage()` to your
client (this app: HTTP 422 in `GlobalExceptionHandler`); log `getMessage()`, never return it.

| Code | When |
|---|---|
| `WALLET_TOKEN_INVALID` | signature, certificate chain, key, decryption or JSON check failed |
| `WALLET_TOKEN_EXPIRED` | Google Pay `messageExpiration` passed; Apple Pay signed longer ago than `max-token-age` |
| `WALLET_TOKEN_UNSUPPORTED` | Apple `RSA_v1` / EMV, Google non-card or unknown auth method |
| `WALLET_NOT_ENABLED` | that wallet is switched off (`wallet.*.enabled=false`) |
| `WALLET_AMOUNT_MISMATCH` | reserved for callers (this app compares the Apple Pay amount with the request) |

Converting **your API objects** into `ApplePayToken` / `GooglePayToken` is the application's job (here:
`PaymentMethodResolver.toApplePayToken / toGooglePayToken`). The library never sees our DTOs.

## 4. The rules (checked on every build)

`src/test/java/com/company/checkout/architecture/WalletBoundaryTest.java` reads the sources (comments and strings
ignored) and fails the build when a rule is broken:

| # | Rule | Why |
|---|---|---|
| 1 | `com.company.wallet..` never references `com.company.checkout..` | the library must compile alone |
| 2 | only `com.company.wallet.spring..` references `org.springframework..` | `api/applepay/googlepay/keys` = plain Java core |
| 3 | `com.company.wallet..` uses no `lombok`, `jakarta.persistence`, `jakarta.servlet` | no app stack in the library |
| 4 | `com.company.checkout..` references only `com.company.wallet.api..` | internals can change freely |
| 5 | the auto-configuration file lists `WalletAutoConfiguration` | it is loaded like a jar, not component-scanned |

If the test fails, fix the dependency; do not loosen the test. Typical fixes:

- Need a Spring feature in a decryptor? Pass the value in through the constructor, built in `WalletAutoConfiguration`.
- Need an app class in the library (e.g. `ApiException`)? Throw `WalletDecryptionException` and map it in the app.
- Need an internal class in checkout (e.g. `WalletKeys`)? Add what you need to `api`, or keep it inside `spring`.

## 5. How it is loaded

- `CheckoutPaymentApplication` (`@SpringBootApplication`) scans **only** `com.company.checkout`.
- `com.company.wallet` is outside that scan. It is switched on by Spring Boot auto-configuration through
  `META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports` — exactly how a separate jar
  will be found later. Nothing changes for the app after the move.
- Every bean is `@ConditionalOnMissingBean`: an application can define its own `WalletDecryptor`, `ApplePayDecryptor`
  or `GooglePayDecryptor` and the library steps back. Tests replace `WalletDecryptor` with `@MockitoBean`.
- Optional beans used if present: `ObjectMapper` (else a default `JsonMapper`), `Clock` (else system UTC).
- Startup log (safe, no secrets):
  ```
  Apple Pay certificate folder: /opt/checkout/certs/apple-pay
  Apple Pay key loaded from apple-pay.p12: publicKeyHash …, subject CN=merchant.com.company.shop…, valid until …
  Apple Pay root CA loaded from /opt/checkout/certs/apple-pay/AppleRootCA-G3.cer: CN=Apple Root CA - G3,…
  Google Pay decryption ready: environment TEST, merchant …, 1 key(s)
  Wallet decryption ready: Apple Pay on, Google Pay on
  ```

## 6. Configuration (`wallet.*`)

```yaml
wallet:
  apple-pay:
    enabled: true
    merchant-identifier: merchant.com.company.shop
    certificate-dir: /opt/checkout/certs/apple-pay     # folder outside the jar
    root-ca-certificate: AppleRootCA-G3.cer            # plain name -> in the folder; or /abs/path, file:, classpath:
    max-token-age: 5m
    keys:                                              # one per Payment Processing Certificate (two during rotation)
      - keystore: apple-pay.p12
        keystore-password: ${APPLE_PAY_KEYSTORE_PASSWORD}
        alias: ""                                      # empty = first entry with a private key
      # or: - certificate: <base64/PEM>  private-key: <base64/PEM PKCS#8>
  google-pay:
    enabled: true
    environment: TEST                                  # TEST | PRODUCTION
    merchant-id: "1234567890"
    private-keys: <base64 PKCS#8>[,<second key during rotation>]
```

Startup fails with a clear message for: missing merchant id, empty keys, folder missing / not readable, a plain file
name without `certificate-dir`, `.p12` not found / not readable / wrong password / no key under the alias / RSA key,
Apple root CA missing, no Google private key.

## 7. How-to: future changes

### 7.1 Use it from another PSP integration

**Today (same repo):** copy nothing; the other integration lives in this app and injects `WalletDecryptor`.

**After the move (§8):** in the other project:

1. Add the dependency:
   ```xml
   <dependency>
       <groupId>com.company.payments</groupId>
       <artifactId>wallet-decryption-spring-boot-starter</artifactId>
       <version>1.0.0</version>
   </dependency>
   ```
2. Add the `wallet.*` properties (§6). Same merchant ids → same keys; different merchant ids → that project's own keys.
3. Convert your API's token objects to `ApplePayToken` / `GooglePayToken` and call `WalletDecryptor`.
4. Map `DecryptedWalletCard` to the PSP's request:
   - `authMethod == CRYPTOGRAM_3DS` → the PSP's network-token / wallet-token source: `pan` (DPAN) + `cryptogram` + `eci`.
   - `authMethod == PAN_ONLY` (Google Pay only) → the PSP's card source **with 3DS**.
   - Apple Pay: check `amountMinor` / `currencyNumeric` against your request.
   - Store `walletTransactionId` as unique to reject a token used twice.
5. Map `WalletDecryptionException` codes to your API errors.
6. Add masking rules for your token fields (the token objects must be logged as `***`).

### 7.2 Rotate an Apple Pay certificate or a Google Pay key

Apple Pay:
1. Create the new key + CSR, get the new certificate from Apple, build the new `.p12` (README §4).
2. Put it in the certificate folder next to the old one and add a **second** `keys` entry:
   ```yaml
   keys:
     - keystore: apple-pay.p12            # current
       keystore-password: ${APPLE_PAY_KEYSTORE_PASSWORD}
     - keystore: apple-pay-2027.p12       # new
       keystore-password: ${APPLE_PAY_KEYSTORE_PASSWORD_2027}
   ```
3. Deploy, check the startup log shows both keys, then activate the new certificate at Apple.
4. After the old certificate's tokens are gone (a few days), remove the old entry and file.

Google Pay: add the new private key as a second value of `private-keys`, register the new public key in the Google Pay
& Wallet Console and in the frontend, then remove the old key.

### 7.3 Add a key source (vault / KMS / HSM)

Keys are read in one place: `WalletAutoConfiguration` (where) + `WalletKeys` (parse).

1. Keep `WalletKeys` pure: add a parser there only if the format is new (e.g. `fromJwk(...)`).
2. Add the source in `spring/`, e.g. a `WalletKeySource` interface with `List<CertificateAndKey> applePayKeys()`:
   - default implementation = today's properties / folder logic;
   - `@ConditionalOnMissingBean`, so an app (or a new `wallet.key-source=vault` property) can provide a vault one.
3. If the private key never leaves an HSM, the ECDH step must run in the HSM: give `ApplePayDecryptor` a
   `KeyAgreement`-like interface instead of a `PrivateKey` and implement it with the HSM's provider.
4. Add a test in `src/test/java/com/company/wallet/...`; the boundary rules still apply (no vault SDK outside `spring/`
   unless it is a plain Java SDK and you accept it as a core dependency).

### 7.4 Add a new wallet (e.g. Samsung Pay, Click to Pay)

1. `api/WalletType` — add the constant.
2. `api/<Wallet>Token` — the encrypted token as a record (field names = the wallet's JSON names), masked `toString`.
3. `<wallet>/` package — `<Wallet>Decryptor` (constructor-built, thread-safe, no Spring) returning `DecryptedWalletCard`;
   throw only `WalletDecryptionException`.
4. `api/WalletDecryptor` — `decrypt<Wallet>(<Wallet>Token)` + `isEnabled` case; constructor parameter (null = off).
   Adding a constructor parameter is a **breaking change** for code that builds `WalletDecryptor` by hand: keep the old
   constructor delegating with `null`.
5. `spring/<Wallet>Properties` (`wallet.<wallet>.*`) + a `@ConditionalOnProperty(... enabled ...)` bean in
   `WalletAutoConfiguration`.
6. Tests under `src/test/java/com/company/wallet/<wallet>/` (build tokens the way the wallet does, as for Apple Pay).
7. In the application: request DTO + doc schema, `PaymentMethodType`, `PaymentMethodResolver` (validate + map),
   `PaymentCkoMapper` token type, masking rule `paymentMethod.<field>` FULL, README.

### 7.5 Add a field to the decrypted card

`DecryptedWalletCard` is a record used by every PSP integration:

- Add new components at the **end** and keep a constructor with the old parameter list (delegating with `null`), so
  existing callers and tests compile. Mention it in the release notes (minor version).
- Never add secrets to `toString`.

### 7.6 Add a new error code

Add a constant + factory in `WalletDecryptionException`. Applications that map codes explicitly need to handle it;
unknown codes should fall back to 422 (this app maps every `WalletDecryptionException` to 422).

## 8. Move to a separate project

Do this when a second PSP integration needs the library. Nothing in `com.company.checkout` changes.

**1. New repository `wallet-decryption`, two modules:**

```
wallet-decryption/
├── pom.xml                                   parent: groupId com.company.payments, version 1.0.0, Java 21
├── wallet-decryption-core/
│   ├── pom.xml                               tink, bcpkix, jackson-databind, slf4j-api
│   └── src/main/java/com/company/wallet/{api,applepay,googlepay,keys}
│       src/test/java/com/company/wallet/{api,applepay,googlepay,keys}
└── wallet-decryption-spring-boot-starter/
    ├── pom.xml                               wallet-decryption-core, spring-boot-autoconfigure,
    │                                         spring-boot-configuration-processor (optional)
    └── src/main/java/com/company/wallet/spring
        src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
```

**2. Copy from this project** (same paths, same package names):

| From this project | To |
|---|---|
| `src/main/java/com/company/wallet/{api,applepay,googlepay,keys}` | core `src/main/java/...` |
| `src/test/java/com/company/wallet/**` | core `src/test/java/...` (add junit, assertj, mockito as test deps) |
| `src/main/java/com/company/wallet/spring` | starter `src/main/java/...` |
| `src/main/resources/META-INF/spring/...AutoConfiguration.imports` | starter `src/main/resources/...` |
| the `wallet-decryption` blocks in `pom.xml` | core / starter `pom.xml` |
| this file | the new repository's `README.md` |

**3. Make the rules permanent in the new repo:** module boundaries now enforce rules 1–3 (core has no Spring
dependency, neither has this app). Keep a small copy of `WalletBoundaryTest` rule 2 in the core module, or just rely on
the missing dependency.

**4. Build and publish** to Nexus / Artifactory: `mvn deploy` → `com.company.payments:wallet-decryption-*:1.0.0`.
Pin Spring Boot / Jackson versions through the Spring Boot BOM in the starter so apps on the same Boot line match.

**5. In this project:**

1. Delete `src/main/java/com/company/wallet`, `src/test/java/com/company/wallet`, and the auto-configuration imports
   file (keep the file if the app adds its own auto-configurations; then remove only the wallet line).
2. Replace the `wallet-decryption` pom blocks with:
   ```xml
   <dependency>
       <groupId>com.company.payments</groupId>
       <artifactId>wallet-decryption-spring-boot-starter</artifactId>
       <version>1.0.0</version>
   </dependency>
   ```
3. Keep `WalletBoundaryTest` rule 4 only (checkout uses only `com.company.wallet.api`); remove rules 1, 2, 3, 5 (they
   now live in the library).
4. `mvn verify` — `PaymentApiTest` and everything else must pass unchanged. Same `wallet.*` properties, same packages.

**6. Other PSP integrations:** §7.1.

## 9. Versioning and compatibility

- **Semantic versions.** Major = breaking change in `api` or `wallet.*` properties; minor = new feature (new wallet,
  new property with a default, new record component with a compatible constructor); patch = fixes.
- **Only `api` and `wallet.*` are the contract.** `applepay`, `googlepay`, `keys`, `spring` internals may change in any
  release (apps must not use them — rule 4).
- **Security fixes first.** Tink / BouncyCastle advisories → patch release; every consuming project upgrades.
- **Release notes** list: API changes, property changes, dependency upgrades, and any startup-check changes (an app
  that started before may now stop on a bad key — that is intended, but say so).

## 10. Checklist for every change

- [ ] `mvn verify` passes, including `WalletBoundaryTest`.
- [ ] New classes in the right package: public contract in `api`, Spring only in `spring`.
- [ ] No secrets in `toString`, log lines or exception messages (`getMessage()` may contain technical detail, never
      key material or card data).
- [ ] New token fields are masked in the application's `app.logging.masking.rules`.
- [ ] Startup checks give a message naming the property / file for every new required setting.
- [ ] Tests for the change live under `src/test/java/com/company/wallet/` (library) or `com.company.checkout` (app).
- [ ] This file and the README are updated.
